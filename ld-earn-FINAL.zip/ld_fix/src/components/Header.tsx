/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Coins, User, Wallet, ShieldAlert, CheckCircle, Smartphone } from 'lucide-react';
import ldLogo from '../assets/images/ld_logo_1781514983884.jpg';

interface HeaderProps {
  activeTab: 'dashboard' | 'tasks' | 'referrals' | 'wallet' | 'withdraw';
  setActiveTab: (tab: 'dashboard' | 'tasks' | 'referrals' | 'wallet' | 'withdraw') => void;
  availableWithdrawal: number;
}

export default function Header({
  activeTab,
  setActiveTab,
  availableWithdrawal,
}: HeaderProps) {
  const tabs: { id: 'dashboard' | 'tasks' | 'referrals' | 'wallet' | 'withdraw'; label: string }[] = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'tasks', label: 'Daily Tasks' },
    { id: 'referrals', label: 'Referrals' },
    { id: 'wallet', label: 'Wallet Ledger' },
    { id: 'withdraw', label: 'Secure Payout' },
  ];

  return (
    <header className="w-full bg-[#070707] border-b border-amber-500/10 sticky top-0 z-40 shadow-[0_4px_25px_rgba(0,0,0,0.5)]">
      
      {/* Row 1: LOGO & USER PROFILE */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        
        {/* LOGO */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
          <div className="flex h-11 w-11 items-center justify-center rounded-xl overflow-hidden border border-amber-500/20 bg-[#111111] p-0.5 shadow-[0_0_15px_rgba(245,175,25,0.15)] relative">
            <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-transparent pointer-events-none" />
            <img 
              src={ldLogo} 
              alt="LD Logo" 
              className="h-full w-full object-cover rounded-lg" 
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h1 className="font-display font-black text-lg tracking-[0.1em] bg-gradient-to-r from-amber-300 via-[#f5af19] to-amber-500 bg-clip-text text-transparent uppercase leading-none">
              LD EARN
            </h1>
            <p className="font-mono text-[8px] text-amber-500/70 font-black uppercase tracking-[0.25em] leading-none mt-1">
              DAILY REWARDS PORTAL
            </p>
          </div>
        </div>

        {/* USER PROFILE */}
        <div className="flex items-center space-x-3 bg-[#111111] hover:bg-amber-500/5 px-4 py-2 rounded-full border border-amber-500/10 hover:border-amber-500/20 transition duration-300">
          <div className="h-7 w-7 rounded-full bg-amber-500/10 border border-amber-500/35 flex items-center justify-center text-amber-500 shadow-sm">
            <User className="h-4 w-4" />
          </div>
          <div className="text-left hidden sm:block">
            <div className="text-xs font-black text-white leading-tight">Member Account</div>
            <div className="text-[9px] font-mono font-bold text-amber-500 uppercase tracking-widest leading-none mt-0.5">Level 2 Partner</div>
          </div>
        </div>

      </div>

      {/* Row 2: NAVIGATION TABS */}
      <div className="border-t border-amber-500/10 bg-[#040404]/90 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-1 sm:space-x-4 h-13 items-center overflow-x-auto scrollbar-none justify-around sm:justify-start">
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`tab-navigation-${tab.id}`}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-2 h-full rounded-none relative border-b-2 text-[11px] font-black uppercase tracking-[0.1em] transition-all whitespace-nowrap cursor-pointer flex items-center justify-center ${
                    isActive
                      ? 'border-amber-500 text-amber-400 font-extrabold shadow-[inset_0_-2px_0_#f5af19] drop-shadow-[0_2px_8px_rgba(245,175,25,0.2)]'
                      : 'border-transparent text-gray-400 hover:text-white hover:border-amber-500/30'
                  }`}
                >
                  {tab.label}
                  {tab.id === 'tasks' && (
                    <span className="ml-2 flex h-2 w-2 rounded-full bg-red-500 animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

    </header>
  );
}
