/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { EarningActivity, SocialTask } from '../types';
import { formatNaira, playSynthSound } from '../utils';
import { motion } from 'motion/react';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  Wallet, 
  Users, 
  CheckCircle, 
  TrendingUp, 
  ArrowRight, 
  Zap, 
  Sparkles, 
  User, 
  Hourglass,
  Clock,
  XCircle,
  BellRing,
  ExternalLink,
  MessageSquare,
  Send,
  ShieldCheck
} from 'lucide-react';

interface DashboardProps {
  referralBalance: number;
  taskBalance: number;
  totalBalance: number;
  availableWithdrawal: number;
  todaysTasksCount: number;
  referralEarnings: number;
  totalReferrals: number;
  activities: EarningActivity[];
  highlightTask: SocialTask | null;
  profileLevel: string;
  onNavigate: (tab: 'dashboard' | 'tasks' | 'referrals' | 'wallet' | 'withdraw') => void;
  onQuickCompleteTask: (task: SocialTask) => void;
  onQuickWithdraw?: (amount: number, category: 'Referral' | 'Task') => void;
  officialChannelLink?: string;
  officialWhatsappLink?: string;
}

export default function Dashboard({
  referralBalance,
  taskBalance,
  totalBalance,
  availableWithdrawal,
  todaysTasksCount,
  referralEarnings,
  totalReferrals,
  activities,
  highlightTask,
  profileLevel,
  onNavigate,
  onQuickCompleteTask,
  onQuickWithdraw,
  officialChannelLink = 'https://t.me/+8aDqe4G00v8xOGI0',
  officialWhatsappLink = 'https://whatsapp.com/channel/0029Vb8MwfN4CrfZB97sry1r'
}: DashboardProps) {

  const [isShaking, setIsShaking] = React.useState(false);

  // Keep track of the number of failed activities we have seen to trigger visual feedback
  const prevFailedCountRef = React.useRef(0);

  React.useEffect(() => {
    prevFailedCountRef.current = activities.filter(a => a.status === 'Failed').length;
  }, []);

  const triggerShakeEffect = React.useCallback(() => {
    setIsShaking(true);
    playSynthSound('err');
    const timer = setTimeout(() => {
      setIsShaking(false);
    }, 550);
    return () => clearTimeout(timer);
  }, []);

  React.useEffect(() => {
    const currentFailedCount = activities.filter(a => a.status === 'Failed').length;
    if (currentFailedCount > prevFailedCountRef.current) {
      triggerShakeEffect();
    }
    prevFailedCountRef.current = currentFailedCount;
  }, [activities, triggerShakeEffect]);

  React.useEffect(() => {
    const handleGlobalShake = () => {
      triggerShakeEffect();
    };
    window.addEventListener('balance-shake', handleGlobalShake);
    return () => {
      window.removeEventListener('balance-shake', handleGlobalShake);
    };
  }, [triggerShakeEffect]);

  const shakeVariants = {
    shake: {
      x: [0, -8, 8, -8, 8, -5, 5, -2, 2, 0],
      transition: { duration: 0.5, ease: "easeInOut" }
    },
    idle: {
      x: 0
    }
  };

  // Generate dynamic path coordinate values for the Earnings curve
  const getGraphLinePoints = () => {
    if (activities.length === 0) return "10,120 150,120 300,120 450,120 600,120";
    
    const baseline = 1500;
    let currentTotal = baseline;
    const history: number[] = [baseline];

    activities.forEach(act => {
      if (act.status === 'Successful') {
        if (act.isCredit) {
          currentTotal += act.amount;
        } else {
          currentTotal -= act.amount;
        }
        history.push(currentTotal);
      }
    });

    const pointsList = history.slice(-8);
    while (pointsList.length < 5) {
      pointsList.unshift(baseline);
    }

    const maxVal = Math.max(...pointsList, 15000);
    const minVal = Math.min(...pointsList, 1000);
    const diff = (maxVal - minVal) || 1000;

    const coordinates = pointsList.map((val, index) => {
      const x = 20 + index * (700 / (pointsList.length - 1));
      const computedY = 135 - ((val - minVal) / diff) * 100;
      return `${x},${computedY}`;
    });

    return coordinates.join(' ');
  };

  return (
    <div className="space-y-8 animate-fade-in font-sans text-white">
      
      {/* 1. Header Segment: Personalized Welcome with Integrated Total Balance Showcase */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#0c0c0e] to-[#040405] rounded-[2rem] border border-amber-500/15 p-6 sm:p-8 shadow-[0_12px_40px_rgba(0,0,0,0.7)]">
        {/* Background micro grid aura */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(245,175,25,0.06),transparent_60%)] pointer-events-none" />
        
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/25 rounded-full text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                <ShieldCheck className="h-3.5 w-3.5 text-amber-400" />
                Verified Partner
              </span>
              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-zinc-900 border border-zinc-800 rounded-full text-[10px] font-mono text-gray-400 uppercase tracking-wider">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Ledger Live
              </span>
            </div>
            
            <div>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight font-display text-white">
                Welcome Back, Partner!
              </h2>
              <p className="text-xs sm:text-sm text-gray-400 max-w-lg leading-relaxed mt-1">
                You have logged <strong className="text-amber-400 font-bold">{activities.filter(a => a.type === 'Task' && a.status === 'Successful').length} task handshakes</strong> this week. Continue driving performance to hit your next cashout milestone!
              </p>
            </div>
          </div>

          {/* Large prominent Total Ledger Balance Showcase */}
          <div className="bg-gradient-to-br from-[#131316] to-[#08080a] border border-amber-500/10 rounded-2xl p-5 sm:p-6 min-w-[260px] lg:min-w-[320px] flex flex-col justify-between shadow-inner relative group hover:border-amber-500/20 transition-all duration-300">
            <div className="absolute top-0 right-0 w-20 h-20 bg-amber-500/5 rounded-full blur-xl pointer-events-none" />
            <div className="flex items-center justify-between text-gray-400">
              <span className="font-mono text-[9px] tracking-[0.2em] uppercase font-black">
                TOTAL LEDGER BALANCE
              </span>
              <Wallet className="h-4.5 w-4.5 text-amber-500" />
            </div>
            
            <h1 className="text-3xl sm:text-4xl font-black tracking-tight font-display mt-3 bg-gradient-to-r from-white via-amber-200 to-amber-400 bg-clip-text text-transparent drop-shadow-[0_2px_8px_rgba(245,175,25,0.25)]">
              {formatNaira(totalBalance)}
            </h1>

            <div className="flex items-center gap-2 mt-4 text-[10px] text-gray-500">
              <span className="inline-flex items-center gap-1 text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded font-bold">
                <TrendingUp className="h-3 w-3" />
                Active
              </span>
              <span>Consolidated wallet asset pool</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Official Communities Broadcast Ribbon */}
      <div className="relative overflow-hidden bg-gradient-to-r from-amber-950/20 via-[#0c0c0e] to-[#050506] rounded-[2rem] border border-amber-500/15 p-5 sm:p-6 shadow-md flex flex-col xl:flex-row items-center justify-between gap-5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_left,rgba(245,175,25,0.04),transparent_50%)] pointer-events-none" />
        
        <div className="flex items-center gap-4 w-full xl:w-auto relative z-10">
          <div className="h-11 w-11 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/20">
            <BellRing className="h-5 w-5 text-amber-500 animate-bounce" />
          </div>
          <div>
            <span className="font-mono text-[9px] font-black text-amber-500 uppercase tracking-widest leading-none">
              SYSTEM ANNOUNCEMENT CHANNEL
            </span>
            <h3 className="text-sm font-black text-white font-display uppercase tracking-wider mt-1">
              Join Our Official Communities!
            </h3>
            <p className="text-[11px] text-gray-400 leading-normal mt-0.5 max-w-xl">
              Stay fully updated on high-yield tasks, instant payment proofs, and official announcements on our active channels.
            </p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full xl:w-auto relative z-10">
          <a 
            href={officialWhatsappLink}
            target="_blank"
            rel="noreferrer"
            className="flex-1 sm:flex-none shrink-0 flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600/90 hover:bg-emerald-500 text-white text-xs font-black uppercase tracking-wider rounded-xl transition duration-200 cursor-pointer shadow-md shadow-emerald-600/15"
          >
            <MessageSquare className="h-3.5 w-3.5" />
            <span>WhatsApp Group</span>
            <ExternalLink className="h-3 w-3" />
          </a>
          <a 
            href={officialChannelLink}
            target="_blank"
            rel="noreferrer"
            className="flex-1 sm:flex-none shrink-0 flex items-center justify-center gap-2 px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:brightness-110 text-slate-950 text-xs font-black uppercase tracking-wider rounded-xl transition duration-200 cursor-pointer shadow-md shadow-amber-500/10"
          >
            <Send className="h-3.5 w-3.5" />
            <span>Telegram Channel</span>
            <ExternalLink className="h-3 w-3" />
          </a>
        </div>
      </div>

      {/* 3. Core Balance Grid Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Referral Balance Card */}
        <motion.div 
          variants={shakeVariants}
          animate={isShaking ? "shake" : "idle"}
          className="bg-gradient-to-br from-[#0e0e11] to-[#050506] text-white rounded-[2rem] p-6 sm:p-7 border border-amber-500/10 shadow-[0_12px_36px_rgba(0,0,0,0.65)] relative overflow-hidden flex flex-col justify-between h-48 animate-scale-in group hover:border-amber-500/20 transition duration-300"
        >
          {/* Decorative faint background watermark */}
          <div className="absolute right-[-10px] bottom-[-20px] opacity-[0.03] text-amber-500 pointer-events-none">
            <Users className="h-44 w-44" />
          </div>

          <div>
            <div className="flex items-center justify-between text-gray-400">
              <span className="font-mono text-[9px] tracking-[0.2em] uppercase font-black text-amber-500/80">
                REFERRAL FUNDS
              </span>
              <Users className="h-4 w-4 text-amber-500/60" />
            </div>
            
            <h3 className="text-3xl font-black tracking-tight font-display mt-3 text-white">
              {formatNaira(referralBalance)}
            </h3>
          </div>

          <div className="flex items-center justify-between border-t border-zinc-900/80 pt-3.5 z-10">
            <p className="text-[10px] text-gray-400">From verified invited partners</p>
            <button
              onClick={() => onNavigate('referrals')}
              className="font-mono text-[9px] font-bold uppercase text-amber-500 hover:text-amber-400 flex items-center gap-1 transition"
            >
              Invites <ArrowRight className="h-3 w-3" />
            </button>
          </div>
        </motion.div>

        {/* Task Balance Card */}
        <motion.div 
          variants={shakeVariants}
          animate={isShaking ? "shake" : "idle"}
          className="bg-gradient-to-br from-[#0e0e11] to-[#050506] text-white rounded-[2rem] p-6 sm:p-7 border border-amber-500/10 shadow-[0_12px_36px_rgba(0,0,0,0.65)] relative overflow-hidden flex flex-col justify-between h-48 animate-scale-in group hover:border-amber-500/20 transition duration-300"
        >
          {/* Decorative faint background watermark */}
          <div className="absolute right-[-10px] bottom-[-20px] opacity-[0.03] text-amber-500 pointer-events-none">
            <CheckCircle className="h-44 w-44" />
          </div>

          <div>
            <div className="flex items-center justify-between text-gray-400">
              <span className="font-mono text-[9px] tracking-[0.2em] uppercase font-black text-amber-500/80">
                TASK REWARDS
              </span>
              <CheckCircle className="h-4 w-4 text-amber-500/60" />
            </div>
            
            <h3 className="text-3xl font-black tracking-tight font-display mt-3 text-white">
              {formatNaira(taskBalance)}
            </h3>
          </div>

          <div className="flex items-center justify-between border-t border-zinc-900/80 pt-3.5 z-10">
            <p className="text-[10px] text-gray-400">Social promo target rewards</p>
            <button
              onClick={() => onNavigate('tasks')}
              className="font-mono text-[9px] font-bold uppercase text-amber-500 hover:text-amber-400 flex items-center gap-1 transition"
            >
              Tasks <ArrowRight className="h-3 w-3" />
            </button>
          </div>
        </motion.div>

        {/* Available Withdrawal Cashout Card (High Highlight) */}
        <motion.div 
          variants={shakeVariants}
          animate={isShaking ? "shake" : "idle"}
          className="bg-gradient-to-br from-[#1a1306] via-[#0b0a0c] to-[#050506] text-white rounded-[2rem] p-6 sm:p-7 border border-amber-500/25 shadow-[0_12px_36px_rgba(245,175,25,0.08)] relative overflow-hidden flex flex-col justify-between h-48 animate-scale-in group hover:border-amber-500/40 transition duration-300"
        >
          {/* Subtle glowing halo aura */}
          <div className="absolute top-[-20px] right-[-20px] w-24 h-24 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between text-amber-400">
              <span className="font-mono text-[9px] tracking-[0.2em] uppercase font-black">
                ELIGIBLE CASHOUT
              </span>
              <Sparkles className="h-4 w-4 text-amber-400 animate-pulse" />
            </div>
            
            <h3 className="text-3xl font-black tracking-tight font-display mt-3 bg-gradient-to-r from-[#ffe066] via-amber-400 to-[#e65c00] bg-clip-text text-transparent drop-shadow-[0_2px_8px_rgba(245,175,25,0.3)]">
              {formatNaira(availableWithdrawal)}
            </h3>
          </div>

          <div className="flex items-center justify-between border-t border-amber-500/10 pt-3 z-10">
            <p className="text-[10px] text-amber-300/60">Cleared instant withdrawal pool</p>
            
            <button
              id="dashboard-quick-withdraw-btn"
              onClick={() => {
                if (onQuickWithdraw) {
                  const totalAvail = availableWithdrawal;
                  const halfAvail = Math.round(totalAvail * 0.5);
                  let chosenCategory: 'Referral' | 'Task' = 'Referral';
                  let chosenAmount = halfAvail;

                  if (referralBalance >= halfAvail && halfAvail > 0) {
                    chosenCategory = 'Referral';
                  } else if (taskBalance >= halfAvail && halfAvail > 0) {
                    chosenCategory = 'Task';
                  } else {
                    if (referralBalance >= taskBalance) {
                      chosenCategory = 'Referral';
                      chosenAmount = Math.min(halfAvail, referralBalance);
                    } else {
                      chosenCategory = 'Task';
                      chosenAmount = Math.min(halfAvail, taskBalance);
                    }
                  }
                  onQuickWithdraw(chosenAmount, chosenCategory);
                }
              }}
              className="flex items-center gap-1 px-3 py-1.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:brightness-110 text-slate-950 rounded-xl text-[10px] font-black uppercase tracking-wider transition duration-200 cursor-pointer shadow-md shadow-amber-500/10"
            >
              <span>Quick Cashout 50%</span>
              <ArrowRight className="h-3 w-3" />
            </button>
          </div>
        </motion.div>

      </div>

      {/* 4. Secondary Action Segment: Target Promo & Graph Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Daily Task Target Promo Card */}
        <div className="lg:col-span-5 bg-[#0a0a0c] rounded-[2rem] border border-amber-500/10 p-6 shadow-md flex flex-col justify-between min-h-[300px]">
          <div>
            <span className="font-mono text-[9px] tracking-widest text-[#f5af19] bg-[#f5af19]/10 border border-[#f5af19]/25 px-2.5 py-1 rounded-lg uppercase font-black flex items-center gap-1.5 w-fit">
              <span className="h-1.5 w-1.5 rounded-full bg-[#f5af19] animate-pulse" />
              Promo Target Campaign
            </span>
            
            <div className="mt-6 flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-[#f5af19] to-[#e65c00] flex items-center justify-center text-slate-950 mb-3 shadow-md shadow-amber-500/20">
                <Zap className="h-5.5 w-5.5" />
              </div>
              <h4 className="text-sm font-black text-white font-display uppercase tracking-wider">
                Fresh Promotion Targets Ready
              </h4>
              <p className="mt-1.5 text-[11px] text-gray-400 max-w-xs leading-normal">
                Submit screenshot proof of active social sharing to clear instant wallet commissions.
              </p>
            </div>
          </div>

          <button
            id="daily-task-route-card"
            onClick={() => onNavigate('tasks')}
            className="w-full mt-4 py-3 bg-zinc-900 hover:bg-zinc-800/80 border border-amber-500/15 rounded-2xl text-[10px] font-black uppercase tracking-wider text-amber-400 transition flex items-center justify-center gap-1.5"
          >
            <span>Launch Social Tasks</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        {/* Dynamic Growth SVG Curve chart */}
        <div className="lg:col-span-7 bg-[#0a0a0c] rounded-[2rem] border border-amber-500/10 p-6 flex flex-col justify-between min-h-[300px] shadow-md">
          <div>
            <div className="flex items-center justify-between">
              <span className="font-mono text-[9px] tracking-widest text-amber-500/70 uppercase font-black">
                EARNINGS INDEX
              </span>
              <span className="text-amber-500 flex items-center gap-1 font-mono text-[9px] font-bold uppercase tracking-wider">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                Stable Trend
              </span>
            </div>
            <h4 className="text-white font-black text-sm font-display mt-1.5 uppercase tracking-wider">
              Cumulative Growth Curve
            </h4>
          </div>

          {/* SVG line */}
          <div className="relative h-28 w-full bg-[#050506] border border-amber-500/5 rounded-2xl flex items-center justify-center p-2 mt-4 overflow-hidden">
            <div className="absolute inset-x-2 inset-y-4 flex flex-col justify-between pointer-events-none opacity-10">
              <div className="border-b border-amber-500 w-full" />
              <div className="border-b border-amber-500 w-full" />
              <div className="border-b border-amber-500 w-full" />
            </div>

            <svg viewBox="0 0 740 150" className="w-full h-full drop-shadow-sm">
              <polyline
                fill="none"
                stroke="#f5af19"
                strokeWidth="4"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={getGraphLinePoints()}
                className="drop-shadow-[0_2px_8px_rgba(245,175,25,0.4)]"
              />
              <polygon
                fill="url(#area-gradient-dash)"
                opacity="0.1"
                points={`20,140 ${getGraphLinePoints()} 720,140`}
              />
              <defs>
                <linearGradient id="area-gradient-dash" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f5af19" />
                  <stop offset="100%" stopColor="#e65c00" stopOpacity="0" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          <div className="text-[10px] text-gray-500 mt-3 font-mono flex justify-between items-center px-1">
            <span>Historical Balance Log Matrix</span>
            <span>Refreshed live</span>
          </div>
        </div>

      </div>

      {/* 5. Ledger Real-time Audit stream */}
      <div className="bg-[#0a0a0c] rounded-[2rem] border border-amber-500/10 p-6 shadow-md">
        <div className="flex items-center justify-between mb-5 border-b border-zinc-900 pb-3">
          <div>
            <span className="font-mono text-[9px] tracking-widest text-amber-500 uppercase font-black">
              AUDIT LOG STREAM
            </span>
            <h3 className="text-base font-black text-white font-display uppercase tracking-wider mt-1">
              Recent Transactions & Payouts
            </h3>
          </div>
          
          <button
            onClick={() => onNavigate('wallet')}
            className="text-xs text-amber-500 hover:text-amber-400 font-extrabold flex items-center gap-1 uppercase tracking-wider transition"
          >
            Ledger Book <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        {/* Log rows list */}
        {activities.length === 0 ? (
          <div className="text-center py-8 text-gray-500 text-xs font-mono">
            No activities have hit the ledger gateway yet.
          </div>
        ) : (
          <div className="space-y-3">
            {activities.slice().reverse().map((act) => {
              const isWin = act.isCredit;
              
              return (
                <div 
                  key={act.id} 
                  id={`activity-${act.id}`}
                  className="flex items-center justify-between p-3.5 bg-[#050506] hover:bg-[#0c0c0e] border border-zinc-900 hover:border-amber-500/10 rounded-2xl transition duration-300 gap-4"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className={`h-9 w-9 rounded-xl flex items-center justify-center shrink-0 border ${
                      act.status === 'Pending' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                      act.status === 'Failed' ? 'bg-red-500/10 text-red-500 border-red-500/20' :
                      isWin ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'
                    }`}>
                      {act.status === 'Pending' ? (
                        <Hourglass className="h-4.5 w-4.5 animate-spin" />
                      ) : act.status === 'Failed' ? (
                        <XCircle className="h-4.5 w-4.5" />
                      ) : isWin ? (
                        <ArrowDownLeft className="h-4.5 w-4.5" />
                      ) : (
                        <ArrowUpRight className="h-4.5 w-4.5" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white truncate">{act.title}</span>
                        <span className="font-mono text-[9px] text-gray-500">({act.id})</span>
                      </div>
                      <p className="text-[10px] text-gray-400 truncate mt-0.5 leading-none">{act.details || 'Attributed ledger transaction logs'}</p>
                    </div>
                  </div>

                  <div className="flex flex-col items-end shrink-0">
                    <span className={`font-mono text-xs font-black ${
                      act.status === 'Failed' ? 'text-gray-500 line-through' :
                      isWin ? 'text-amber-400 font-extrabold' : 'text-red-400 font-extrabold'
                    }`}>
                      {isWin ? '+' : '-'}{formatNaira(act.amount)}
                    </span>
                    <span className="font-mono text-[8px] text-gray-500 mt-1 flex items-center gap-1 uppercase tracking-wider font-bold">
                      <Clock className="h-2.5 w-2.5" />
                      {act.timestamp.split(' ')[1] || act.timestamp}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
