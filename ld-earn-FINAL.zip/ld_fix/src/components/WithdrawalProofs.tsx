/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  CheckCircle2, 
  Search, 
  ExternalLink, 
  Copy, 
  Check, 
  TrendingUp, 
  Building, 
  Calendar, 
  ShieldCheck, 
  Filter, 
  Sparkles,
  Info,
  X,
  FileCheck,
  Clock
} from 'lucide-react';
import { formatNaira } from '../utils';

export interface VerifiedProof {
  id: string;
  recipient: string;
  bankName: string;
  amount: number;
  category: 'Referral' | 'Task';
  timestamp: string;
  reference: string;
  planLevel: 'Solo' | 'Premium' | 'VIP';
  accountNumberMasked: string;
  status: 'Processing' | 'Settled' | 'Confirmed';
}

// Pre-populated verified platform-wide successful payments is removed to display only real live records

export default function WithdrawalProofs() {
  const [proofs, setProofs] = useState<VerifiedProof[]>([]);
  const [flashingIds, setFlashingIds] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'All' | 'Referral' | 'Task'>('All');
  const [amountFilter, setAmountFilter] = useState<'All' | 'under10k' | '10to30k' | 'over30k'>('All');
  const [tierFilter, setTierFilter] = useState<'All' | 'Solo' | 'Premium' | 'VIP'>('All');
  const [selectedProof, setSelectedProof] = useState<VerifiedProof | null>(null);
  const [copiedRef, setCopiedRef] = useState(false);

  // Cache previously processed IDs to prevent false flashing on initial mount
  const seenIdsRef = useRef<Set<string>>(new Set());

  // Dynamic ledger polling engine
  useEffect(() => {
    const parseLatestLedger = (isFirstLoad: boolean = false) => {
      const savedGlobalWithdrawals = localStorage.getItem('naira_global_withdrawals');
      let realWithdrawals: VerifiedProof[] = [];

      if (savedGlobalWithdrawals) {
        try {
          const parsed = JSON.parse(savedGlobalWithdrawals);
          if (Array.isArray(parsed)) {
            // Include successful and pending withdrawals
            const activeOnes = parsed.filter((w: any) => w.status === 'Successful' || w.status === 'Pending');
            realWithdrawals = activeOnes.map((w: any, index: number) => {
              // Mask first name slightly
              const parts = w.fullName ? w.fullName.split(' ') : ['User'];
              const firstName = parts[0];
              const lastNameInitial = parts[1] ? `${parts[1][0]}.***` : '***';
              const maskedName = `${firstName} ${lastNameInitial}`;

              // Mask account number
              const acctNum = w.accountNumber || '0000000000';
              const maskedAcct = `******${acctNum.substring(acctNum.length - 4)}`;

              // Plan level mapping based on amount limits
              let planLevel: 'Solo' | 'Premium' | 'VIP' = 'Solo';
              if (w.amount >= 30000) {
                planLevel = 'VIP';
              } else if (w.amount >= 10000) {
                planLevel = 'Premium';
              }

              // Map status dynamically to Processing, Settled, or Confirmed
              let status: 'Processing' | 'Settled' | 'Confirmed' = 'Confirmed';
              if (w.status === 'Pending') {
                status = 'Processing';
              } else {
                status = index % 2 === 0 ? 'Confirmed' : 'Settled';
              }

              return {
                id: w.id || `WD-PROOF-REAL-${index}-${w.timestamp || ''}`,
                recipient: maskedName,
                bankName: w.bankName || 'Nigerian Bank',
                amount: Number(w.amount),
                category: w.category || 'Task',
                timestamp: w.timestamp || new Date().toISOString().replace('T', ' ').substring(0, 16),
                reference: w.txHash || `NIBSS/FT/00242606${Math.floor(10000000000000 + Math.random() * 90000000000000)}`,
                planLevel,
                accountNumberMasked: maskedAcct,
                status
              };
            });
          }
        } catch (e) {
          console.error('Failed to load real withdrawals:', e);
        }
      }

      // Detect and flag brand new transactions for visual feedback flash
      if (!isFirstLoad && realWithdrawals.length > 0) {
        const newlyAddedIds: string[] = [];
        realWithdrawals.forEach(item => {
          if (!seenIdsRef.current.has(item.id)) {
            newlyAddedIds.push(item.id);
            seenIdsRef.current.add(item.id);
          }
        });

        if (newlyAddedIds.length > 0) {
          setFlashingIds(prev => [...prev, ...newlyAddedIds]);
          // Clean up flashes after 3.5 seconds
          setTimeout(() => {
            setFlashingIds(prev => prev.filter(id => !newlyAddedIds.includes(id)));
          }, 3500);
        }
      } else if (isFirstLoad) {
        // Cache initial values so we don't flash existing data on component render
        realWithdrawals.forEach(item => seenIdsRef.current.add(item.id));
      }

      setProofs(realWithdrawals);
    };

    // Perform initial load immediately
    parseLatestLedger(true);

    // Dynamic high-perceived responsiveness polling interval (2 seconds)
    const interval = setInterval(() => {
      parseLatestLedger(false);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleCopyReference = (ref: string) => {
    navigator.clipboard.writeText(ref);
    setCopiedRef(true);
    setTimeout(() => setCopiedRef(false), 2000);
  };

  // Filter proofs
  const filteredProofs = proofs.filter(item => {
    // 1. Search term (matches name or bank or reference)
    const matchesSearch = 
      item.recipient.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.bankName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.reference.toLowerCase().includes(searchTerm.toLowerCase());

    // 2. Category filter
    const matchesCategory = categoryFilter === 'All' || item.category === categoryFilter;

    // 3. Amount bracket filter
    let matchesAmount = true;
    if (amountFilter === 'under10k') {
      matchesAmount = item.amount < 10000;
    } else if (amountFilter === '10to30k') {
      matchesAmount = item.amount >= 10000 && item.amount <= 30000;
    } else if (amountFilter === 'over30k') {
      matchesAmount = item.amount > 30000;
    }

    // 4. Tier filter
    const matchesTier = tierFilter === 'All' || item.planLevel === tierFilter;

    return matchesSearch && matchesCategory && matchesAmount && matchesTier;
  });

  // Only sum up settled or confirmed amounts
  const totalPaidSum = proofs
    .filter(item => item.status === 'Settled' || item.status === 'Confirmed')
    .reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="space-y-8 animate-fade-in" id="withdrawal-proofs-section">
      {/* Custom injected style block for the premium highlight pulse */}
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes proofHighlightPulse {
          0% {
            background-color: rgba(16, 185, 129, 0.18);
            box-shadow: inset 0 0 16px rgba(16, 185, 129, 0.22);
          }
          30% {
            background-color: rgba(16, 185, 129, 0.22);
            box-shadow: inset 0 0 24px rgba(16, 185, 129, 0.28);
          }
          100% {
            background-color: transparent;
            box-shadow: inset 0 0 0px transparent;
          }
        }
        .animate-proof-flash-row {
          animation: proofHighlightPulse 3.5s cubic-bezier(0.16, 1, 0.3, 1) forwards !important;
        }
      `}} />
      {/* Upper Title HUD */}
      <div className="bg-white rounded-2xl border border-gray-150 p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100 shadow-xs">
            <ShieldCheck className="h-6 w-6 stroke-[2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-display text-2xl font-bold text-gray-900 tracking-tight">Withdrawal Proofs</h2>
              <span className="bg-emerald-50 text-emerald-700 text-[10px] font-mono px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1 font-medium">
                <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-pulse" />
                Live Verified
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-1 max-w-xl">
              Transparent, verified proof of cashouts processed directly via Nigerian Inter-Bank Settlement System (NIBSS) instant electronic transfer rails. Click any transaction to inspect the official receipt.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs text-amber-600 bg-amber-50 px-3 py-2 rounded-xl border border-amber-100 self-start md:self-auto">
          <Info className="h-4 w-4 shrink-0 stroke-[2.2]" />
          <span>Names and account numbers are partially masked to respect privacy regulations.</span>
        </div>
      </div>

      {/* Trust Bento Grid Summary Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Stat 1 */}
        <div className="bg-white rounded-2xl border border-gray-150 p-4 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="text-gray-400 text-xs font-medium">Cumulative Paid Out</div>
          <div className="mt-2">
            <span className="text-lg sm:text-2xl font-extrabold text-gray-900 font-sans tracking-tight">
              ₦{totalPaidSum.toLocaleString()}
            </span>
          </div>
          <div className="mt-2 text-[10px] text-emerald-600 flex items-center gap-1 font-medium">
            <TrendingUp className="h-3 w-3" />
            <span>Naira Rails Settlement</span>
          </div>
        </div>

        {/* Stat 2 */}
        <div className="bg-white rounded-2xl border border-gray-150 p-4 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="text-gray-400 text-xs font-medium">Payout Success Rate</div>
          <div className="mt-2">
            <span className="text-lg sm:text-2xl font-extrabold text-emerald-600 font-sans tracking-tight">
              {proofs.length > 0 ? '100.0%' : '0.0%'}
            </span>
          </div>
          <div className="mt-2 text-[10px] text-gray-500 flex items-center gap-1">
            <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full" />
            <span>Zero transfer friction</span>
          </div>
        </div>

        {/* Stat 3 */}
        <div className="bg-white rounded-2xl border border-gray-150 p-4 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="text-gray-400 text-xs font-medium">Average Processing Speed</div>
          <div className="mt-2">
            <span className="text-lg sm:text-2xl font-extrabold text-gray-900 font-sans tracking-tight">
              {proofs.length > 0 ? '~2 Hours' : 'N/A'}
            </span>
          </div>
          <div className="mt-2 text-[10px] text-gray-500 flex items-center gap-1">
            <span>24/7 Automated processing</span>
          </div>
        </div>

        {/* Stat 4 */}
        <div className="bg-white rounded-2xl border border-gray-150 p-4 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="text-gray-400 text-xs font-medium">Verified Successful Payouts</div>
          <div className="mt-2">
            <span className="text-lg sm:text-2xl font-extrabold text-gray-900 font-sans tracking-tight">
              {proofs.length}
            </span>
          </div>
          <div className="mt-2 text-[10px] text-emerald-600 flex items-center gap-1 font-medium">
            <Sparkles className="h-3 w-3 animate-pulse" />
            <span>Synced live from ledger</span>
          </div>
        </div>
      </div>

      {/* Dynamic Filters & Search Panel */}
      <div className="bg-white rounded-2xl border border-gray-150 p-5 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input 
              type="text"
              placeholder="Search by participant name, bank, or transaction reference..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all placeholder-gray-400"
            />
          </div>

          {/* Quick Filter Info Tag */}
          <div className="flex items-center gap-1.5 text-[11px] text-gray-500 bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-100 self-start lg:self-auto">
            <Filter className="h-3.5 w-3.5 text-gray-400" />
            <span>Showing {filteredProofs.length} of {proofs.length} successful payouts</span>
          </div>
        </div>

        {/* Filters Select Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-gray-100">
          {/* Filter 1: Earning Type */}
          <div>
            <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Earning Category</label>
            <div className="flex gap-1.5 bg-gray-50 p-1 rounded-xl border border-gray-200">
              {(['All', 'Referral', 'Task'] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`flex-1 text-center py-1.5 rounded-lg text-[11px] font-medium transition-all ${
                    categoryFilter === cat 
                      ? 'bg-white text-gray-900 shadow-xs border border-gray-200' 
                      : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  {cat === 'All' ? 'All Types' : cat}
                </button>
              ))}
            </div>
          </div>

          {/* Filter 2: Amount Range */}
          <div>
            <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Payout Amount Bracket</label>
            <select
              value={amountFilter}
              onChange={(e: any) => setAmountFilter(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-1.5 text-xs text-gray-700 focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
            >
              <option value="All">All Amounts</option>
              <option value="under10k">Under ₦10,000</option>
              <option value="10to30k">₦10,000 - ₦30,000</option>
              <option value="over30k">Over ₦30,000</option>
            </select>
          </div>

          {/* Filter 3: Tier Level */}
          <div>
            <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1.5">Member Plan Level</label>
            <div className="flex gap-1.5 bg-gray-50 p-1 rounded-xl border border-gray-200">
              {(['All', 'Solo', 'Premium', 'VIP'] as const).map((tier) => (
                <button
                  key={tier}
                  onClick={() => setTierFilter(tier)}
                  className={`flex-1 text-center py-1.5 rounded-lg text-[10px] font-medium transition-all ${
                    tierFilter === tier 
                      ? 'bg-white text-gray-900 shadow-xs border border-gray-200' 
                      : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  {tier === 'All' ? 'All Tiers' : tier}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Proof Feed Table */}
      <div className="bg-white rounded-2xl border border-gray-150 overflow-hidden shadow-xs">
        {filteredProofs.length === 0 ? (
          <div className="p-12 text-center">
            <div className="h-12 w-12 rounded-full bg-gray-50 text-gray-400 flex items-center justify-center mx-auto mb-3">
              <Search className="h-6 w-6 stroke-[1.5]" />
            </div>
            <h3 className="text-sm font-semibold text-gray-900">No matching payout proofs found</h3>
            <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto">Try clearing your search query or selecting "All Amounts" under filters to expand your parameters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            {/* Desktop Table View */}
            <table className="w-full text-left border-collapse hidden md:table">
              <thead>
                <tr className="bg-gray-50 text-gray-400 text-[10px] font-bold uppercase tracking-wider border-b border-gray-100">
                  <th className="py-4 px-6">Beneficiary Info</th>
                  <th className="py-4 px-4">Amount Paid</th>
                  <th className="py-4 px-4">Source Category</th>
                  <th className="py-4 px-4">Settlement Bank</th>
                  <th className="py-4 px-4">Timestamp</th>
                  <th className="py-4 px-4 text-center">Status</th>
                  <th className="py-4 px-6 text-right">Verification</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredProofs.map((item, index) => {
                  const isNew = flashingIds.includes(item.id);
                  return (
                    <tr 
                      key={item.id} 
                      className={`transition-colors ${
                        isNew 
                          ? 'animate-proof-flash-row' 
                          : 'hover:bg-gray-50/50'
                      }`}
                    >
                      {/* Column 1: Beneficiary */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-full bg-gray-100 text-gray-700 flex items-center justify-center font-bold text-xs">
                            {item.recipient.charAt(0)}
                          </div>
                          <div>
                            <div className="font-semibold text-gray-900 text-xs flex items-center gap-1.5">
                              {item.recipient}
                              <span className={`text-[9px] font-mono font-medium px-1.5 py-0.2 rounded-full ${
                                item.planLevel === 'VIP' 
                                  ? 'bg-purple-50 text-purple-700 border border-purple-100' 
                                  : item.planLevel === 'Premium'
                                  ? 'bg-amber-50 text-amber-700 border border-amber-100'
                                  : 'bg-gray-50 text-gray-600 border border-gray-150'
                              }`}>
                                {item.planLevel}
                              </span>
                            </div>
                            <div className="text-[10px] text-gray-400 font-mono mt-0.5">{item.accountNumberMasked}</div>
                          </div>
                        </div>
                      </td>

                      {/* Column 2: Amount */}
                      <td className="py-4 px-4">
                        <span className="font-bold text-emerald-600 text-sm font-sans">
                          {formatNaira(item.amount)}
                        </span>
                      </td>

                      {/* Column 3: Category */}
                      <td className="py-4 px-4">
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                          item.category === 'Referral' 
                            ? 'bg-blue-50 text-blue-700 border border-blue-100' 
                            : 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                        }`}>
                          {item.category} Earnings
                        </span>
                      </td>

                      {/* Column 4: Settlement Bank */}
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-1.5">
                          <Building className="h-3.5 w-3.5 text-gray-400" />
                          <span className="text-xs text-gray-700 font-medium">{item.bankName}</span>
                        </div>
                      </td>

                      {/* Column 5: Timestamp */}
                      <td className="py-4 px-4">
                        <span className="text-xs text-gray-500 font-medium">{item.timestamp}</span>
                      </td>

                      {/* Column 6: Status */}
                      <td className="py-4 px-4 text-center">
                        {item.status === 'Processing' ? (
                          <div className="inline-flex items-center gap-1.5 text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-100">
                            <Clock className="h-3 w-3 animate-spin" />
                            Processing
                          </div>
                        ) : item.status === 'Settled' ? (
                          <div className="inline-flex items-center gap-1.5 text-[10px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-full border border-teal-100">
                            <CheckCircle2 className="h-3 w-3 stroke-[2.5]" />
                            Settled
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1.5 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                            <CheckCircle2 className="h-3 w-3 stroke-[2.5]" />
                            Confirmed
                          </div>
                        )}
                      </td>

                      {/* Column 7: Verification CTA */}
                      <td className="py-4 px-6 text-right">
                        <button 
                          onClick={() => setSelectedProof(item)}
                          className="inline-flex items-center gap-1 text-xs text-emerald-600 hover:text-emerald-700 font-bold hover:underline"
                        >
                          Verify Receipt
                          <ExternalLink className="h-3 w-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {/* Mobile Cards List View */}
            <div className="block md:hidden divide-y divide-gray-100">
              {filteredProofs.map((item) => {
                const isNew = flashingIds.includes(item.id);
                return (
                  <div 
                    key={item.id} 
                    className={`p-4 space-y-3 transition-colors ${
                      isNew 
                        ? 'animate-proof-flash-row' 
                        : 'hover:bg-gray-50/30'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="h-8 w-8 rounded-full bg-gray-100 text-gray-700 flex items-center justify-center font-bold text-xs">
                          {item.recipient.charAt(0)}
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900 text-xs flex items-center gap-1.5">
                            {item.recipient}
                            <span className={`text-[8.5px] font-mono px-1.5 rounded-full ${
                              item.planLevel === 'VIP' 
                                ? 'bg-purple-50 text-purple-700 border border-purple-100' 
                                : item.planLevel === 'Premium'
                                ? 'bg-amber-50 text-amber-700 border border-amber-100'
                                : 'bg-gray-50 text-gray-600 border border-gray-150'
                            }`}>
                              {item.planLevel}
                            </span>
                          </div>
                          <div className="text-[10px] text-gray-400 font-mono mt-0.5">{item.accountNumberMasked}</div>
                        </div>
                      </div>
                      <span className="font-extrabold text-emerald-600 text-sm font-sans">
                        {formatNaira(item.amount)}
                      </span>
                    </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] bg-gray-50 p-2.5 rounded-xl border border-gray-100 font-medium">
                    <div>
                      <span className="text-gray-400 block text-[9px] uppercase font-bold">Category</span>
                      <span className="text-gray-700 mt-0.5 block">{item.category} Earnings</span>
                    </div>
                    <div>
                      <span className="text-gray-400 block text-[9px] uppercase font-bold">Destination</span>
                      <span className="text-gray-700 mt-0.5 block truncate">{item.bankName}</span>
                    </div>
                    <div className="col-span-2 pt-1 border-t border-gray-150 flex items-center justify-between">
                      <span className="text-gray-400 text-[10px]">{item.timestamp}</span>
                      {item.status === 'Processing' ? (
                        <div className="flex items-center gap-1.5 text-[9.5px] font-bold text-amber-700">
                          <Clock className="h-3 w-3 animate-spin" />
                          Processing
                        </div>
                      ) : item.status === 'Settled' ? (
                        <div className="flex items-center gap-1.5 text-[9.5px] font-bold text-teal-700">
                          <CheckCircle2 className="h-3 w-3 stroke-[2.5]" />
                          Settled
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-[9.5px] font-bold text-emerald-700">
                          <CheckCircle2 className="h-3 w-3 stroke-[2.5]" />
                          Confirmed
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedProof(item)}
                    className="w-full text-center py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-xl text-xs border border-emerald-100 flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <FileCheck className="h-4 w-4" />
                    Verify Receipt Advice
                  </button>
                </div>
              );
            })}
          </div>
          </div>
        )}
      </div>

      {/* HIGH-FIDELITY OFFICIAL BANK TRANSFER ADVICE MODAL */}
      {selectedProof && (
        <div className="fixed inset-0 bg-gray-950/70 backdrop-blur-xs flex items-center justify-center z-50 p-4" id="receipt-modal-backdrop">
          <div className="bg-white rounded-3xl border border-gray-100 max-w-lg w-full overflow-hidden shadow-2xl animate-scale-up" id="receipt-modal-body">
            
            {/* Header branding band */}
            <div className="bg-gradient-to-r from-emerald-700 to-teal-800 px-6 py-5 text-white relative">
              <button 
                onClick={() => setSelectedProof(null)}
                className="absolute right-4 top-4 text-emerald-100 hover:text-white bg-emerald-850 hover:bg-emerald-900 h-8 w-8 rounded-full flex items-center justify-center transition-all border border-emerald-700"
              >
                <X className="h-4 w-4" />
              </button>
              
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 bg-white/10 rounded-xl flex items-center justify-center border border-white/20">
                  <ShieldCheck className="h-5 w-5 text-emerald-300 stroke-[2]" />
                </div>
                <div>
                  <h3 className="text-sm font-bold tracking-tight font-display text-emerald-100 uppercase">Transfer Advice</h3>
                  <p className="text-[11px] text-emerald-200 mt-0.5">Nigerian Inter-Bank Settlement System (NIBSS)</p>
                </div>
              </div>
            </div>

            {/* Official Looking Cashout Bill/Advice Receipt */}
            <div className="p-6 space-y-6">
              
              {/* Central Seal status & amount */}
              <div className="text-center py-2 space-y-2">
                {selectedProof.status === 'Processing' ? (
                  <>
                    <div className="inline-flex h-12 w-12 rounded-full bg-amber-100 border-4 border-white text-amber-600 items-center justify-center shadow-md">
                      <Clock className="h-6 w-6 stroke-[2.5] animate-spin" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold tracking-wider text-amber-700 uppercase bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
                        Processing Settlement
                      </span>
                    </div>
                  </>
                ) : selectedProof.status === 'Settled' ? (
                  <>
                    <div className="inline-flex h-12 w-12 rounded-full bg-teal-100 border-4 border-white text-teal-600 items-center justify-center shadow-md">
                      <CheckCircle2 className="h-6 w-6 stroke-[2.5]" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold tracking-wider text-teal-700 uppercase bg-teal-50 px-3 py-1 rounded-full border border-teal-200">
                        Settlement Succeeded
                      </span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="inline-flex h-12 w-12 rounded-full bg-emerald-100 border-4 border-white text-emerald-600 items-center justify-center shadow-md animate-bounce">
                      <CheckCircle2 className="h-6 w-6 stroke-[2.5]" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold tracking-wider text-emerald-700 uppercase bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                        Confirmed & Disbursed
                      </span>
                    </div>
                  </>
                )}
                <div className="pt-2 text-3xl font-extrabold text-gray-900 font-sans tracking-tight">
                  {formatNaira(selectedProof.amount)}
                </div>
                <p className="text-[10px] text-gray-400 font-mono mt-0.5">{selectedProof.timestamp}</p>
              </div>

              {/* Grid with Bank Transfer Specs */}
              <div className="bg-gray-50 rounded-2xl border border-gray-150 p-4 space-y-3.5">
                {/* Sender pool */}
                <div className="flex justify-between items-start text-xs border-b border-gray-200 pb-2.5">
                  <span className="text-gray-400 font-medium">Originating Sender</span>
                  <div className="text-right">
                    <span className="font-bold text-gray-900 block">L-DEARN SETTLEMENT POOL</span>
                    <span className="text-[10px] text-gray-400 font-mono mt-0.5">Cbn Operations Ledger / Settlement</span>
                  </div>
                </div>

                {/* Recipient Account Name */}
                <div className="flex justify-between items-start text-xs border-b border-gray-200 pb-2.5">
                  <span className="text-gray-400 font-medium">Beneficiary Participant</span>
                  <div className="text-right">
                    <span className="font-bold text-gray-900 block">{selectedProof.recipient}</span>
                    <span className="text-[10px] text-gray-500 font-mono mt-0.5">NIBSS Account Name Match</span>
                  </div>
                </div>

                {/* Destination bank & account */}
                <div className="flex justify-between items-start text-xs border-b border-gray-200 pb-2.5">
                  <span className="text-gray-400 font-medium">Destination Bank Details</span>
                  <div className="text-right">
                    <span className="font-bold text-gray-900 block">{selectedProof.bankName}</span>
                    <span className="text-[10px] text-gray-500 font-mono mt-0.5">Account: {selectedProof.accountNumberMasked}</span>
                  </div>
                </div>

                {/* Earning Category */}
                <div className="flex justify-between items-center text-xs border-b border-gray-200 pb-2.5">
                  <span className="text-gray-400 font-medium">Settlement Category</span>
                  <span className="font-bold text-gray-900 bg-gray-200 px-2.5 py-0.5 rounded-md text-[11px]">{selectedProof.category} Cashout</span>
                </div>

                {/* Session ID / NIBSS Reference */}
                <div className="flex justify-between items-start text-xs">
                  <span className="text-gray-400 font-medium">NIBSS Session ID</span>
                  <div className="text-right max-w-[200px]">
                    <span className="font-mono text-[10px] font-semibold text-gray-900 break-all leading-normal block">
                      {selectedProof.reference}
                    </span>
                    <button
                      onClick={() => handleCopyReference(selectedProof.reference)}
                      className="inline-flex items-center gap-1 text-[9.5px] font-bold text-emerald-600 hover:text-emerald-700 mt-1 cursor-pointer"
                    >
                      {copiedRef ? (
                        <>
                          <Check className="h-3 w-3 text-emerald-600" />
                          Session ID Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="h-3 w-3" />
                          Copy Session ID
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* CBN disclaimer note */}
              <div className="bg-emerald-50/50 rounded-xl border border-emerald-100 p-3.5 flex items-start gap-2.5">
                <ShieldCheck className="h-5 w-5 text-emerald-600 shrink-0 stroke-[2] mt-0.5" />
                <div className="text-[10.5px] text-emerald-800 leading-normal font-medium">
                  <strong>Regulatory Clearance Verified:</strong> This payment advice serves as authentic electronic evidence of a finished inter-bank credit transfer transaction. All transactions processed under state-level clearing codes.
                </div>
              </div>

              {/* Close Button */}
              <button
                onClick={() => setSelectedProof(null)}
                className="w-full text-center py-2.5 bg-gray-900 hover:bg-gray-800 text-white font-semibold rounded-xl text-xs transition-colors shadow-xs"
              >
                Done
              </button>

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
