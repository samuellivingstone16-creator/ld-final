/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { EarningActivity } from '../types';
import { Search, Filter, ArrowUpRight, ArrowDownLeft, FileText, Download, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Calculates current queue headway for 2-hour withdrawal compliance check
const getWithdrawalProgress = (timestampStr: string) => {
  try {
    const safeStr = timestampStr.replace(' ', 'T');
    const txTime = new Date(safeStr).getTime();
    if (isNaN(txTime)) return { percent: 15, minutesLeft: 105, stage: 1 };
    
    const now = new Date().getTime();
    const diffMs = now - txTime;
    if (diffMs <= 0) {
      return { percent: 10, minutesLeft: 120, stage: 1 };
    }
    
    const diffMins = Math.floor(diffMs / (60 * 1000));
    if (diffMins >= 120) {
      return { percent: 95, minutesLeft: 5, stage: 3 };
    }
    
    const percent = Math.min(95, Math.max(10, Math.floor((diffMins / 120) * 85) + 10));
    
    let stage = 1;
    if (percent > 70) {
      stage = 3;
    } else if (percent > 30) {
      stage = 2;
    }
    
    return { percent, minutesLeft: 120 - diffMins, stage };
  } catch (e) {
    return { percent: 25, minutesLeft: 95, stage: 1 };
  }
};

interface TransactionHistoryProps {
  activities: EarningActivity[];
}

export default function TransactionHistory({ activities }: TransactionHistoryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'All' | 'Task' | 'Referral' | 'Withdrawal' | 'Bonus'>('All');
  const [filterStatus, setFilterStatus] = useState<'All' | 'Successful' | 'Pending' | 'Failed'>('All');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'amount-high' | 'amount-low'>('newest');

  // Filter & Search Logic
  const filteredActivities = activities
    .filter((act) => {
      if (!act) return false;
      const titleStr = String(act.title || '');
      const idStr = String(act.id || '');
      const detailsStr = String(act.details || '');
      const matchesSearch = 
        titleStr.toLowerCase().includes(searchTerm.toLowerCase()) ||
        idStr.toLowerCase().includes(searchTerm.toLowerCase()) ||
        detailsStr.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesType = filterType === 'All' || act.type === filterType;
      const matchesStatus = filterStatus === 'All' || act.status === filterStatus;

      return matchesSearch && matchesType && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === 'newest') {
        return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
      }
      if (sortBy === 'oldest') {
        return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
      }
      if (sortBy === 'amount-high') {
        return b.amount - a.amount;
      }
      if (sortBy === 'amount-low') {
        return a.amount - b.amount;
      }
      return 0;
    });

  // Export simulator
  const handleExportCSV = () => {
    try {
      const headers = ['Transaction ID,Type,Title,Amount (NGN),Flow,Timestamp,Details,Status\n'];
      const rows = filteredActivities.map(act => {
        return `"${act.id}","${act.type}","${act.title.replace(/"/g, '""')}",${act.amount},"${act.isCredit ? 'CREDIT' : 'DEBIT'}","${act.timestamp}","${(act.details || '').replace(/"/g, '""')}","${act.status}"`;
      });
      const blob = new Blob([headers.concat(rows.join('\n')).join('')], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `ld_ledger_statement_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      // Quiet handled
    }
  };

  // Download single transaction printable text receipt
  const handleDownloadReceipt = (act: EarningActivity) => {
    try {
      const receiptText = `================================================
              LD NAIRAEARN TRANSACTION RECEIPT           
================================================
Transaction ID: ${act.id}
Date/Time:      ${act.timestamp}
Status:         ${act.status.toUpperCase()}
================================================
Type:           ${act.type}
Description:    ${act.title}
Detail:         ${act.details || "N/A"}
------------------------------------------------
Flow:           ${act.isCredit ? "CREDIT (+)" : "DEBIT (-)"}
Amount:         ₦${act.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
================================================
      Thank you for choosing LD NairaEarn       
      Security cleared via secure TLS 1.3       
================================================`;

      const blob = new Blob([receiptText], { type: 'text/plain;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `receipt_${act.id}.txt`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      // Quiet handled
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-150 shadow-xs p-6 sm:p-8 animate-fade-in" id="transaction-history-view">
      
      {/* Title & Stats */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between pb-6 border-b border-gray-100 gap-4">
        <div>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-green-50 text-green-700 font-mono tracking-wider uppercase mb-1">
            Realtime Audit Ledger
          </span>
          <h2 className="font-display text-2xl font-bold text-gray-900">Transaction History</h2>
          <p className="text-sm text-gray-500 mt-1">
            Review your precise earnings micro-credits and instant withdrawal cashouts.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="inline-flex items-center justify-center space-x-2 bg-gray-900 hover:bg-gray-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl cursor-pointer transition shadow-xs"
        >
          <Download className="h-4 w-4" />
          <span>Export Ledger Statement (.CSV)</span>
        </button>
      </div>

      {/* Filters bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 py-6 border-b border-gray-100">
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search reference IDs or titles..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition font-sans placeholder:text-gray-400"
          />
        </div>

        {/* Filter by Type */}
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider whitespace-nowrap">Type:</span>
          <select
            value={filterType}
            onChange={(e: any) => setFilterType(e.target.value)}
            className="w-full py-2 px-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition"
          >
            <option value="All">All Types</option>
            <option value="Task">Daily Rewards</option>
            <option value="Referral">Referral Commissions</option>
            <option value="Withdrawal">Withdrawals</option>
            <option value="Bonus">Loyalty Grants</option>
          </select>
        </div>

        {/* Filter by Status */}
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider whitespace-nowrap">Status:</span>
          <select
            value={filterStatus}
            onChange={(e: any) => setFilterStatus(e.target.value)}
            className="w-full py-2 px-3 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition"
          >
            <option value="All">All Statuses</option>
            <option value="Successful">Successful</option>
            <option value="Pending">Pending</option>
            <option value="Failed">Failed</option>
          </select>
        </div>

        {/* Sorting */}
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider whitespace-nowrap">Sort:</span>
          <select
            value={sortBy}
            onChange={(e: any) => setSortBy(e.target.value)}
            className="w-full py-2 px-3 border border-gray-250 border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="amount-high">Amount: High to Low</option>
            <option value="amount-low">Amount: Low to High</option>
          </select>
        </div>

      </div>

      {/* Transaction List Counter */}
      <div className="flex items-center justify-between py-4 text-xs font-mono text-gray-400 font-bold">
        <span>FILTERED RESULTS: {filteredActivities.length} OF {activities.length} LOGS</span>
        <span>CURRENCY: NIGERIAN NAIRA (₦)</span>
      </div>

      {/* Table Container */}
      {filteredActivities.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="h-14 w-14 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 mb-4 border border-gray-200">
            <FileText className="h-6 w-6 stroke-[1.5]" />
          </div>
          <p className="font-display font-medium text-gray-800">No transactions match your search filters.</p>
          <p className="text-xs text-gray-400 mt-1">Try resetting the parameters or look for other keywords.</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-100 text-xs text-gray-400 font-mono uppercase tracking-wider">
                <th className="py-3 px-4 font-bold">Reference ID</th>
                <th className="py-3 px-4 font-bold">Transaction / Type</th>
                <th className="py-3 px-4 font-bold">Timestamp</th>
                <th className="py-3 px-4 font-bold text-center">Status</th>
                <th className="py-3 px-4 font-bold text-right">Value (₦)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredActivities.map((act) => {
                const isCredit = act.isCredit;
                return (
                  <tr key={act.id} className="hover:bg-gray-50/55 transition group">
                    {/* ID */}
                    <td className="py-4 px-4">
                      <span className="font-mono text-xs font-bold text-gray-500 bg-gray-100 group-hover:bg-green-50 group-hover:text-green-800 transition px-2 py-1 rounded">
                        {act.id}
                      </span>
                    </td>
                    
                    {/* Title & Metadata */}
                    <td className="py-4 px-4">
                      <div>
                        <div className="text-sm font-bold text-gray-900 flex items-center space-x-1.5">
                          <span>{act.title}</span>
                        </div>
                        {act.details && (
                          <div className="text-[11px] font-sans text-gray-400 mt-1 line-clamp-2 max-w-sm sm:max-w-md md:max-w-lg lg:max-w-xl group-hover:text-gray-600 transition">
                            {act.details}
                          </div>
                        )}

                        {/* 2-Hour Progress Bar & Step Indicator for Pending Withdrawals */}
                        {act.type === 'Withdrawal' && act.status === 'Pending' && (() => {
                          const progress = getWithdrawalProgress(act.timestamp);
                          return (
                            <div className="mt-3 p-3.5 bg-slate-50/80 border border-amber-100 rounded-2xl max-w-md space-y-3 shadow-2xs select-none text-left">
                              <div className="flex items-center justify-between text-[10px] font-mono font-bold">
                                <span className="text-amber-700 flex items-center gap-1.5 uppercase">
                                  <Clock className="h-3 w-3 animate-spin" />
                                  Compliance Queue Runway
                                </span>
                                <span className="text-gray-450 font-black">
                                  {progress.minutesLeft > 0 ? `Est. ~${progress.minutesLeft}m remaining` : 'Awaiting final release'}
                                </span>
                              </div>

                              {/* Progress bar line */}
                              <div className="relative">
                                <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                                  <div 
                                    className="bg-gradient-to-r from-amber-500 to-emerald-500 h-full rounded-full transition-all duration-300"
                                    style={{ width: `${progress.percent}%` }}
                                  />
                                </div>
                                <span className="absolute -top-1.5 right-1.5 text-[8px] font-mono font-bold bg-white px-1 py-0.2 border border-gray-150 rounded text-gray-500 shadow-3xs">
                                  {progress.percent}%
                                </span>
                              </div>

                              {/* Progression stages list */}
                              <div className="grid grid-cols-3 gap-1 text-[9px] font-mono leading-tight font-black uppercase">
                                {/* Stage 1 */}
                                <div className="space-y-1">
                                  <p className="text-emerald-650 text-emerald-600 flex items-center gap-1">
                                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                                    <span>Submitted</span>
                                  </p>
                                  <p className="text-[8px] text-gray-400 font-normal font-sans text-left">NUBAN Secured</p>
                                </div>

                                {/* Stage 2 */}
                                <div className="space-y-1">
                                  <p className={`flex items-center gap-1 ${progress.stage >= 2 ? 'text-emerald-600' : 'text-amber-600 animate-pulse'}`}>
                                    <span className={`h-1.5 w-1.5 rounded-full ${progress.stage >= 2 ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`} />
                                    <span>KYC Audit</span>
                                  </p>
                                  <p className="text-[8px] text-gray-400 font-normal font-sans text-left font-sans">Compliance Vetting</p>
                                </div>

                                {/* Stage 3 */}
                                <div className="space-y-1 text-right sm:text-left">
                                  <p className={`flex items-center justify-end sm:justify-start gap-1 ${progress.stage >= 3 ? 'text-emerald-600 animate-pulse' : 'text-gray-400'}`}>
                                    <span className={`h-1.5 w-1.5 rounded-full ${progress.stage >= 3 ? 'bg-emerald-500' : 'bg-gray-300'}`} />
                                    <span>Release</span>
                                  </p>
                                  <p className="text-[8px] text-gray-400 font-normal font-sans">NIBSS Settlement</p>
                                </div>
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    </td>

                    {/* Timestamp */}
                    <td className="py-4 px-4 whitespace-nowrap">
                      <span className="text-xs font-mono font-bold text-gray-400">
                        {act.timestamp}
                      </span>
                    </td>

                    {/* Status */}
                    <td className="py-4 px-4 whitespace-nowrap text-center">
                      <div className="flex flex-col items-center justify-center gap-1.5">
                        <AnimatePresence mode="wait">
                          <motion.span
                            key={act.status}
                            initial={{ opacity: 0, scale: 0.85, y: -4 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.85, y: 4 }}
                            transition={{ duration: 0.15, ease: "easeInOut" }}
                            className={`inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono tracking-wider uppercase ${
                              act.status === 'Successful' 
                                ? 'bg-emerald-50 text-emerald-700' 
                                : act.status === 'Pending'
                                ? 'bg-amber-50 text-amber-600 animate-pulse'
                                : 'bg-red-50 text-red-600'
                            }`}
                          >
                            {act.status === 'Successful' && <CheckCircle2 className="h-3 w-3 mr-0.5" />}
                            {act.status === 'Pending' && <Clock className="h-3 w-3 mr-0.5 animate-spin" />}
                            {act.status === 'Failed' && <AlertTriangle className="h-3 w-3 mr-0.5" />}
                            {act.status}
                          </motion.span>
                        </AnimatePresence>
                        
                        {act.status === 'Successful' && (
                          <button
                            onClick={() => handleDownloadReceipt(act)}
                            className="inline-flex items-center space-x-1 text-[10px] font-bold font-mono text-emerald-600 hover:text-emerald-800 hover:underline bg-emerald-50/40 hover:bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 transition cursor-pointer"
                            id={`download-receipt-${act.id}`}
                            title="Download transaction receipt"
                          >
                            <Download className="h-2.5 w-2.5" />
                            <span>Download Receipt</span>
                          </button>
                        )}
                      </div>
                    </td>

                    {/* Amount */}
                    <td className="py-4 px-4 text-right whitespace-nowrap">
                      <span className={`font-display text-sm font-bold flex items-center justify-end ${
                        isCredit ? 'text-green-600' : 'text-rose-600'
                      }`}>
                        {isCredit ? (
                          <ArrowDownLeft className="h-3.5 w-3.5 mr-0.5" />
                        ) : (
                          <ArrowUpRight className="h-3.5 w-3.5 mr-0.5" />
                        )}
                        ₦{act.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Security note footer */}
      <div className="mt-8 pt-6 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-400 font-mono">
        <p>© LD Central Ledger. Integrity cleared by secure cryptographic postbacks.</p>
        <p className="mt-2 sm:mt-0">SECURE SHELL TLS 1.3</p>
      </div>

    </div>
  );
}
