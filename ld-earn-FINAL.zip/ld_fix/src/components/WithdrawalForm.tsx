/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { NIGERIAN_BANKS } from '../data';
import { formatNaira, PLANS, normalizePlan, PlanType } from '../utils';
import { 
  Building2, 
  HelpCircle, 
  ArrowUpRight, 
  CheckCircle, 
  AlertCircle, 
  ShieldCheck, 
  Loader2,
  Calendar,
  DollarSign,
  Clock,
  Workflow,
  AlertTriangle,
  Lock,
  ArrowRight
} from 'lucide-react';

interface WithdrawalFormProps {
  referralBalance: number;
  taskBalance: number;
  profileLevel: string;
  onInitiateWithdrawal: (amount: number, bankName: string, accountNumber: string, accountName: string, category: 'Referral' | 'Task') => Promise<boolean>;
  presetAmount?: number | null;
  presetCategory?: 'Referral' | 'Task' | null;
}

export default function WithdrawalForm({
  referralBalance,
  taskBalance,
  profileLevel,
  onInitiateWithdrawal,
  presetAmount,
  presetCategory
}: WithdrawalFormProps) {
  const [bankName, setBankName] = useState(() => {
    const saved = localStorage.getItem('naira_withdraw_bank');
    if (!saved) return NIGERIAN_BANKS[0];
    if (NIGERIAN_BANKS.includes(saved)) return saved;
    return 'Other Bank';
  });
  const [customBankName, setCustomBankName] = useState(() => {
    const saved = localStorage.getItem('naira_withdraw_bank');
    if (saved && !NIGERIAN_BANKS.includes(saved)) return saved;
    return '';
  });
  const [accountNumber, setAccountNumber] = useState(() => localStorage.getItem('naira_withdraw_account_number') || '');
  const [accountName, setAccountName] = useState(() => localStorage.getItem('naira_withdraw_account_name') || 'John Doe'); // Default user

  const resolvedBankName = bankName === 'Other Bank' ? (customBankName.trim() || 'Other Bank') : bankName;
  const isBankRecognized = NIGERIAN_BANKS.includes(bankName) || 
    (bankName === 'Other Bank' && NIGERIAN_BANKS.some(b => 
      b.toLowerCase() === customBankName.trim().toLowerCase() || 
      (b.toLowerCase().includes(customBankName.trim().toLowerCase()) && customBankName.trim().length >= 3)
    ));
  
  const [withdrawalCategory, setWithdrawalCategory] = useState<'Referral' | 'Task'>('Referral');
  const [bypassSchedule, setBypassSchedule] = useState(true); // Default override allows flexible testing of payouts

  const activePlan = normalizePlan(profileLevel);
  const planInfo = PLANS[activePlan];

  // Minimum thresholds based on chosen withdrawal category
  const minWithdrawal = withdrawalCategory === 'Referral' 
    ? planInfo.minWithdrawalRef 
    : planInfo.minWithdrawalTask;

  const maxBalanceAvailable = withdrawalCategory === 'Referral' 
    ? referralBalance 
    : taskBalance;

  const [amount, setAmount] = useState<number>(minWithdrawal);
  
  // UX states
  const [isProcessing, setIsProcessing] = useState(false);
  const [checkingStep, setCheckingStep] = useState(0); // 0=idle, 1=NIBSS check, 2=KYC matching, 3=success
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');

  // Determine current scheduled window state
  const today = new Date();
  const isWednesday = today.getDay() === 3;
  const is20th = today.getDate() === 20;

  const getScheduleStatus = () => {
    if (withdrawalCategory === 'Referral') {
      return {
        isAllowed: isWednesday,
        headline: 'Referral Withdrawal Window',
        ruleText: 'Every Wednesday only',
        currentStatus: today.toLocaleDateString('en-US', { weekday: 'long' }),
        message: 'Referral commission payouts are strictly processed every Wednesday.',
      };
    } else {
      const getOrdinal = (day: number) => {
        if (day > 3 && day < 21) return 'th';
        switch (day % 10) {
          case 1:  return "st";
          case 2:  return "nd";
          case 3:  return "rd";
          default: return "th";
        }
      };
      const formattedDate = `${today.getDate()}${getOrdinal(today.getDate())}`;
      return {
        isAllowed: is20th,
        headline: 'Task Withdrawal Window',
        ruleText: 'Every 20th of the month only',
        currentStatus: formattedDate,
        message: 'Daily task earnings payouts are strictly processed on the 20th of each month.',
      };
    }
  };

  const scheduleInfo = getScheduleStatus();
  const isScheduleAuthorized = scheduleInfo.isAllowed || bypassSchedule;

  // Sync amount on category change & preset availability
  useEffect(() => {
    if (presetAmount !== undefined && presetAmount !== null && presetCategory !== undefined && presetCategory !== null) {
      if (withdrawalCategory === presetCategory) {
        setAmount(presetAmount);
      } else {
        setAmount(minWithdrawal);
      }
    } else {
      setAmount(minWithdrawal);
    }
  }, [withdrawalCategory, minWithdrawal, presetAmount, presetCategory]);

  // Synchronize category if changed from parent
  useEffect(() => {
    if (presetCategory) {
      setWithdrawalCategory(presetCategory);
    }
  }, [presetCategory]);

  const setWithdrawalError = (msg: string) => {
    setFormError(msg);
    if (msg) {
      window.dispatchEvent(new CustomEvent('balance-shake'));
    }
  };

  const handleWithdrawalRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');

    // Schedulers validation
    if (!isScheduleAuthorized) {
      setWithdrawalError(`Withdrawal Locked: ${scheduleInfo.message} Today is ${scheduleInfo.currentStatus}. Please enable the "Override Schedule Lock" to test this payout flow.`);
      return;
    }

    // Validations
    if (bankName === 'Other Bank' && !customBankName.trim()) {
       setWithdrawalError('Please enter a custom bank name.');
       return;
    }

    const nubanRegex = /^[0-9]{10}$/;
    if (!nubanRegex.test(accountNumber)) {
       setWithdrawalError('Invalid Account Number: Must be a NIBSS-compliant, 10-digit numeric NUBAN.');
       return;
    }

    if (!accountName.trim()) {
       setWithdrawalError('Please enter the exact Account Name bound to this bank account.');
       return;
    }

    if (amount < minWithdrawal) {
       setWithdrawalError(`The minimum payout amount for ${withdrawalCategory} withdrawal under the ${planInfo.label} is ₦${minWithdrawal.toLocaleString()}. You requested ₦${amount.toLocaleString()}.`);
       return;
    }

    if (amount > maxBalanceAvailable) {
       setWithdrawalError(`Insufficient funds in selected category. Your active ${withdrawalCategory} Earnings balance is ${formatNaira(maxBalanceAvailable)}, but you requested ${formatNaira(amount)}.`);
       return;
    }

    // Trigger simulation progression
    setIsProcessing(true);
    setCheckingStep(1);

    // Step 1: Querying NIBSS database
    await new Promise(resolve => setTimeout(resolve, 1000));
    setCheckingStep(2);

    // Step 2: KYC profile linking match
    await new Promise(resolve => setTimeout(resolve, 1200));
    setCheckingStep(3);

    // Step 3: API transfer output
    const success = await onInitiateWithdrawal(amount, resolvedBankName, accountNumber, accountName, withdrawalCategory);

    setIsProcessing(false);
    setCheckingStep(0);

    if (success) {
      setFormSuccess(`Payout Request for ${formatNaira(amount)} has been queued! Settlement has been safely routed to ${resolvedBankName} and is currently undergoing the mandatory automated 2-hour compliance and anti-fraud KYC review pipeline.`);
      localStorage.setItem('naira_withdraw_bank', bankName === 'Other Bank' ? customBankName.trim() : bankName);
      localStorage.setItem('naira_withdraw_account_number', accountNumber);
      localStorage.setItem('naira_withdraw_account_name', accountName);
      setAccountNumber('');
      setAmount(minWithdrawal);
    } else {
      setWithdrawalError('A routing communication block occurred. Please try again.');
    }
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-5xl mx-auto" id="withdrawal-panel-stage">
      
      {/* Overview Intro with stunning, high-contrast status banners */}
      <div className="text-center max-w-2xl mx-auto select-none space-y-3">
        <div className="inline-flex items-center gap-2 bg-emerald-50 border border-emerald-200/60 px-3 py-1 rounded-full text-[10px] font-bold text-emerald-850 uppercase font-mono tracking-wider shadow-2xs">
          <Clock className="h-3 w-3 text-emerald-600 animate-pulse" />
          <span>Automated Compliance Queue Load: Normal</span>
          <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-ping" />
        </div>
        <h2 className="text-3xl font-black tracking-tight text-gray-950 font-display">
          Direct Bank Cashout Terminal
        </h2>
        <p className="text-sm text-gray-500 font-sans leading-relaxed">
          Instantly request to liquidate your earned balances. All handshakes undergo secure central checks to settle securely into any target commercial bank in Nigeria.
        </p>
      </div>

      {/* Modern Clearance Flow Indicator Runway (Stunning Stepper Layout) */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-950 text-white rounded-3xl p-6 border border-slate-800 shadow-md">
        <label className="block text-[9px] font-black uppercase tracking-widest text-emerald-400 font-mono mb-4 text-center">
          ⚡ Standard Settlement Runway Sequence
        </label>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
          
          {/* Step 1 */}
          <div className="flex items-start gap-3.5 relative z-10">
            <div className="h-9 w-9 bg-emerald-600/10 border border-emerald-500/40 text-emerald-400 rounded-xl flex items-center justify-center font-bold text-sm font-mono shrink-0 shadow-2xs">
              01
            </div>
            <div>
              <h5 className="text-xs font-bold text-white uppercase tracking-wide font-mono">Transfer Setup</h5>
              <p className="text-[10px] text-gray-400 mt-1 leading-snug">
                Submit your verified 10-digit NUBAN number, legal recipient name, and preferred Nigerian bank.
              </p>
            </div>
          </div>

          {/* Connection arrow 1 (md only) */}
          <div className="hidden md:flex absolute left-[30%] top-4 text-slate-800 pointer-events-none">
            <ArrowRight className="h-4 w-4 animate-pulse text-emerald-500/40" />
          </div>

          {/* Step 2 */}
          <div className="flex items-start gap-3.5 relative z-10 bg-slate-950/60 p-3 rounded-2xl border border-emerald-550/40 border-emerald-500/25 ring-1 ring-emerald-500/10">
            <div className="h-9 w-9 bg-emerald-500 text-slate-950 rounded-xl flex items-center justify-center font-bold text-sm font-mono shrink-0 shadow-xs">
              02
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h5 className="text-xs font-bold text-emerald-400 uppercase tracking-wide font-mono">Compliance Audit Queue</h5>
                <span className="px-1.5 py-0.5 bg-emerald-400/20 text-emerald-300 text-[8px] font-extrabold uppercase rounded font-mono">2-Hour Window</span>
              </div>
              <p className="text-[10px] text-gray-300 mt-1 leading-snug">
                Our strict automated processors and anti-fraud filters review campaign tasks to trigger bank dispatch codes.
              </p>
            </div>
          </div>

          {/* Connection arrow 2 (md only) */}
          <div className="hidden md:flex absolute left-[64%] top-4 text-slate-800 pointer-events-none">
            <ArrowRight className="h-4 w-4 animate-pulse text-emerald-500/40" />
          </div>

          {/* Step 3 */}
          <div className="flex items-start gap-3.5 relative z-10">
            <div className="h-9 w-9 bg-slate-800 text-slate-400 border border-slate-700 rounded-xl flex items-center justify-center font-bold text-sm font-mono shrink-0 shadow-2xs">
              03
            </div>
            <div>
              <h5 className="text-xs font-bold text-gray-300 uppercase tracking-wide font-mono">NIBSS Settlement Release</h5>
              <p className="text-[10px] text-gray-400 mt-1 leading-snug">
                Authorized credits are released via commercial bank gateways directly into your physical ledger balance.
              </p>
            </div>
          </div>

        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        
        {/* Form area: Left column */}
        <div className="md:col-span-7 bg-white rounded-3xl border border-gray-150 p-6 sm:p-8 shadow-xs">
          {isProcessing ? (
            /* Simulation Stepper Loader */
            <div className="py-20 text-center space-y-6 animate-scale-in">
              <Loader2 className="h-12 w-12 text-emerald-600 animate-spin mx-auto" />
              
              <div className="space-y-2">
                <p className="text-base font-black text-slate-900 font-mono uppercase tracking-wide">
                  {checkingStep === 1 ? 'Quering NIBSS Gateway...' : 
                   checkingStep === 2 ? 'Verifying NUBAN Registry...' : 
                   'Securing Bank Payout Handshakes!'}
                </p>
                <p className="text-xs text-gray-500 max-w-xs mx-auto leading-relaxed">
                  Analyzing bank clearing details for target <span className="font-mono font-bold text-slate-900">{accountNumber}</span> against federal inter-bank routing standards...
                </p>
              </div>

              {/* Progress bars indicator */}
              <div className="flex justify-center items-center gap-2 text-xs text-gray-400 font-mono">
                <span className={`h-2.5 w-16 rounded-full transition-all duration-300 ${checkingStep >= 1 ? 'bg-emerald-500 shadow-xs' : 'bg-gray-100'}`} />
                <span className={`h-2.5 w-16 rounded-full transition-all duration-300 ${checkingStep >= 2 ? 'bg-emerald-500 shadow-xs' : 'bg-gray-100'}`} />
                <span className={`h-2.5 w-16 rounded-full transition-all duration-300 ${checkingStep >= 3 ? 'bg-emerald-500 shadow-xs' : 'bg-gray-100'}`} />
              </div>
            </div>
          ) : (
            <form onSubmit={handleWithdrawalRequest} className="space-y-6">
              
              {/* Cashout Source Category Grid */}
              <div className="p-1 bg-gray-50 border border-gray-200/80 rounded-2xl">
                <span className="block text-[9px] font-black uppercase tracking-wider text-gray-400 font-mono mb-1.5 px-3 pt-2">
                  Select Payout Source Category
                </span>
                
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setWithdrawalCategory('Referral')}
                    className={`p-3.5 rounded-xl border text-center transition cursor-pointer flex flex-col justify-center items-center ${
                      withdrawalCategory === 'Referral'
                        ? 'bg-white border-emerald-500 text-emerald-950 font-bold shadow-xs ring-1 ring-emerald-500/10'
                        : 'bg-transparent border-transparent text-gray-400 hover:text-gray-700'
                    }`}
                  >
                    <span className="text-[9px] font-mono tracking-wider block uppercase font-bold">Referral Wallet</span>
                    <span className="text-base font-black text-gray-900 mt-1">{formatNaira(referralBalance)}</span>
                    <span className="text-[8px] text-gray-450 block mt-0.5">(Min: {formatNaira(planInfo.minWithdrawalRef)})</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setWithdrawalCategory('Task')}
                    className={`p-3.5 rounded-xl border text-center transition cursor-pointer flex flex-col justify-center items-center ${
                      withdrawalCategory === 'Task'
                        ? 'bg-white border-emerald-500 text-emerald-950 font-bold shadow-xs ring-1 ring-emerald-500/10'
                        : 'bg-transparent border-transparent text-gray-400 hover:text-gray-700'
                    }`}
                  >
                    <span className="text-[9px] font-mono tracking-wider block uppercase font-bold">Task Wallet</span>
                    <span className="text-base font-black text-gray-900 mt-1">{formatNaira(taskBalance)}</span>
                    <span className="text-[8px] text-gray-450 block mt-0.5">(Min: {formatNaira(planInfo.minWithdrawalTask)})</span>
                  </button>
                </div>
              </div>

              {/* Real-time Schedule Status Banner */}
              <div className={`p-4 rounded-xl border flex flex-col gap-2 transition duration-200 ${
                scheduleInfo.isAllowed
                  ? 'bg-emerald-50/50 border-emerald-150 text-emerald-950'
                  : 'bg-amber-50/70 border-amber-200 text-slate-800'
              }`}>
                <div className="flex items-start gap-3">
                  <Calendar className={`h-4.5 w-4.5 mt-0.5 shrink-0 ${scheduleInfo.isAllowed ? 'text-emerald-600' : 'text-amber-600'}`} />
                  <div className="space-y-0.5 select-none text-left">
                    <p className="text-xs font-black uppercase tracking-wider font-mono flex items-center gap-2">
                      <span>{scheduleInfo.headline}</span>
                      {scheduleInfo.isAllowed ? (
                        <span className="px-1.5 py-0.5 bg-emerald-500 text-white text-[8px] rounded font-black font-mono tracking-normal animate-pulse">OPEN</span>
                      ) : (
                        <span className="px-1.5 py-0.5 bg-amber-500 text-white text-[8px] rounded font-black font-mono tracking-normal">NEXT WEDNESDAY / 20TH</span>
                      )}
                    </p>
                    <p className="text-[11px] leading-relaxed text-gray-600">
                      {scheduleInfo.message} Today is <strong className="font-bold text-gray-900">{scheduleInfo.currentStatus}</strong>.
                    </p>
                  </div>
                </div>


              </div>

              {formSuccess && (
                <div className="p-4 bg-emerald-50 border border-emerald-150 rounded-2xl flex items-start gap-3.5 text-xs text-emerald-900 animate-scale-in">
                  <CheckCircle className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">{formSuccess}</p>
                </div>
              )}

              {formError && (
                <div className="p-4 bg-red-50 border border-red-155 rounded-2xl flex items-start gap-3.5 text-xs text-red-700 animate-scale-in">
                  <AlertCircle className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">{formError}</p>
                </div>
              )}

              {/* Bank Selection Dropdown and Account Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Select bank dropdown */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-[10px] font-black uppercase tracking-wider text-gray-500 font-mono select-none text-left">
                      Select Nigerian Bank *
                    </label>
                    {isBankRecognized ? (
                      <span className="inline-flex items-center gap-1 text-[9px] font-extrabold text-emerald-600 font-mono uppercase bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100 animate-fade-in">
                        <CheckCircle className="h-2.5 w-2.5" />
                        NIBSS Recognized
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[9px] font-extrabold text-amber-500 font-mono uppercase bg-amber-50 px-2 py-0.5 rounded-md border border-amber-150 animate-fade-in">
                        <AlertTriangle className="h-2.5 w-2.5" />
                        Custom Route
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <select
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      className="w-full px-3.5 py-2 text-xs bg-gray-50 hover:bg-gray-100/60 text-slate-900 border border-gray-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/10 transition appearance-none h-11 pr-8 cursor-pointer"
                    >
                      {NIGERIAN_BANKS.map((b) => (
                        <option key={b} value={b}>{b}</option>
                      ))}
                      <option value="Other Bank">Other Bank (Custom routing)</option>
                    </select>
                    <div className="absolute inset-y-0 right-3.5 flex items-center pointer-events-none text-gray-400 text-[10px]">
                      ▼
                    </div>
                  </div>
                </div>

                {/* Account Number */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-[10px] font-black uppercase tracking-wider text-gray-500 font-mono select-none text-left">
                      Account Number *
                    </label>
                    {accountNumber && (
                      /^[0-9]{10}$/.test(accountNumber) ? (
                        <span className="text-[9px] font-extrabold text-emerald-600 font-mono bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-md uppercase animate-fade-in flex items-center gap-1">
                          <CheckCircle className="h-2.5 w-2.5" /> Format Valid
                        </span>
                      ) : (
                        <span className="text-[9px] font-extrabold text-amber-500 font-mono bg-amber-50 border border-amber-100 px-2 py-0.5 rounded-md uppercase animate-pulse flex items-center gap-1">
                          <AlertCircle className="h-2.5 w-2.5" /> Needs {10 - accountNumber.length} digits
                        </span>
                      )
                    )}
                  </div>
                  <input
                    type="text"
                    required
                    maxLength={10}
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ''))}
                    placeholder="e.g. 0122345091"
                    className={`w-full px-3.5 py-2 text-xs font-mono bg-gray-50 border rounded-xl focus:outline-none focus:ring-1 transition h-11 ${
                      accountNumber 
                        ? /^[0-9]{10}$/.test(accountNumber)
                          ? 'border-emerald-500 focus:border-emerald-600 focus:ring-emerald-500/10'
                          : 'border-amber-350 focus:border-amber-500 focus:ring-amber-500/10'
                        : 'border-gray-200 focus:border-emerald-500 focus:ring-emerald-500/10'
                    }`}
                  />
                </div>

              </div>

              {/* Conditional input for Custom Bank name when "Other Bank" selected */}
              {bankName === 'Other Bank' && (
                <div className="p-4 bg-amber-50/20 border border-amber-200/50 rounded-2xl space-y-2 animate-scale-in text-left">
                  <div className="flex items-center justify-between">
                    <label className="block text-[10px] font-black uppercase tracking-wider text-amber-850 font-mono select-none text-left">
                      Enter Custom Bank Name *
                    </label>
                    {customBankName.trim() && (
                      isBankRecognized ? (
                        <span className="inline-flex items-center gap-1 text-[9px] font-extrabold text-emerald-600 font-mono uppercase bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100 animate-fade-in">
                          <CheckCircle className="h-2.5 w-2.5" /> matches standard
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[9px] font-extrabold text-amber-500 font-mono uppercase bg-amber-50 px-2 py-0.5 rounded-md border border-amber-100 animate-fade-in">
                          <HelpCircle className="h-2.5 w-2.5" /> Custom Route
                        </span>
                      )
                    )}
                  </div>
                  <input
                    type="text"
                    required
                    value={customBankName}
                    onChange={(e) => setCustomBankName(e.target.value)}
                    placeholder="e.g. Providus Bank"
                    className="w-full px-3.5 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/10 transition h-11"
                  />
                  <p className="text-[10px] text-gray-500 font-sans leading-relaxed text-left">
                    Since you've specified a custom route, compliance security checks may take slightly longer than the usual 2-hour window.
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Account Name */}
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-gray-500 font-mono mb-1.5 select-none text-left">
                    Verified Account Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={accountName}
                    onChange={(e) => setAccountName(e.target.value)}
                    placeholder="John Doe"
                    className="w-full px-3.5 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/10 transition h-11"
                  />
                </div>

                {/* Amount */}
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-wider text-gray-500 font-mono mb-1.5 select-none text-left">
                    Withdrawal Amount (₦) *
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-3.5 flex items-center pr-1 text-gray-400 text-xs font-mono font-bold">₦</span>
                    <input
                      type="number"
                      required
                      min={minWithdrawal}
                      step={500}
                      value={amount}
                      onChange={(e) => setAmount(Number(e.target.value))}
                      className="w-full pl-7 pr-3.5 py-2 text-xs font-mono font-bold text-gray-1000 border border-gray-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/10 transition h-11"
                    />
                  </div>
                </div>

              </div>

              <button
                type="submit"
                disabled={!isScheduleAuthorized}
                className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl text-xs font-bold transition-all duration-200 cursor-pointer shadow-md active:scale-[0.98] ${
                  isScheduleAuthorized
                    ? "bg-slate-950 text-white hover:bg-emerald-600 hover:text-white hover:shadow-emerald-600/10"
                    : "bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed"
                }`}
              >
                <ArrowUpRight className="h-4.5 w-4.5" />
                <span>{isScheduleAuthorized ? "Queue Direct Bank Clearance" : "Payout Schedule Is Lock Today"}</span>
              </button>
            </form>
          )}
        </div>

        {/* Sidebar Info: Right column */}
        <div className="md:col-span-5 bg-gray-50 border border-gray-150 rounded-3xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <span className="font-mono text-[9px] font-black text-gray-400 uppercase tracking-widest leading-none block select-none">
              WITHDRAWAL POLICY & PARAMETERS
            </span>
            <h4 className="text-sm font-bold text-gray-950 font-display">
              Anti-Fraud Vetting Guidelines
            </h4>

            <div className="space-y-4 text-xs text-gray-500 leading-relaxed font-sans">
              
              <div className="flex gap-2.5">
                <span className="h-5 w-5 bg-white rounded-full border border-gray-200 text-gray-700 flex items-center justify-center text-[10px] font-bold font-mono shrink-0 shadow-3xs">1</span>
                <div>
                  <p className="font-bold text-gray-800 leading-none">Plan Payout Thresholds</p>
                  <p className="text-[10.5px] text-gray-450 mt-1 leading-normal">
                    As a <strong className="text-emerald-700">{planInfo.label}</strong> member, you must reach at least <strong className="text-gray-800">{formatNaira(planInfo.minWithdrawalRef)}</strong> to withdraw Referral Commissions, and <strong className="text-gray-800">{formatNaira(planInfo.minWithdrawalTask)}</strong> to withdraw Daily Task Earnings.
                  </p>
                </div>
              </div>

              <div className="flex gap-2.5">
                <span className="h-5 w-5 bg-white rounded-full border border-gray-200 text-gray-700 flex items-center justify-center text-[10px] font-bold font-mono shrink-0 shadow-3xs">2</span>
                <div>
                  <p className="font-bold text-gray-800 leading-none">Withdrawal Scheduling Days</p>
                  <p className="text-[10.5px] text-gray-450 mt-1 leading-normal">
                    • <strong className="text-gray-800">Referral Commissions:</strong> Every <strong className="text-emerald-600">Wednesday</strong> only.<br />
                    • <strong className="text-gray-800">Daily Task Earnings:</strong> Every <strong className="text-emerald-600">20th of the month</strong> only.
                  </p>
                </div>
              </div>

              <div className="flex gap-2.5">
                <span className="h-5 w-5 bg-white rounded-full border border-gray-200 text-gray-700 flex items-center justify-center text-[10px] font-bold font-mono shrink-0 shadow-3xs">3</span>
                <div>
                  <p className="font-bold text-gray-800 leading-none">2-Hour Settlement Window</p>
                  <p className="text-[10.5px] text-gray-450 mt-1 leading-normal">
                    Every initiated bank payout transaction is validated and cleared by compliance security checkpoints within a strict **2-hour processing queue**. Live notification dispatch is triggered as soon as clearance succeeds.
                  </p>
                </div>
              </div>

              <div className="flex gap-2.5">
                <span className="h-5 w-5 bg-white rounded-full border border-gray-200 text-gray-700 flex items-center justify-center text-[10px] font-bold font-mono shrink-0 shadow-3xs">4</span>
                <div>
                  <p className="font-bold text-gray-800 leading-none">Strict Unique NUBAN Rule</p>
                  <p className="text-[10.5px] text-gray-450 mt-1 leading-normal">
                    To prevent fraudulent farming and duplicate user profiles, linking identical bank accounts across multiple profiles triggers immediate automated system freeze alerts.
                  </p>
                </div>
              </div>

            </div>
          </div>

          <div className="bg-white p-4 border border-gray-150 rounded-2xl flex items-start gap-2.5 shadow-2xs">
            <Lock className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-emerald-800 leading-none">256-Bit Bank Level Encryption</p>
              <p className="text-[10px] text-gray-400 mt-1 leading-normal">
                NUBAN validation and API payload calls are transmitted over premium TLS 1.3 tunnels, protecting end-to-end user ledger and payout privacy.
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
