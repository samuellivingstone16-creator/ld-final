/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ReferralUser } from '../types';
import { formatNaira, PLANS, normalizePlan } from '../utils';
import { 
  Users, 
  Copy, 
  Check, 
  UserPlus, 
  Share2, 
  Sparkles, 
  CheckCircle2, 
  Trash2,
  TrendingUp,
  Mail,
  ShieldCheck,
  AlertCircle,
  QrCode,
  Edit2,
  Save,
  Clock,
  Send,
  MessageSquare,
  Award,
  X,
  ExternalLink,
  Trophy,
  Medal,
  Search,
  Filter,
  ArrowUpDown
} from 'lucide-react';
import { motion } from 'motion/react';

interface ReferralSystemProps {
  referralsList: ReferralUser[];
  totalReferrals: number;
  totalReferralEarnings: number;
  onSimulateInvite: (fullName: string, email: string) => void;
  onUpdateReferralStatus?: (id: string, newStatus: 'Active' | 'Pending' | 'Flagged') => void;
  onDeleteReferral?: (id: string) => void;
  profileLevel?: string;
}

export default function ReferralSystem({
  referralsList,
  totalReferrals,
  totalReferralEarnings,
  onSimulateInvite,
  onUpdateReferralStatus,
  onDeleteReferral,
  profileLevel,
}: ReferralSystemProps) {
  const activePlan = normalizePlan(profileLevel);
  const inviteRewardAmount = PLANS[activePlan].refPaid;

  // Dynamic top 5 leaderboard calculations
  const leaderboardData = React.useMemo(() => {
    const DEFAULT_CHAMPIONS = [
      { name: 'Chidi Amadi', count: 142, level: '👑 Elite Ambassador', initials: 'CA', email: 'chidi@naraearn.com' },
      { name: 'Fatima Umar', count: 98, level: '⭐ Platinum Partner', initials: 'FU', email: 'fatima@naraearn.com' },
      { name: 'Olumide Adebayo', count: 76, level: '🔥 Gold Inviter', initials: 'OA', email: 'olumide@naraearn.com' },
      { name: 'Blessing Paul', count: 59, level: '✨ RISING STAR', initials: 'BP', email: 'blessing@naraearn.com' },
      { name: 'Ngozi Okoye', count: 44, level: '⚡ ACTIVE PIONEER', initials: 'NO', email: 'ngozi@naraearn.com' },
    ];

    let databaseAccounts: any[] = [];
    try {
      const stored = localStorage.getItem('ld_accounts_database');
      if (stored) {
        databaseAccounts = JSON.parse(stored);
      }
    } catch (e) {
      console.error('Error parsing accounts database for leaderboard:', e);
    }

    const currentEmail = localStorage.getItem('naira_profile_email') || '';
    const currentUserName = localStorage.getItem('naira_profile_name') || 'You';

    const mappedUsers = databaseAccounts.map(acc => {
      const count = acc.totalReferrals || (acc.referralsList ? acc.referralsList.length : 0) || 0;
      const earnings = acc.referralEarnings || 0;
      let level = '⭐ Platinum Partner';
      if (count >= 100) level = '👑 Elite Ambassador';
      else if (count >= 50) level = '👑 Premium Partner';
      else if (count >= 15) level = '🔥 Gold Inviter';
      else if (count >= 5) level = '✨ RISING STAR';
      else level = '🌱 Active Pioneer';

      const nameParts = (acc.fullName || 'User').split(' ');
      const initials = nameParts.length > 1 
        ? (nameParts[0][0] + nameParts[1][0]).toUpperCase()
        : (nameParts[0][0] + (nameParts[0][1] || '')).toUpperCase();

      return {
        name: acc.fullName || 'Anonymous User',
        email: acc.email,
        count: count,
        level: level,
        initials: initials || 'US',
        earnings: earnings || (count * inviteRewardAmount),
        isCurrentUser: acc.email?.toLowerCase() === currentEmail.toLowerCase()
      };
    });

    const hasCurrentUser = mappedUsers.some(u => u.isCurrentUser);
    if (!hasCurrentUser && currentEmail) {
      let level = '⭐ Platinum Partner';
      if (totalReferrals >= 100) level = '👑 Elite Ambassador';
      else if (totalReferrals >= 50) level = '👑 Premium Partner';
      else if (totalReferrals >= 15) level = '🔥 Gold Inviter';
      else if (totalReferrals >= 5) level = '✨ RISING STAR';
      else level = '🌱 Active Pioneer';

      const nameParts = currentUserName.split(' ');
      const initials = nameParts.length > 1 
        ? (nameParts[0][0] + nameParts[1][0]).toUpperCase()
        : (nameParts[0][0] + (nameParts[0][1] || '')).toUpperCase();

      mappedUsers.push({
        name: currentUserName,
        email: currentEmail,
        count: totalReferrals,
        level: level,
        initials: initials || 'YO',
        earnings: totalReferralEarnings,
        isCurrentUser: true
      });
    }

    const combinedList = [...mappedUsers];

    DEFAULT_CHAMPIONS.forEach(champ => {
      const alreadyExists = combinedList.some(u => u.name.toLowerCase() === champ.name.toLowerCase());
      if (!alreadyExists) {
        combinedList.push({
          name: champ.name,
          email: champ.email,
          count: champ.count,
          level: champ.level,
          initials: champ.initials,
          earnings: champ.count * inviteRewardAmount,
          isCurrentUser: false
        });
      }
    });

    // Sort by count descending
    combinedList.sort((a, b) => b.count - a.count);

    return combinedList.slice(0, 5).map((user, idx) => {
      let badge = '';
      if (idx === 0) badge = '🥇';
      else if (idx === 1) badge = '🥈';
      else if (idx === 2) badge = '🥉';

      return {
        ...user,
        rank: idx + 1,
        badge: badge
      };
    });
  }, [referralsList, totalReferrals, totalReferralEarnings, inviteRewardAmount]);

  const [friendName, setFriendName] = useState('');
  const [friendEmail, setFriendEmail] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  const [isCodeCopied, setIsCodeCopied] = useState(false);
  const [simulationSuccess, setSimulationSuccess] = useState('');
  const [simulationError, setSimulationError] = useState('');

  // Search, filter, and sorting states for referral list
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Pending' | 'Flagged'>('All');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'commission_high' | 'commission_low'>('newest');
  
  // Track nudge notifications state
  const [nudgedUsers, setNudgedUsers] = useState<{ [key: string]: 'idle' | 'sending' | 'sent' }>({});

  // Active status edit selector open per user row
  const [editingRowStatusId, setEditingRowStatusId] = useState<string | null>(null);

  // Processed filtered and sorted referral list
  const filteredAndSortedList = React.useMemo(() => {
    let result = [...referralsList];

    // Search filter
    if (searchTerm.trim()) {
      const query = searchTerm.toLowerCase().trim();
      result = result.filter(
        u => u.fullName.toLowerCase().includes(query) || u.email.toLowerCase().includes(query)
      );
    }

    // Status filter
    if (statusFilter !== 'All') {
      result = result.filter(u => u.status === statusFilter);
    }

    // Sorting
    result.sort((a, b) => {
      if (sortBy === 'newest') {
        return new Date(b.joinedDate || 0).getTime() - new Date(a.joinedDate || 0).getTime();
      }
      if (sortBy === 'oldest') {
        return new Date(a.joinedDate || 0).getTime() - new Date(b.joinedDate || 0).getTime();
      }
      if (sortBy === 'commission_high') {
        return (b.commissionEarned || 0) - (a.commissionEarned || 0);
      }
      if (sortBy === 'commission_low') {
        return (a.commissionEarned || 0) - (b.commissionEarned || 0);
      }
      return 0;
    });

    return result;
  }, [referralsList, searchTerm, statusFilter, sortBy]);

  // Export referrals list as CSV
  const handleExportCSV = () => {
    try {
      const headers = ['Full Name', 'Email', 'Date Joined', 'Commission Earned (NGN)', 'Status'];
      const rows = referralsList.map(u => [
        `"${u.fullName.replace(/"/g, '""')}"`,
        `"${u.email.replace(/"/g, '""')}"`,
        `"${u.joinedDate}"`,
        u.commissionEarned,
        `"${u.status}"`
      ]);
      const csvContent = [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `naraearn_referrals_${new Date().toISOString().slice(0,10)}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      console.error('Failed to export csv:', e);
    }
  };

  const handleSimulateNudge = (id: string, fullName: string) => {
    setNudgedUsers(prev => ({ ...prev, [id]: 'sending' }));
    setTimeout(() => {
      setNudgedUsers(prev => ({ ...prev, [id]: 'sent' }));
      // Set a reset after a short period to make it triggerable again
      setTimeout(() => {
        setNudgedUsers(prev => ({ ...prev, [id]: 'idle' }));
      }, 5000);
    }, 1200);
  };

  // Chart configuration states
  const [chartView, setChartView] = useState<'count' | 'earnings'>('count');
  const [hoveredBarIndex, setHoveredBarIndex] = useState<number | null>(null);

  // Process monthly data for the chart
  const monthlyData = React.useMemo(() => {
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const now = new Date();
    
    // Create list of the last 6 months
    const list = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const year = d.getFullYear();
      const monthIndex = d.getMonth();
      const label = `${monthNames[monthIndex]} '${String(year).substring(2)}`;
      const key = `${year}-${String(monthIndex + 1).padStart(2, '0')}`; // e.g. "2026-06"
      list.push({ key, label, count: 0, earnings: 0 });
    }

    // Populate with real data from referralsList
    referralsList.forEach(user => {
      if (!user.joinedDate) return;
      const key = user.joinedDate.substring(0, 7); // e.g. "2026-06"
      const match = list.find(m => m.key === key);
      if (match) {
        match.count += 1;
        match.earnings += user.commissionEarned || 500;
      }
    });

    return list;
  }, [referralsList]);

  // Unique Referral Configuration State
  const [refSlug, setRefSlug] = useState(() => {
    const saved = localStorage.getItem('ld_user_ref_slug');
    if (saved) return saved;
    
    // Generate code from Profile Name or Email
    const officialName = localStorage.getItem('naira_profile_name') || 'John Doe';
    let clean = officialName
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '-')
      .replace(/-+/g, '-')
      .replace(/(^-|-$)/g, '');
    
    if (!clean || clean === 'john-doe') {
      const email = localStorage.getItem('naira_profile_email') || '';
      if (email) {
        clean = email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '-');
      }
    }
    
    // Append a distinct, unique sequence ID
    const savedCode = localStorage.getItem('ld_user_ref_code') || Math.floor(1000 + Math.random() * 9000).toString();
    const result = `${clean || 'user'}-${savedCode}`;
    localStorage.setItem('ld_user_ref_slug', result.toUpperCase());
    localStorage.setItem('ld_user_ref_code', savedCode);
    return result.toUpperCase();
  });

  const [refCode, setRefCode] = useState(() => {
    const saved = localStorage.getItem('ld_user_ref_code');
    if (saved) return saved;
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    localStorage.setItem('ld_user_ref_code', code);
    return code;
  });

  const [isEditingSlug, setIsEditingSlug] = useState(false);
  const [editSlugInput, setEditSlugInput] = useState(refSlug);
  const [slugError, setSlugError] = useState('');
  const [isPromoCopied, setIsPromoCopied] = useState<{ [key: string]: boolean }>({});

  // Share Preview States & Real-Time Customizable Messaging
  const [isSharePreviewOpen, setIsSharePreviewOpen] = useState(false);
  const [previewPlatform, setPreviewPlatform] = useState<'whatsapp' | 'telegram'>('whatsapp');
  const [customMessage, setCustomMessage] = useState('');
  const [isCopiedFromModal, setIsCopiedFromModal] = useState(false);

  const baseDomain = typeof window !== 'undefined' 
    ? window.location.origin.replace('-dev-', '-pre-') 
    : 'https://naraearn.com';
  const referralLink = `${baseDomain}/?ref=${refSlug.toUpperCase()}`;

  const handleCopyLink = () => {
    try {
      navigator.clipboard.writeText(referralLink);
    } catch (e) {
      // safe fallback
    }
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleSaveSlug = () => {
    setSlugError('');
    const inputCleaned = editSlugInput
      .toUpperCase()
      .trim()
      .replace(/[^A-Z0-9-]/g, '')
      .replace(/-+/g, '-');
    
    if (inputCleaned.length < 3) {
      setSlugError('Referral handle must be at least 3 characters long.');
      return;
    }
    
    const finalized = inputCleaned;
    setRefSlug(finalized);
    localStorage.setItem('ld_user_ref_slug', finalized);
    setIsEditingSlug(false);
  };

  // Promo copy handles
  const handleCopyPromo = (type: string, text: string) => {
    try {
      navigator.clipboard.writeText(text);
    } catch (e) {}
    setIsPromoCopied(prev => ({ ...prev, [type]: true }));
    setTimeout(() => {
      setIsPromoCopied(prev => ({ ...prev, [type]: false }));
    }, 2500);
  };

  // Promotional Templates
  const promoTemplates = {
    whatsapp: `🇳🇬 *Make Passive Income Daily on NaraEarn!* 🚀\n\nHey! I'm inviting you to NaraEarn, the premier social-micropayments platform in Nigeria. You can earn *${formatNaira(inviteRewardAmount)} instantly* on registrations and perform simple daily tasks for payouts.\n\n👉 Join via my verified link here:\n👉 ${referralLink}\n\nLet's grow together! 💸`,
    telegram: `🇳🇬 *Earn Money Daily on NaraEarn!* 🚀\n\nHey there! NaraEarn is Nigeria's leading social micropayments platform. You can earn *${formatNaira(inviteRewardAmount)} instantly* on signups and do simple, fun daily tasks to collect rewards.\n\n👇 Register here with my secure link:\n👇 ${referralLink}`,
    twitter: `Looking for a legitimate way to earn passive Naira in Nigeria? 🇳🇬 Join NaraEarn now. Perform quick daily tasks like liking posts or joining channels to earn and cash out instantly. Register with my exclusive inviter link: ${referralLink} 🚀💸`,
    email: `Hello, I hope this finds you well. I'm inviting you to check out NaraEarn, a digital rewards platform that lets you earn daily commissions by completing simple, verified promotional tasks. Sign up with my secure link to receive premium task access: ${referralLink}`
  };

  const handleTriggerSimReferral = (e: React.FormEvent) => {
    e.preventDefault();

    if (!friendName.trim() || !friendEmail.trim()) {
      setSimulationError('Please fully input name and valid email structures.');
      return;
    }

    if (!friendEmail.includes('@') || !friendEmail.includes('.')) {
      setSimulationError('Please enter a valid format email (e.g. name@domain.com)');
      return;
    }

    setSimulationError('');
    onSimulateInvite(friendName.trim(), friendEmail.trim());
    
    // Set simulated success logs
    setSimulationSuccess(`Hooray! ${friendName.trim()} joined NaraEarn via your unique link! You earned ${formatNaira(inviteRewardAmount)} commission credit!`);
    
    // reset inputs
    setFriendName('');
    setFriendEmail('');

    // Clear alert after a few seconds
    setTimeout(() => setSimulationSuccess(''), 6000);
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-5xl mx-auto">
      
      {/* Overview Intro */}
      <div className="text-center max-w-2xl mx-auto px-4 select-none">
        <span className="font-mono text-[9px] tracking-widest text-green-600 bg-green-50 px-2.5 py-1 rounded-full uppercase font-black">
          PASSIVE REFERRAL PORTAL & GROWTH ENGINE
        </span>
        <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-gray-950 font-display">
          Refer Friends, Earn {formatNaira(inviteRewardAmount)} Commission
        </h2>
        <p className="mt-2 text-sm text-gray-500 font-sans leading-relaxed">
          Invite your friends to complete tasks. Once they register and verify their first social campaign, you will receive a {formatNaira(inviteRewardAmount)} referral bonus credited directly to your Available balance.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Section: Link Builder and Guest Simulator */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Share Box card */}
          <div className="bg-white rounded-3xl border border-gray-150 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider font-mono">
                Your Referral Link:
              </h3>
              <button
                type="button"
                onClick={() => {
                  setEditSlugInput(refSlug);
                  setIsEditingSlug(!isEditingSlug);
                }}
                className="text-[10px] text-green-700 hover:text-green-800 font-bold uppercase flex items-center gap-1 cursor-pointer"
                title="Customize handle slug"
              >
                <Edit2 className="h-3 w-3" />
                <span>{isEditingSlug ? 'Cancel' : 'Customize'}</span>
              </button>
            </div>

            {isEditingSlug ? (
              <div className="space-y-2 p-3 bg-gray-50 rounded-2xl border border-gray-200">
                <span className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block">
                  Choose Custom Slug/Handle
                </span>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    value={editSlugInput}
                    onChange={(e) => setEditSlugInput(e.target.value)}
                    placeholder="e.g. CHIDI-EARNS"
                    className="flex-1 min-w-0 font-mono text-xs font-black p-2 rounded-xl bg-white border border-gray-200 focus:outline-none focus:border-green-600 uppercase"
                  />
                  <button
                    type="button"
                    onClick={handleSaveSlug}
                    className="p-2 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded-xl text-xs font-mono font-bold uppercase tracking-wider flex items-center justify-center cursor-pointer shadow-sm"
                  >
                    <Save className="h-4 w-4" />
                  </button>
                </div>
                {slugError && (
                  <p className="text-[9.5px] text-red-500 font-mono font-medium leading-tight">
                    {slugError}
                  </p>
                )}
                <span className="text-[9px] text-gray-400 font-sans block leading-normal pt-1 p-0.5">
                  Use only alphabets, numbers and dashes. Upper-cased automatically for validation.
                </span>
              </div>
            ) : (
              <div className="space-y-2">
                {/* Interactive Link Copy Container */}
                <div className="relative group/link">
                  <p 
                    onClick={handleCopyLink}
                    className="text-xs font-mono font-bold text-green-700 bg-gray-50 hover:bg-green-50/80 p-3.5 pr-10 rounded-xl border border-gray-200 break-all select-all text-left cursor-pointer transition flex items-center justify-between gap-2"
                    title="Click to Copy Link"
                  >
                    <span className="truncate">{referralLink}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent duplicate trigger from parent p tag click
                        handleCopyLink();
                      }}
                      className="shrink-0 p-1 rounded-lg hover:bg-green-100 transition duration-150"
                      title="Copy Link to Clipboard"
                    >
                      {isCopied ? (
                        <Check className="h-4 w-4 text-emerald-600 animate-scale-in" />
                      ) : (
                        <Copy className="h-4 w-4 text-green-600 hover:scale-105" />
                      )}
                    </button>
                  </p>
                </div>

                {/* Interactive Code Copy Container */}
                <div className="flex items-center justify-between bg-gray-50/50 px-3.5 py-2.5 rounded-xl border border-gray-150 text-[11px]">
                  <span className="text-gray-500 font-sans">
                    Registration Code: <strong className="font-mono text-gray-900 font-bold select-all">{refSlug.toUpperCase()}</strong>
                  </span>
                  
                  <button
                    type="button"
                    onClick={() => {
                      try {
                        navigator.clipboard.writeText(refSlug.toUpperCase());
                      } catch (e) {}
                      setIsCodeCopied(true);
                      setTimeout(() => setIsCodeCopied(false), 2000);
                    }}
                    className="text-[10px] text-green-700 hover:text-green-800 font-mono font-bold flex items-center gap-1 cursor-pointer hover:bg-green-50 px-2 py-1 rounded-md transition duration-150"
                  >
                    {isCodeCopied ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-600" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleCopyLink}
                className="flex-1 inline-flex items-center justify-center space-x-1.5 bg-green-600 hover:bg-green-700 text-white font-bold text-xs uppercase tracking-wider py-3 rounded-xl cursor-pointer transition shadow-xs"
              >
                {isCopied ? (
                  <>
                    <Check className="h-4 w-4 text-emerald-250" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4" />
                    <span>Copy Link</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  setCustomMessage(promoTemplates.whatsapp);
                  setPreviewPlatform('whatsapp');
                  setIsSharePreviewOpen(true);
                }}
                className="inline-flex items-center justify-center space-x-1.5 border border-gray-200 hover:border-gray-350 bg-gray-50 hover:bg-gray-100 text-gray-800 font-bold text-[11px] uppercase tracking-wider px-3.5 py-3 rounded-xl cursor-pointer transition shadow-3xs"
                title="Live Customize & Share Preview"
              >
                <Share2 className="h-4 w-4 text-green-600 animate-pulse" />
                <span>Share Preview</span>
              </button>
            </div>

            <div className="pt-4 border-t border-gray-100 space-y-3 font-sans text-xs font-bold">
              <div className="flex items-center justify-between">
                <span className="text-gray-500">Total Referrals:</span>
                <span className="text-gray-900 font-mono font-bold">{totalReferrals}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-500">Referral Earnings:</span>
                <span className="text-green-750 text-green-700 font-mono font-bold">
                  ₦{totalReferralEarnings.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                </span>
              </div>
            </div>
          </div>

          {/* Social Quick Share Copy Kit */}
          <div className="bg-white rounded-3xl border border-gray-150 p-5 shadow-xs space-y-3.5">
            <div>
              <span className="font-mono text-[9px] tracking-widest text-green-600 font-black">
                MARKETING KIT
              </span>
              <h4 className="text-xs font-bold text-gray-950 font-display uppercase tracking-wider">
                High-Converting Promos
              </h4>
              <p className="text-[10.5px] text-gray-400 leading-snug">
                Pick a channel format below to copy pre-optimized invitations.
              </p>
            </div>

            <div className="space-y-2 text-left">
              {/* WhatsApp Share Card */}
              <div className="p-3 bg-green-50/40 rounded-2xl border border-green-100/70 flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold font-mono text-green-800 flex items-center gap-1 uppercase">
                    <MessageSquare className="h-3.5 w-3.5" /> WhatsApp & Telegram
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setCustomMessage(promoTemplates.whatsapp);
                        setPreviewPlatform('whatsapp');
                        setIsSharePreviewOpen(true);
                      }}
                      className="text-[9.5px] font-mono font-black uppercase text-slate-700 hover:text-green-850 cursor-pointer flex items-center gap-1"
                      title="Open Live Share Preview dialog"
                    >
                      <Share2 className="h-3 w-3 text-green-600" />
                      <span>Preview</span>
                    </button>
                    <span className="text-gray-300">|</span>
                    <button
                      type="button"
                      onClick={() => handleCopyPromo('wa', promoTemplates.whatsapp)}
                      className="text-[9.5px] font-mono font-black uppercase text-green-700 hover:text-green-800 cursor-pointer flex items-center gap-1"
                    >
                      {isPromoCopied.wa ? <CheckCircle2 className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
                      <span>{isPromoCopied.wa ? 'Copied' : 'Copy Kit'}</span>
                    </button>
                  </div>
                </div>
                <p className="text-[10.5px] text-gray-600 line-clamp-3 select-none leading-relaxed italic">
                  "{promoTemplates.whatsapp}"
                </p>
              </div>

              {/* Twitter/X Card */}
              <div className="p-3 bg-gray-50 rounded-2xl border border-gray-150 flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold font-mono text-gray-800 flex items-center gap-1 uppercase">
                    <Send className="h-3.5 w-3.5 text-gray-600" /> Social Feeds (Twitter/FB)
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopyPromo('tw', promoTemplates.twitter)}
                    className="text-[9.5px] font-mono font-black uppercase text-gray-900 hover:text-gray-800 cursor-pointer flex items-center gap-1"
                  >
                    {isPromoCopied.tw ? <CheckCircle2 className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
                    <span>{isPromoCopied.tw ? 'Copied' : 'Copy Kit'}</span>
                  </button>
                </div>
                <p className="text-[10.5px] text-gray-600 line-clamp-2 select-none leading-relaxed italic">
                  "{promoTemplates.twitter}"
                </p>
              </div>
            </div>
          </div>

          {/* Premium Agent Hologram Card Graphic */}
          <div className="bg-gradient-to-br from-indigo-900 via-emerald-950 to-slate-950 text-white rounded-3xl p-5 border border-emerald-500/20 shadow flex flex-col justify-between h-48 relative overflow-hidden select-none">
            {/* Background pattern accents */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl -z-10" />
            
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[9px] font-mono tracking-widest text-emerald-400 font-bold uppercase">
                  NaraEarn Exclusive
                </span>
                <h4 className="text-xs font-bold uppercase tracking-widest font-mono text-white mt-0.5">
                  Verified Inviter Pass
                </h4>
              </div>
              <div className="h-8 w-12 bg-gradient-to-br from-amber-300 to-amber-500 rounded-lg flex items-center justify-center opacity-85 shadow-sm border border-amber-200">
                <QrCode className="h-5 w-5 text-amber-950" />
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[9px] font-mono uppercase text-teal-400 block tracking-wider leading-none">
                Inviter Handle
              </span>
              <strong className="text-base font-mono font-black text-white block uppercase tracking-wide leading-none select-all truncate">
                @{refSlug.toUpperCase()}
              </strong>
            </div>

            <div className="flex items-center justify-between border-t border-white/10 pt-3">
              <div className="text-left">
                <span className="text-[8px] font-mono uppercase text-gray-400 block leading-none">Registered Code</span>
                <p className="text-[11px] font-mono text-teal-200 font-extrabold mt-0.5 uppercase">LD-{refSlug.toUpperCase()}</p>
              </div>
              <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-teal-500/10 border border-teal-500/30 text-[9px] font-mono text-teal-300 font-bold uppercase">
                <Award className="h-3 w-3 shrink-0" />
                <span>Level A Partner</span>
              </div>
            </div>
          </div>

          {/* Invitation Guest Simulator */}
          <div className="bg-gradient-to-br from-gray-900 to-gray-950 text-white rounded-3xl p-6 shadow-sm space-y-4 border border-gray-800">
            <div>
              <span className="font-mono text-[9px] tracking-widest text-[#22c55e] text-teal-400 uppercase font-black">
                INVITATION DISPATCH
              </span>
              <h3 className="text-sm font-bold font-display text-white mt-1">
                Send Invitation & Register Referral
              </h3>
              <p className="text-[10px] text-gray-400 leading-relaxed font-sans mt-0.5">
                Send a registered loyalty referral link to your partners. Input their details below to pre-register and earn referral bonuses instantly.
              </p>
            </div>

            {simulationSuccess && (
              <div className="p-3 bg-green-950/80 border border-green-800/80 text-green-300 text-xs rounded-xl flex items-start gap-2 animate-scale-in">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-green-400 mt-0.5" />
                <p className="leading-snug">Invitation generated! {friendName.trim()} has been registered under your affiliate network. +{formatNaira(inviteRewardAmount)} referral bonus credited!</p>
              </div>
            )}

            <form onSubmit={handleTriggerSimReferral} className="space-y-3.5">
              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-gray-400 font-mono mb-1">
                  Friend's Full Name*
                </label>
                <input
                  type="text"
                  required
                  value={friendName}
                  onChange={(e) => setFriendName(e.target.value)}
                  placeholder="e.g. Chinedu Obi"
                  className="w-full px-3 py-2 text-xs bg-gray-800/80 text-white placeholder-gray-500 border border-gray-700 rounded-lg focus:outline-none focus:border-green-500"
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold uppercase tracking-wider text-gray-400 font-mono mb-1">
                  Friend's Email address*
                </label>
                <input
                  type="email"
                  required
                  value={friendEmail}
                  onChange={(e) => setFriendEmail(e.target.value)}
                  placeholder="e.g. chinedu@tech.ng"
                  className="w-full px-3 py-2 text-xs bg-gray-800/80 text-white placeholder-gray-500 border border-gray-700 rounded-lg focus:outline-none focus:border-green-500"
                />
              </div>

              {simulationError && (
                <p className="text-[10px] text-red-400 flex items-center gap-1.5 mt-1 leading-snug">
                  <AlertCircle className="h-4 w-4" />
                  {simulationError}
                </p>
              )}

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-green-600 hover:bg-green-500 text-white text-xs font-bold transition duration-200 cursor-pointer"
              >
                <UserPlus className="h-4 w-4" />
                <span>Generate & Dispatch Invitation</span>
              </button>
            </form>
          </div>

        </div>

        {/* Right Section: Friends Ledger Database list & Referral Leaderboard */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Referral Leaderboard Card Widget */}
          <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-xs space-y-5">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-100 pb-4 gap-3">
              <div>
                <span className="font-mono text-[9px] tracking-widest text-green-600 font-bold flex items-center gap-1">
                  <Sparkles className="h-3 w-3 inline text-amber-550 text-amber-500" /> NIGERIAN REGIONAL HALL OF FAME
                </span>
                <h3 className="text-sm font-bold text-gray-950 font-display flex items-center gap-1.5 mt-0.5">
                  <Trophy className="h-4.5 w-4.5 text-amber-500 animate-bounce" /> Top Weekly Ambassadors
                </h3>
              </div>
              <div className="px-3 py-1 rounded-xl bg-slate-50 border border-slate-100 text-[10px] font-mono text-gray-400 select-none flex items-center gap-1.5 self-start sm:self-center">
                <Clock className="h-3 w-3 text-gray-400" />
                <span>Next update in 4h 12m</span>
              </div>
            </div>

            {/* Top 3 Podium Cards Style */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-1">
              
              {/* Podium Rank 2 */}
              <motion.div 
                whileHover={{ y: -3, scale: 1.01 }}
                className={`border rounded-2xl p-4 flex flex-col items-center text-center relative overflow-hidden transition-all duration-350 ${
                  leaderboardData[1]?.isCurrentUser 
                    ? 'border-emerald-500 ring-2 ring-emerald-100 bg-emerald-50/25 shadow-xs' 
                    : 'bg-slate-50/55 border-slate-150'
                }`}
              >
                <div className="absolute top-2 right-2 bg-slate-200/70 text-slate-700 font-mono text-[9.5px] font-black px-1.5 py-0.5 rounded-md leading-none border border-slate-300 flex items-center gap-1">
                  #2 {leaderboardData[1]?.isCurrentUser && <span className="text-[8px] bg-emerald-600 text-white px-1 py-0.2 rounded font-sans uppercase font-bold">You</span>}
                </div>
                <div className="h-10 w-10 rounded-full bg-slate-200 text-slate-700 font-black text-xs flex items-center justify-center border-2 border-white shadow-xs relative">
                  {leaderboardData[1]?.initials}
                  <span className="absolute -bottom-1 -right-1 bg-slate-400 rounded-full p-0.5 text-[8px] text-white">🥈</span>
                </div>
                <h4 className="font-extrabold text-xs text-slate-900 mt-2 font-display truncate max-w-[130px]">{leaderboardData[1]?.name}</h4>
                <p className="text-[10px] text-slate-500 font-sans font-bold uppercase mt-0.5 tracking-wider">{leaderboardData[1]?.level}</p>
                
                <div className="mt-3 pt-2.5 border-t border-slate-200/50 w-full flex justify-between items-center text-[10.5px]">
                  <span className="text-slate-400 font-sans">{leaderboardData[1]?.count} invites</span>
                  <span className="font-mono font-black text-emerald-700">₦{leaderboardData[1]?.earnings.toLocaleString()}</span>
                </div>
              </motion.div>

              {/* Podium Rank 1 */}
              <motion.div 
                whileHover={{ y: -4, scale: 1.015 }}
                className={`border rounded-2xl p-4 flex flex-col items-center text-center relative overflow-hidden ring-1 transition-all duration-350 ${
                  leaderboardData[0]?.isCurrentUser 
                    ? 'border-emerald-500 ring-2 ring-emerald-150 bg-emerald-50/30 shadow-md' 
                    : 'bg-amber-50/40 border-amber-150 ring-amber-100'
                }`}
              >
                <div className="absolute top-2 right-2 bg-amber-200 text-amber-850 text-amber-700 font-mono text-[9.5px] font-black px-1.5 py-0.5 rounded-md leading-none border border-amber-300 flex items-center gap-1">
                  👑 #1 {leaderboardData[0]?.isCurrentUser && <span className="text-[8px] bg-emerald-600 text-white px-1 py-0.2 rounded font-sans uppercase font-bold">You</span>}
                </div>
                <div className="h-12 w-12 rounded-full bg-amber-100 text-amber-700 font-black text-sm flex items-center justify-center border-2 border-amber-200 shadow-sm relative">
                  {leaderboardData[0]?.initials}
                  <span className="absolute -bottom-1 -right-1 bg-amber-500 rounded-full p-0.5 text-[9px] text-white">🥇</span>
                </div>
                <h4 className="font-extrabold text-xs text-amber-950 mt-2 font-display truncate max-w-[140px]">{leaderboardData[0]?.name}</h4>
                <p className="text-[10px] text-amber-700 font-sans font-bold uppercase mt-0.5 tracking-wider">{leaderboardData[0]?.level}</p>
                
                <div className="mt-2 pt-2.5 border-t border-amber-200/50 w-full flex justify-between items-center text-[10.5px]">
                  <span className="text-amber-600 font-sans font-bold">{leaderboardData[0]?.count} invites</span>
                  <span className="font-mono font-black text-emerald-800 text-xs">₦{leaderboardData[0]?.earnings.toLocaleString()}</span>
                </div>
              </motion.div>

              {/* Podium Rank 3 */}
              <motion.div 
                whileHover={{ y: -3, scale: 1.01 }}
                className={`border rounded-2xl p-4 flex flex-col items-center text-center relative overflow-hidden transition-all duration-350 ${
                  leaderboardData[2]?.isCurrentUser 
                    ? 'border-emerald-500 ring-2 ring-emerald-100 bg-emerald-50/25 shadow-xs' 
                    : 'bg-amber-50/15 border-amber-100/70'
                }`}
              >
                <div className="absolute top-2 right-2 bg-amber-100/50 text-amber-800 font-mono text-[9.5px] font-black px-1.5 py-0.5 rounded-md leading-none border border-amber-200/60 flex items-center gap-1">
                  #3 {leaderboardData[2]?.isCurrentUser && <span className="text-[8px] bg-emerald-600 text-white px-1 py-0.2 rounded font-sans uppercase font-bold">You</span>}
                </div>
                <div className="h-10 w-10 rounded-full bg-orange-100 text-orange-850 text-orange-800 font-black text-xs flex items-center justify-center border-2 border-white shadow-xs relative">
                  {leaderboardData[2]?.initials}
                  <span className="absolute -bottom-1 -right-1 bg-amber-600 rounded-full p-0.5 text-[8px] text-white">🥉</span>
                </div>
                <h4 className="font-extrabold text-xs text-orange-950 mt-2 font-display truncate max-w-[130px]">{leaderboardData[2]?.name}</h4>
                <p className="text-[10px] text-orange-600 font-sans font-bold uppercase mt-0.5 tracking-wider">{leaderboardData[2]?.level}</p>
                
                <div className="mt-3 pt-2.5 border-t border-slate-200/30 w-full flex justify-between items-center text-[10.5px]">
                  <span className="text-orange-605 text-orange-600 font-sans">{leaderboardData[2]?.count} invites</span>
                  <span className="font-mono font-black text-emerald-700">₦{leaderboardData[2]?.earnings.toLocaleString()}</span>
                </div>
              </motion.div>

            </div>

            {/* List for Rank 4 & 5 */}
            <div className="space-y-2 pt-1 border-t border-gray-50">
              
              {/* Rank 4 */}
              <div className={`flex items-center justify-between p-3 rounded-xl border transition-all duration-350 text-xs ${
                leaderboardData[3]?.isCurrentUser 
                  ? 'border-emerald-500 ring-2 ring-emerald-100/50 bg-emerald-50/20' 
                  : 'bg-gray-50/40 border-gray-150 hover:bg-slate-50'
              }`}>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-gray-400 font-bold w-4 text-center">#4</span>
                  <div className="h-7 w-7 rounded-full bg-violet-50 text-violet-700 font-bold flex items-center justify-center text-[11px]">
                    {leaderboardData[3]?.initials}
                  </div>
                  <div>
                    <h5 className="font-bold text-gray-950 font-sans flex items-center gap-1.5">
                      {leaderboardData[3]?.name}
                      {leaderboardData[3]?.isCurrentUser && <span className="text-[8px] bg-emerald-600 text-white px-1 py-0.5 rounded font-mono uppercase font-bold leading-none">You</span>}
                    </h5>
                    <span className="text-[9px] text-violet-600 font-mono font-medium uppercase tracking-wider">{leaderboardData[3]?.level}</span>
                  </div>
                </div>
                <div className="text-right flex items-center gap-6 font-mono">
                  <span className="text-gray-400 text-[10.5px]">{leaderboardData[3]?.count} invites</span>
                  <span className="font-bold text-green-700">₦{leaderboardData[3]?.earnings.toLocaleString()}</span>
                </div>
              </div>

              {/* Rank 5 */}
              <div className={`flex items-center justify-between p-3 rounded-xl border transition-all duration-350 text-xs ${
                leaderboardData[4]?.isCurrentUser 
                  ? 'border-emerald-500 ring-2 ring-emerald-100/50 bg-emerald-50/20' 
                  : 'bg-gray-50/40 border-gray-150 hover:bg-slate-50'
              }`}>
                <div className="flex items-center gap-3">
                  <span className="font-mono text-gray-400 font-bold w-4 text-center">#5</span>
                  <div className="h-7 w-7 rounded-full bg-blue-50 text-blue-700 font-bold flex items-center justify-center text-[11px]">
                    {leaderboardData[4]?.initials}
                  </div>
                  <div>
                    <h5 className="font-bold text-gray-950 font-sans flex items-center gap-1.5">
                      {leaderboardData[4]?.name}
                      {leaderboardData[4]?.isCurrentUser && <span className="text-[8px] bg-emerald-600 text-white px-1 py-0.5 rounded font-mono uppercase font-bold leading-none">You</span>}
                    </h5>
                    <span className="text-[9px] text-blue-600 font-mono font-medium uppercase tracking-wider">{leaderboardData[4]?.level}</span>
                  </div>
                </div>
                <div className="text-right flex items-center gap-6 font-mono">
                  <span className="text-gray-400 text-[10.5px]">{leaderboardData[4]?.count} invites</span>
                  <span className="font-bold text-green-700">₦{leaderboardData[4]?.earnings.toLocaleString()}</span>
                </div>
              </div>

            </div>

            {/* Gamification Progress Tracker based on user's real totalReferrals */}
            {(() => {
              const MILESTONES = [
                { name: 'Bronze Inviter', target: 5, bonus: 1000 },
                { name: 'Silver Partner', target: 15, bonus: 3500 },
                { name: 'Gold Ambassador', target: 50, bonus: 12500 },
                { name: 'Elite Pioneer', target: 100, bonus: 30000 },
              ];

              const currentMilestoneIndex = MILESTONES.findIndex(m => totalReferrals < m.target);
              const nextMilestone = currentMilestoneIndex !== -1 ? MILESTONES[currentMilestoneIndex] : null;
              const prevMilestoneTarget = currentMilestoneIndex > 0 ? MILESTONES[currentMilestoneIndex - 1].target : 0;
              const progressPercent = nextMilestone
                ? Math.min(100, Math.round(((totalReferrals - prevMilestoneTarget) / (nextMilestone.target - prevMilestoneTarget)) * 100))
                : 100;

              return (
                <div className="bg-green-50/40 rounded-2xl border border-green-150 p-4.5 space-y-3 relative overflow-hidden select-none">
                  <div className="flex items-start justify-between">
                    <div className="text-left">
                      <span className="font-mono text-[8px] tracking-widest text-green-600 font-black uppercase">
                        YOUR EXCLUSIVE TARGET PROGRESS
                      </span>
                      {nextMilestone ? (
                        <>
                          <h4 className="text-xs font-bold text-slate-900 font-display">
                            Unlock <strong className="text-green-700 font-extrabold">{nextMilestone.name}</strong> bonus rank!
                          </h4>
                          <p className="text-[10px] text-gray-500 font-sans leading-tight mt-0.5">
                            Invite {nextMilestone.target - totalReferrals} more active referral{nextMilestone.target - totalReferrals === 1 ? '' : 's'} to secure your <strong className="font-bold text-slate-800">₦{nextMilestone.bonus.toLocaleString()} Extra cash payout</strong>.
                          </p>
                        </>
                      ) : (
                        <>
                          <h4 className="text-xs font-bold text-slate-900 font-display">
                            🎉 Max Rank Unlocked: <strong className="text-green-700 font-extrabold">{MILESTONES[MILESTONES.length - 1].name}</strong>!
                          </h4>
                          <p className="text-[10px] text-gray-500 font-sans leading-tight mt-0.5">
                            You've conquered the local milestone system! You've claimed all exclusive rewards successfully.
                          </p>
                        </>
                      )}
                    </div>
                    {nextMilestone && (
                      <span className="font-mono text-xs font-black text-green-700 bg-green-100 border border-green-200 px-2.5 py-0.5 rounded-lg shrink-0">
                        +₦{nextMilestone.bonus.toLocaleString()}
                      </span>
                    )}
                  </div>

                  <div className="space-y-1.5 pt-0.5">
                    <div className="flex justify-between items-center text-[10px] font-mono font-medium text-gray-400">
                      <span>{prevMilestoneTarget} invites</span>
                      <span className="text-green-700 font-bold">{totalReferrals} / {nextMilestone ? nextMilestone.target : '∞'} invites ({progressPercent}% )</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200/50 relative">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${progressPercent}%` }}
                        transition={{ duration: 1, ease: 'easeOut' }}
                        className="bg-gradient-to-r from-emerald-500 to-green-600 h-full rounded-full"
                      />
                    </div>
                  </div>
                </div>
              );
            })()}

          </div>

          {/* Referral Analytics & Monthly Growth Breakdown */}
          <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-150 pb-4 gap-4">
              <div className="text-left select-none">
                <span className="font-mono text-[9px] tracking-widest text-green-600 font-bold flex items-center gap-1 uppercase">
                  <TrendingUp className="h-3.5 w-3.5 text-green-600" /> Affiliate Network Analytics
                </span>
                <h3 className="text-sm font-bold text-gray-950 font-display mt-0.5">
                  Monthly Referral Growth & Performance
                </h3>
                <p className="text-[11px] text-gray-400 font-sans leading-tight mt-0.5">
                  Real-time visualization of invites joined and commissions credited by calendar month.
                </p>
              </div>

              {/* View Toggle */}
              <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 self-start sm:self-center">
                <button
                  type="button"
                  onClick={() => setChartView('count')}
                  className={`px-3 py-1 text-[11px] font-bold rounded-lg transition duration-150 flex items-center gap-1.5 cursor-pointer ${
                    chartView === 'count'
                      ? 'bg-white shadow-3xs text-green-700 font-black'
                      : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  <Users className="h-3 w-3" />
                  <span>Referrals Count</span>
                </button>
                <button
                  type="button"
                  onClick={() => setChartView('earnings')}
                  className={`px-3 py-1 text-[11px] font-bold rounded-lg transition duration-150 flex items-center gap-1.5 cursor-pointer ${
                    chartView === 'earnings'
                      ? 'bg-white shadow-3xs text-green-700 font-black'
                      : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  <span className="font-bold text-[10px] leading-none">₦</span>
                  <span>Commissions</span>
                </button>
              </div>
            </div>

            {/* Main Chart Card Grid */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              
              {/* Left 4 Cols: Analytics Stats Cards */}
              <div className="md:col-span-4 space-y-3.5">
                
                {/* Stat 1: Best Month */}
                <div className="p-4 bg-slate-50/60 border border-slate-100 rounded-2xl flex items-center justify-between">
                  <div className="text-left">
                    <span className="text-[9px] font-mono text-gray-400 font-bold uppercase block tracking-wider leading-none">Peak Activity</span>
                    <strong className="text-xs text-gray-900 font-display block mt-1.5">
                      {(() => {
                        const maxMonth = monthlyData.reduce((max, current) => {
                          const maxVal = chartView === 'count' ? max.count : max.earnings;
                          const curVal = chartView === 'count' ? current.count : current.earnings;
                          return curVal > maxVal ? current : max;
                        }, monthlyData[0] || { label: 'None', count: 0, earnings: 0 });
                        return maxMonth.label === 'None' || (chartView === 'count' ? maxMonth.count : maxMonth.earnings) === 0
                          ? 'No Data'
                          : `${maxMonth.label} (${chartView === 'count' ? `${maxMonth.count} invites` : `₦${maxMonth.earnings.toLocaleString()}`})`;
                      })()}
                    </strong>
                  </div>
                  <div className="h-8 w-8 rounded-xl bg-green-50 text-green-700 flex items-center justify-center font-bold shrink-0">
                    <Award className="h-4.5 w-4.5" />
                  </div>
                </div>

                {/* Stat 2: Current Month Activity */}
                <div className="p-4 bg-slate-50/60 border border-slate-100 rounded-2xl flex items-center justify-between">
                  <div className="text-left">
                    <span className="text-[9px] font-mono text-gray-400 font-bold uppercase block tracking-wider leading-none">This Month's Growth</span>
                    <strong className="text-xs text-gray-900 font-display block mt-1.5">
                      {(() => {
                        const currentMonthData = monthlyData[monthlyData.length - 1];
                        if (!currentMonthData) return 'No Data';
                        return chartView === 'count'
                          ? `+${currentMonthData.count} new referrals`
                          : `+₦${currentMonthData.earnings.toLocaleString()} earned`;
                      })()}
                    </strong>
                  </div>
                  <div className="h-8 w-8 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold shrink-0">
                    <Users className="h-4.5 w-4.5" />
                  </div>
                </div>

                {/* Stat 3: Total Program Payout */}
                <div className="p-4 bg-gradient-to-br from-emerald-500/5 to-green-600/5 border border-green-100 rounded-2xl flex items-center justify-between">
                  <div className="text-left">
                    <span className="text-[9px] font-mono text-green-700 font-bold uppercase block tracking-wider leading-none">Overall Efficiency</span>
                    <strong className="text-xs text-gray-900 font-display block mt-1.5">
                      {(() => {
                        const totalReferralsEver = referralsList.length;
                        const activeReferralsEver = referralsList.filter(r => r.status === 'Active').length;
                        const efficiency = totalReferralsEver > 0 ? Math.round((activeReferralsEver / totalReferralsEver) * 100) : 0;
                        return `${efficiency}% Active Quality Rate`;
                      })()}
                    </strong>
                  </div>
                  <div className="h-8 w-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold shrink-0">
                    <CheckCircle2 className="h-4.5 w-4.5" />
                  </div>
                </div>

              </div>

              {/* Right 8 Cols: The Actual Chart Canvas */}
              <div className="md:col-span-8 bg-slate-50/55 border border-slate-150 rounded-3xl p-5 relative min-h-[220px] flex flex-col justify-between">
                
                {/* Chart Background Grid Lines */}
                <div className="absolute inset-x-5 top-8 bottom-14 flex flex-col justify-between pointer-events-none">
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} className="w-full border-t border-dashed border-gray-200" />
                  ))}
                </div>

                {/* Bars Container */}
                <div className="flex-1 flex items-end justify-between px-3 md:px-5 relative z-10 h-36">
                  {(() => {
                    const maxVal = Math.max(
                      ...monthlyData.map(m => chartView === 'count' ? m.count : m.earnings),
                      1 // Prevent division by zero
                    );

                    return monthlyData.map((data, index) => {
                      const val = chartView === 'count' ? data.count : data.earnings;
                      const pct = (val / maxVal) * 100;
                      const isHovered = hoveredBarIndex === index;

                      return (
                        <div 
                          key={data.key} 
                          className="flex-1 flex flex-col items-center group/bar relative"
                          onMouseEnter={() => setHoveredBarIndex(index)}
                          onMouseLeave={() => setHoveredBarIndex(null)}
                        >
                          {/* Tooltip on top of active bar */}
                          {isHovered && (
                            <div className="absolute bottom-full mb-2 bg-gray-900 text-white text-[10px] font-mono font-bold px-2.5 py-1 rounded-lg shadow-md z-20 whitespace-nowrap animate-scale-in">
                              {chartView === 'count' 
                                ? `${val} active signups` 
                                : `₦${val.toLocaleString()} earned`
                              }
                            </div>
                          )}

                          {/* Animated Bar */}
                          <div className="w-8 sm:w-11 bg-gray-200/30 rounded-t-xl overflow-hidden h-full flex items-end">
                            <motion.div
                              initial={{ height: 0 }}
                              animate={{ height: `${pct || 4}%` }} // Minimal height of 4% for nice styling if value is 0
                              transition={{ duration: 0.8, ease: "easeOut", delay: index * 0.05 }}
                              className={`w-full rounded-t-xl transition duration-150 cursor-pointer ${
                                pct === 0 ? 'bg-slate-200/50 hover:bg-slate-300' :
                                isHovered 
                                  ? 'bg-gradient-to-t from-green-600 to-emerald-400 shadow-sm' 
                                  : 'bg-gradient-to-t from-emerald-500 to-teal-400'
                              }`}
                            />
                          </div>
                        </div>
                      );
                    });
                  })()}
                </div>

                {/* X-Axis labels */}
                <div className="flex justify-between items-center px-3 md:px-5 border-t border-gray-200 pt-3 mt-3 relative z-10 select-none">
                  {monthlyData.map((data, index) => (
                    <div 
                      key={data.key} 
                      className={`flex-1 text-center font-mono text-[10px] font-bold transition-all duration-150 ${
                        hoveredBarIndex === index ? 'text-green-700 scale-105' : 'text-gray-400'
                      }`}
                    >
                      {data.label}
                    </div>
                  ))}
                </div>

              </div>

            </div>
          </div>

          {/* Friends Ledger Database list (Enhanced Interactive Table Card) */}
          <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-xs space-y-5" id="referrals-ledger-card">
            
            {/* Header with quick stats & actions */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-100 pb-4">
              <div>
                <span className="font-mono text-[9px] tracking-widest text-green-600 font-black block uppercase">
                  REGISTERED NETWORK LEDGER
                </span>
                <h3 className="text-base font-bold text-gray-950 font-display">
                  Referral Management Suite
                </h3>
                <p className="text-[11px] text-gray-400 font-sans mt-0.5">
                  Audit accounts, release commissions, flag potential abuse, and send automated email nudges.
                </p>
              </div>
              
              <div className="flex items-center gap-3 self-start md:self-auto select-none">
                <div className="text-right">
                  <span className="text-[10px] text-gray-400 font-mono block">Commission accrued</span>
                  <strong className="text-sm font-bold text-green-700 block">{formatNaira(totalReferralEarnings)}</strong>
                </div>
                
                <button
                  type="button"
                  onClick={handleExportCSV}
                  disabled={referralsList.length === 0}
                  className="px-3.5 py-2 bg-slate-50 hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed border border-slate-150 rounded-xl text-xs font-mono font-bold text-slate-700 flex items-center gap-1.5 transition cursor-pointer"
                  title="Export entire ledger to CSV spreadsheet"
                >
                  <Send className="h-3.5 w-3.5 text-slate-500 rotate-90" />
                  <span>Export CSV</span>
                </button>
              </div>
            </div>

            {/* Advanced Search, Filtering, and Sorting Controls */}
            <div className="bg-slate-50/60 border border-slate-100 p-4 rounded-2xl space-y-3.5">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                
                {/* Left Side: Search Bar */}
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search by friend name or email..."
                    className="w-full pl-10 pr-4 py-2 text-xs font-sans text-gray-800 bg-white border border-gray-200 rounded-xl focus:outline-none focus:border-green-600 focus:ring-1 focus:ring-green-500/10 transition"
                  />
                  {searchTerm && (
                    <button
                      type="button"
                      onClick={() => setSearchTerm('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 text-gray-400 hover:text-gray-600 text-xs font-mono font-bold rounded-full hover:bg-gray-100 transition"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Right Side: Sorting controls */}
                <div className="flex items-center gap-2 select-none self-end lg:self-auto">
                  <div className="flex items-center gap-1 text-[11px] font-mono text-gray-400 font-bold">
                    <ArrowUpDown className="h-3.5 w-3.5" />
                    <span>Sort:</span>
                  </div>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="text-xs font-mono font-bold text-gray-600 bg-white border border-gray-200 rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-green-600 transition cursor-pointer"
                  >
                    <option value="newest">Newest Joined</option>
                    <option value="oldest">Oldest Joined</option>
                    <option value="commission_high">Commission (High → Low)</option>
                    <option value="commission_low">Commission (Low → High)</option>
                  </select>
                </div>

              </div>

              {/* Quick Status Filters */}
              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100 select-none">
                <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest mr-1.5">
                  Filter by:
                </span>
                {(['All', 'Active', 'Pending', 'Flagged'] as const).map((status) => {
                  const count = status === 'All' 
                    ? referralsList.length 
                    : referralsList.filter(u => u.status === status).length;
                  
                  return (
                    <button
                      key={status}
                      type="button"
                      onClick={() => setStatusFilter(status)}
                      className={`px-3 py-1 text-xs font-mono font-bold rounded-lg transition-all duration-150 flex items-center gap-1.5 cursor-pointer ${
                        statusFilter === status
                          ? status === 'Active'
                            ? 'bg-emerald-600 text-white shadow-3xs'
                            : status === 'Flagged'
                            ? 'bg-red-650 bg-red-600 text-white shadow-3xs'
                            : status === 'Pending'
                            ? 'bg-amber-500 text-white shadow-3xs'
                            : 'bg-slate-800 text-white shadow-3xs'
                          : 'bg-white hover:bg-slate-100 text-gray-500 border border-gray-150'
                      }`}
                    >
                      <span>{status}</span>
                      <span className={`text-[9px] px-1 py-0.2 rounded-md ${
                        statusFilter === status ? 'bg-white/20 text-white' : 'bg-slate-100 text-gray-500'
                      }`}>
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>

            </div>

            {/* Table view */}
            <div className="overflow-x-auto select-none rounded-2xl border border-gray-100">
              <table className="w-full text-left text-xs min-w-[700px]">
                <thead>
                  <tr className="bg-slate-50/65 border-b border-gray-100 text-[10px] font-mono text-gray-400 uppercase tracking-widest font-bold">
                    <th className="py-3 px-4">User Details</th>
                    <th className="py-3 px-2">Date Joined</th>
                    <th className="py-3 px-2">Your Commission</th>
                    <th className="py-3 px-2">Attribution Status</th>
                    <th className="py-3 px-4 text-right">Quick Operations</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {filteredAndSortedList.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-gray-400 font-sans">
                        <AlertCircle className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                        <p className="text-xs font-bold text-gray-500">No network referrals match your filters.</p>
                        <p className="text-[10px] text-gray-400 mt-0.5">Try widening your search string or toggling filters.</p>
                      </td>
                    </tr>
                  ) : (
                    filteredAndSortedList.map((user) => {
                      const nudgeState = nudgedUsers[user.id] || 'idle';
                      
                      return (
                        <tr key={user.id} className="hover:bg-slate-50/40 transition">
                          
                          {/* User Details */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <div className="h-8 w-8 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold font-mono shrink-0">
                                {user.fullName.charAt(0)}
                              </div>
                              <div>
                                <div className="font-bold text-gray-950">{user.fullName}</div>
                                <div className="text-[10px] text-gray-500 font-mono flex items-center gap-1 mt-0.5">
                                  <Mail className="h-3 w-3 text-gray-400" />
                                  {user.email}
                                </div>
                              </div>
                            </div>
                          </td>
                          
                          {/* Date Joined */}
                          <td className="py-3 px-2 text-gray-600 font-mono text-[11px]">
                            {user.joinedDate}
                          </td>
                          
                          {/* Commission */}
                          <td className="py-3 px-2 font-mono font-bold text-green-600">
                            +{formatNaira(user.commissionEarned)}
                          </td>
                          
                          {/* Status and Active Dropdown */}
                          <td className="py-3 px-2">
                            <div className="relative">
                              {editingRowStatusId === user.id ? (
                                <div className="absolute left-0 top-1/2 -translate-y-1/2 z-20 bg-white border border-slate-200 shadow-lg rounded-xl p-1 flex flex-col gap-1 min-w-[100px]">
                                  {(['Active', 'Pending', 'Flagged'] as const).map((st) => (
                                    <button
                                      key={st}
                                      type="button"
                                      onClick={() => {
                                        if (onUpdateReferralStatus) {
                                          onUpdateReferralStatus(user.id, st);
                                        }
                                        setEditingRowStatusId(null);
                                      }}
                                      className="px-2 py-1 text-left text-[10px] font-mono hover:bg-slate-50 rounded-md text-gray-700 flex items-center justify-between cursor-pointer"
                                    >
                                      <span>{st}</span>
                                      {user.status === st && <span className="text-emerald-500">✓</span>}
                                    </button>
                                  ))}
                                  <button
                                    type="button"
                                    onClick={() => setEditingRowStatusId(null)}
                                    className="border-t border-gray-100 text-[9px] font-mono font-bold py-1 text-center text-red-500 hover:bg-red-50 rounded-md cursor-pointer"
                                  >
                                    Cancel
                                  </button>
                                </div>
                              ) : null}

                              <button
                                type="button"
                                onClick={() => setEditingRowStatusId(user.id)}
                                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[9px] font-mono leading-none tracking-wider uppercase font-bold border transition duration-100 hover:scale-102 hover:border-indigo-200 cursor-pointer ${
                                  user.status === 'Active' 
                                    ? 'bg-green-50 text-green-650 border-green-150'
                                    : user.status === 'Flagged'
                                    ? 'bg-red-50 text-red-650 border-red-150'
                                    : 'bg-amber-50 text-amber-650 border-amber-150'
                                }`}
                                title="Click to audit/modify status in-place"
                              >
                                {user.status === 'Active' && <ShieldCheck className="h-3 w-3 text-green-500" />}
                                {user.status === 'Flagged' && <AlertCircle className="h-3 w-3 text-red-500" />}
                                {user.status === 'Pending' && <Clock className="h-3 w-3 text-amber-500" />}
                                <span>{user.status}</span>
                                <span className="text-[8px] text-gray-400">▼</span>
                              </button>
                            </div>
                          </td>

                          {/* Action Operations */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              
                              {/* Quick status flip button (approve/unflag vs flag/suspend) */}
                              {user.status !== 'Active' ? (
                                <button
                                  type="button"
                                  onClick={() => onUpdateReferralStatus && onUpdateReferralStatus(user.id, 'Active')}
                                  className="p-1 bg-green-50 text-green-700 hover:bg-green-100 border border-green-200 rounded-lg text-[10px] font-bold font-mono transition-all flex items-center gap-1 cursor-pointer"
                                  title={`Instantly verify user and release ${formatNaira(user.commissionEarned || inviteRewardAmount)} commission`}
                                >
                                  <Check className="h-3.5 w-3.5" />
                                  <span className="hidden sm:inline">Verify</span>
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => onUpdateReferralStatus && onUpdateReferralStatus(user.id, 'Flagged')}
                                  className="p-1 bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 rounded-lg text-[10px] font-bold font-mono transition-all flex items-center gap-1 cursor-pointer"
                                  title="Flag as suspicious and freeze commission"
                                >
                                  <AlertCircle className="h-3.5 w-3.5" />
                                  <span className="hidden sm:inline">Flag</span>
                                </button>
                              )}

                              {/* Simulate emailing/nudging user to complete verification steps */}
                              <button
                                type="button"
                                onClick={() => handleSimulateNudge(user.id, user.fullName)}
                                disabled={nudgeState !== 'idle'}
                                className={`p-1 border rounded-lg text-[10px] font-bold font-mono transition-all flex items-center gap-1 cursor-pointer ${
                                  nudgeState === 'sending'
                                    ? 'bg-indigo-50 border-indigo-200 text-indigo-700 cursor-wait'
                                    : nudgeState === 'sent'
                                    ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                                    : 'bg-white hover:bg-slate-50 text-slate-600 border-slate-200'
                                }`}
                                title="Simulate sending email alert reminder"
                              >
                                <Send className={`h-3 w-3 ${nudgeState === 'sending' ? 'animate-bounce' : ''}`} />
                                <span className="hidden sm:inline">
                                  {nudgeState === 'sending' ? 'Sending...' : nudgeState === 'sent' ? 'Nudged!' : 'Nudge'}
                                </span>
                              </button>

                              {/* Delete record permanently */}
                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(`Delete referral entry for ${user.fullName}? Doing so will claw back commissions if they are Active.`)) {
                                    if (onDeleteReferral) onDeleteReferral(user.id);
                                  }
                                }}
                                className="p-1 hover:bg-red-50 hover:text-red-700 border border-transparent hover:border-red-200 text-slate-400 rounded-lg transition-all cursor-pointer"
                                title="Delete user record permanently"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>

                            </div>
                          </td>

                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Custom Referral Structure and Commission Boost Info Card */}
            <div className="bg-gradient-to-br from-indigo-900/5 to-purple-900/5 border border-indigo-50 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex gap-3">
                <div className="h-10 w-10 bg-indigo-100 text-indigo-700 rounded-xl flex items-center justify-center shrink-0">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div className="text-left">
                  <span className="text-[10px] font-mono text-indigo-700 font-bold uppercase block tracking-wider leading-none">Ambassador Boosts</span>
                  <strong className="text-sm text-gray-900 font-display block mt-1">Multiplied Referral Rates Active</strong>
                  <p className="text-[11px] text-gray-500 font-sans mt-0.5">
                    As your network expands, the commission per verification increases up to <strong className="text-indigo-600">1.5x (₦750/invite)</strong> automatically!
                  </p>
                </div>
              </div>

              {/* Commission multiplier map legend */}
              <div className="grid grid-cols-4 gap-1 sm:gap-2 max-w-sm w-full font-mono text-[9px] text-center select-none">
                <div className="p-1.5 bg-white border border-indigo-100 rounded-lg">
                  <div className="text-gray-400">BRONZE</div>
                  <strong className="text-gray-900 block font-bold mt-0.5">1.0x Rate</strong>
                </div>
                <div className="p-1.5 bg-white border border-indigo-100 rounded-lg">
                  <div className="text-indigo-500 font-bold">SILVER</div>
                  <strong className="text-indigo-700 block font-bold mt-0.5">1.1x Rate</strong>
                </div>
                <div className="p-1.5 bg-white border border-indigo-100 rounded-lg">
                  <div className="text-amber-600 font-bold">GOLD</div>
                  <strong className="text-amber-800 block font-bold mt-0.5">1.25x Rate</strong>
                </div>
                <div className="p-1.5 bg-white border border-indigo-100 rounded-lg">
                  <div className="text-purple-600 font-bold">ELITE</div>
                  <strong className="text-purple-800 block font-bold mt-0.5">1.5x Rate</strong>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* Share Preview & Customizable Interactive Invite Modal */}
      {isSharePreviewOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto animate-fade-in" id="share-preview-modal-overlay">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-gray-200 dark:border-slate-800 shadow-2xl max-w-4xl w-full overflow-hidden flex flex-col md:flex-row animate-scale-in my-auto">
            
            {/* Modal Left Option Area - Configurator */}
            <div className="flex-1 p-5 sm:p-7 border-b md:border-b-0 md:border-r border-gray-150 dark:border-slate-800 space-y-5 flex flex-col">
              <div className="flex justify-between items-start">
                <div className="text-left select-none">
                  <span className="font-mono text-[9px] tracking-widest text-green-600 uppercase font-black">
                    Live Marketing Hub
                  </span>
                  <h3 className="text-lg font-extrabold text-gray-900 dark:text-gray-100 font-display">
                    Customize Invite Message
                  </h3>
                  <p className="text-[11px] text-gray-400 font-sans mt-0.5">
                    Rewrite or refine your pitch. Watch how it targets users live.
                  </p>
                </div>
                
                <button
                  type="button"
                  onClick={() => setIsSharePreviewOpen(false)}
                  className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800 transition text-gray-400 hover:text-gray-600 block md:hidden"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Platform Selector Tabs */}
              <div className="grid grid-cols-2 gap-2 bg-gray-50 dark:bg-slate-950 p-1.5 rounded-xl border border-gray-150 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setPreviewPlatform('whatsapp');
                    setCustomMessage(promoTemplates.whatsapp);
                  }}
                  className={`py-2 px-3 text-xs font-bold rounded-lg transition-all duration-150 flex items-center justify-center gap-1.5 cursor-pointer ${
                    previewPlatform === 'whatsapp'
                      ? 'bg-white dark:bg-slate-800 shadow-3xs text-green-600 dark:text-green-500 font-black'
                      : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
                  }`}
                >
                  <MessageSquare className="h-4 w-4 shrink-0" />
                  <span>WhatsApp Mode</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPreviewPlatform('telegram');
                    setCustomMessage(promoTemplates.telegram);
                  }}
                  className={`py-2 px-3 text-xs font-bold rounded-lg transition-all duration-150 flex items-center justify-center gap-1.5 cursor-pointer ${
                    previewPlatform === 'telegram'
                      ? 'bg-white dark:bg-slate-800 shadow-3xs text-[#24A1DE] font-black'
                      : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
                  }`}
                >
                  <Send className="h-4 w-4 shrink-0" />
                  <span>Telegram Mode</span>
                </button>
              </div>

              {/* Message Drafting Textarea */}
              <div className="space-y-1.5 flex-1 flex flex-col">
                <div className="flex justify-between items-center text-[10.5px] font-sans">
                  <span className="text-gray-400 font-mono">Draft area:</span>
                  <span className="text-gray-500 font-mono font-medium">{customMessage.length} characters</span>
                </div>
                
                <textarea
                  value={customMessage}
                  onChange={(e) => setCustomMessage(e.target.value)}
                  placeholder="Draft your viral NaraEarn invitation pack here..."
                  className="w-full flex-1 min-h-[190px] p-3 text-xs font-sans text-gray-800 dark:text-gray-250 bg-gray-50 dark:bg-slate-950 border border-gray-200 dark:border-slate-800 rounded-xl focus:outline-none focus:border-green-600 dark:focus:border-green-500 focus:bg-white dark:focus:bg-slate-900 transition leading-relaxed resize-none"
                />
              </div>

              {/* Quick Utility Tag Injectors */}
              <div className="space-y-2">
                <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest block text-left">
                  ⚡ Smart Tag Insertion:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      const trimmed = customMessage.trim();
                      setCustomMessage(`${trimmed}\n\nCode: ${refSlug.toUpperCase()}`);
                    }}
                    className="px-2 py-1 bg-gray-50 dark:bg-slate-950 hover:bg-green-50 hover:text-green-700 dark:hover:bg-slate-800 border border-gray-150 dark:border-slate-800 rounded-lg text-[9.5px] font-mono font-black text-gray-600 transition"
                  >
                    + Insert Referral Code
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const trimmed = customMessage.trim();
                      setCustomMessage(`${trimmed}\n\nLink: ${referralLink}`);
                    }}
                    className="px-2 py-1 bg-gray-50 dark:bg-slate-950 hover:bg-green-50 hover:text-green-700 dark:hover:bg-slate-800 border border-gray-150 dark:border-slate-800 rounded-lg text-[9.5px] font-mono font-black text-gray-600 transition"
                  >
                    + Insert Referral Link
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCustomMessage(previewPlatform === 'whatsapp' ? promoTemplates.whatsapp : promoTemplates.telegram);
                    }}
                    className="px-2 py-1 bg-gray-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg text-[9.5px] font-mono font-black text-gray-500 dark:text-gray-300 transition"
                  >
                    ↩️ Clear to Preset
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-gray-100 dark:border-slate-800 flex flex-col sm:flex-row gap-2">
                <button
                  type="button"
                  onClick={() => {
                    try {
                      navigator.clipboard.writeText(customMessage);
                    } catch (e) {}
                    setIsCopiedFromModal(true);
                    setTimeout(() => setIsCopiedFromModal(false), 2000);
                  }}
                  className="flex-1 inline-flex items-center justify-center space-x-1.5 bg-green-600 hover:bg-green-700 text-white font-bold text-xs uppercase tracking-wider py-3.5 rounded-xl cursor-pointer transition shadow-xs"
                >
                  {isCopiedFromModal ? (
                    <>
                      <Check className="h-4 w-4" />
                      <span>Copied to Clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-4 w-4" />
                      <span>Copy Finished Invite</span>
                    </>
                  )}
                </button>
                
                {previewPlatform === 'whatsapp' ? (
                  <a
                    href={`https://api.whatsapp.com/send?text=${encodeURIComponent(customMessage)}`}
                    target="_blank"
                    rel="no_referrer noopener"
                    className="inline-flex items-center justify-center space-x-1 border border-green-200 hover:bg-green-50 text-green-700 font-bold text-[11px] uppercase tracking-wider px-4 py-3.5 rounded-xl transition"
                    referrerPolicy="no-referrer"
                  >
                    <ExternalLink className="h-4 w-4" />
                    <span>Send to WhatsApp</span>
                  </a>
                ) : (
                  <a
                    href={`https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(customMessage)}`}
                    target="_blank"
                    rel="no_referrer noopener"
                    className="inline-flex items-center justify-center space-x-1 border border-blue-200 hover:bg-blue-50 text-blue-700 font-bold text-[11px] uppercase tracking-wider px-4 py-3.5 rounded-xl transition"
                    referrerPolicy="no-referrer"
                  >
                    <ExternalLink className="h-4 w-4" />
                    <span>Send to Telegram</span>
                  </a>
                )}
              </div>
            </div>

            {/* Modal Right Area - Real-time Smartphone Simulation Screen */}
            <div className="w-full md:w-[350px] bg-slate-900 border-t md:border-t-0 border-gray-800 flex flex-col justify-between absolute md:relative inset-y-0 right-0 z-10 md:z-auto translate-x-full md:translate-x-0 hidden md:flex">
              
              {/* Phone Header simulation bar */}
              <div className="p-3.5 bg-slate-950 flex items-center justify-between border-b border-gray-800 text-white select-none">
                <div className="flex items-center gap-2">
                  <div className="h-2.5 w-2.5 rounded-full bg-green-500 animate-pulse" />
                  <span className="font-mono text-[9px] font-black uppercase tracking-widest text-gray-400">Live Mock preview</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsSharePreviewOpen(false)}
                  className="p-1 rounded-full hover:bg-gray-800 text-gray-400 hover:text-white transition cursor-pointer"
                  title="Close Preview Screen"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* High-fidelity Mockup Area */}
              <div className="flex-1 relative overflow-hidden flex flex-col">
                
                {previewPlatform === 'whatsapp' ? (
                  // WhatsApp mockup chat board
                  <div className="flex-1 bg-[#efeae2]/10 dark:bg-slate-950 flex flex-col h-full">
                    {/* Simulated WA Header */}
                    <div className="p-3 bg-[#075e54] text-white flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="h-8 w-8 rounded-full bg-emerald-700 text-white font-extrabold flex items-center justify-center text-xs">
                          NE
                        </div>
                        <div className="text-left font-sans leading-none">
                          <p className="text-xs font-black">NaraEarn Rewards</p>
                          <span className="text-[9px] text-teal-150 text-teal-100 font-medium">online</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <span className="h-1.5 w-1.5 bg-white/40 rounded-full" />
                        <span className="h-1.5 w-1.5 bg-white/40 rounded-full" />
                        <span className="h-1.5 w-1.5 bg-white/40 rounded-full" />
                      </div>
                    </div>
                    
                    {/* Message Bubble Container with custom WA beige texture */}
                    <div className="flex-1 p-4 bg-[#efeae2] overflow-y-auto flex flex-col justify-end text-left relative min-h-[300px]">
                      {/* Chat timestamp sticker */}
                      <div className="mx-auto my-2 px-2.5 py-0.5 bg-white/60 text-gray-500 rounded-md text-[9px] font-mono leading-none select-none uppercase tracking-wide">
                        Today
                      </div>

                      {/* Outgoing Message Bubble */}
                      <div className="relative max-w-[85%] self-end bg-[#d9fdd3] text-gray-800 p-3 rounded-2xl rounded-tr-none shadow-xs border-r-3 border-emerald-500/20 text-[10.5px] font-sans mt-2">
                        {/* Bubble content rendering styled WhatsApp markdown strings */}
                        <div className="leading-relaxed whitespace-pre-wrap select-all">
                          {customMessage || "Type premium invitation text..."}
                        </div>
                        
                        {/* Status elements bottom-right corner */}
                        <div className="flex items-center justify-end gap-1 mt-1 text-[9px] text-gray-450 select-none">
                          <span>{new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })}</span>
                          <span className="text-sky-500 font-bold">✓✓</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  // Telegram Mockup Area
                  <div className="flex-1 bg-[#e7ebf0]/5 dark:bg-slate-950 flex flex-col h-full">
                    {/* Simulated TG Header */}
                    <div className="p-3 bg-[#5288c1] text-white flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="h-8 w-8 rounded-full bg-blue-700 text-white font-extrabold flex items-center justify-center text-xs">
                          TG
                        </div>
                        <div className="text-left font-sans leading-none">
                          <p className="text-xs font-black">NaraEarn Bot</p>
                          <span className="text-[9px] text-[#a5c5e8] font-medium">bot service</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <span className="h-1 w-1 bg-white rounded-full" />
                        <span className="h-1 w-1 bg-white rounded-full" />
                        <span className="h-1 w-1 bg-white rounded-full" />
                      </div>
                    </div>

                    {/* Message Bubble Container with custom TG light blue texture */}
                    <div className="flex-1 p-4 bg-[#f4f5f9] overflow-y-auto flex flex-col justify-end text-left relative min-h-[300px]">
                      {/* Chat timestamp sticker */}
                      <div className="mx-auto my-2 px-2.5 py-0.5 bg-blue-100/50 text-[#5288c1] rounded-full text-[9px] font-bold leading-none select-none">
                        Today
                      </div>

                      {/* Incoming bot preview message */}
                      <div className="relative max-w-[85%] self-start bg-white text-gray-800 p-3 rounded-2xl shadow-xs border-l-2 border-blue-400 text-[10.5px] font-sans">
                        <strong className="text-blue-500 font-bold block mb-0.5 uppercase text-[9px]">Affiliate System Info</strong>
                        <p className="leading-snug text-gray-500">This is how your customized inviter message is formatted and received in a standard Telegram chat dialogue bubble.</p>
                      </div>

                      {/* Outgoing Message Bubble */}
                      <div className="relative max-w-[85%] self-end bg-white text-gray-800 p-3 rounded-2xl shadow-xs text-[10.5px] font-sans mt-3 border-r-2 border-emerald-400">
                        {/* Bubble content rendering styled WhatsApp markdown strings */}
                        <div className="leading-relaxed whitespace-pre-wrap select-all">
                          {customMessage || "Type premium invitation text..."}
                        </div>
                        
                        {/* Status elements bottom-right corner */}
                        <div className="flex items-center justify-end gap-1 mt-1 text-[8.5px] text-gray-400 select-none">
                          <span>{new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })}</span>
                          <span className="text-gray-400">✓</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

              </div>
              
              {/* Phone Footer simulation bar */}
              <div className="p-3 bg-slate-950 text-center select-none text-[9.5px] text-gray-500 font-mono">
                Simulation Screen • Standard Mobile View
              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
}
