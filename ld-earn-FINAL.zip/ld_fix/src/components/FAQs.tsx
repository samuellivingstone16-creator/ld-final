/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useMemo } from 'react';
import { 
  ChevronDown, 
  ChevronUp, 
  Search, 
  Sparkles, 
  Users, 
  TrendingUp, 
  Clock, 
  HelpCircle,
  X 
} from 'lucide-react';

interface FAQItem {
  id: string;
  category: 'earnings' | 'referrals' | 'withdrawals';
  question: string;
  answer: string;
}

const FAQ_DATABASE: FAQItem[] = [
  // Earning Levels
  {
    id: 'el-1',
    category: 'earnings',
    question: 'What are the different Earning Levels, and how do they affect my payouts?',
    answer: 'NairaEarn offers tier-based progression ranks: Level 1 (Bronze - Free/Standard tier) features standard payout rewards. Upgrading to Level 2 (Silver) and Level 3 (Gold Premium/VIP) unlocks up to 3x, 5x, or 10x reward multipliers on your daily micro-task rates, larger direct referral payouts, and reduces bank processing commissions.'
  },
  {
    id: 'el-2',
    category: 'earnings',
    question: 'How do I upgrade to Silver or Gold Premium Earning Levels?',
    answer: 'You can instantly upgrade your account rank via the Profile Settings or Wallet tab. Ranks can be unlocked using your available core earnings balance or by using a One-Time Verification Activation Token obtained from our official Support Admin.'
  },
  {
    id: 'el-3',
    category: 'earnings',
    question: 'Is there a limit to how many daily tasks I can do on my level?',
    answer: 'Yes. Free standard accounts are allowed 1 high-yield primary daily task every 24 hours. Level 2 (Silver) and Level 3 (Gold Premium/VIP) accounts gain priority access to high-paying featured daily tasks and higher frequency of client-funded business campaigns.'
  },
  // Referral Payouts
  {
    id: 'ref-1',
    category: 'referrals',
    question: 'How does the Referral Payout and commission tracking work?',
    answer: 'For every user who registers on NairaEarn using your unique affiliate referral link or code AND completes at least 1 social task, you are instantly credited with a flat ₦500 referral payout. Your referral bonus gets safely wired into your referral balance ledger immediately.'
  },
  {
    id: 'ref-2',
    category: 'referrals',
    question: 'Why has my referral payout not credited or appears as pending?',
    answer: 'Referral credits require that your invitee registers a fresh verified account and completes today\'s active sponsored task to verify active user contribution. This protects against automated sign-up bots. Once they click "Claim" on a task, your ₦500 bonus triggers automatically.'
  },
  {
    id: 'ref-3',
    category: 'referrals',
    question: 'Are there any limits on total referral payouts I can earn?',
    answer: 'No! The NairaEarn affiliate networking code has absolutely no capping limits. You can refer hundreds of users from WhatsApp, Telegram, or Twitter and watch your compound balance skyrocket. Super-affiliate users at Gold levels also unlock a 10% secondary passive network override commission on task earnings.'
  },
  // Withdrawal Timelines
  {
    id: 'wd-1',
    category: 'withdrawals',
    question: 'How long do withdrawals take to arrive in my bank account?',
    answer: 'NairaEarn is directly tied into the Nigerian Inter-Bank Settlement System (NIBSS) instant electronic transfer framework. All bank transfers are verified and clear inside your Nigerian bank account (Wema, GTBank, OPay, Palmpay, Zenith, etc.) within a secure 2-hour compliance and audit queue.'
  },
  {
    id: 'wd-2',
    category: 'withdrawals',
    question: 'What is the minimum and maximum withdrawal threshold?',
    answer: 'The minimum withdrawal target is ₦2,000 for standard task balances, and there is no minimum for referral funds. The maximum per-transaction withdrawal limit is ₦50,000 to maintain direct clearing safety with central switch gateways.'
  },
  {
    id: 'wd-3',
    category: 'withdrawals',
    question: 'Why does my withdrawal status show "Pending Review"?',
    answer: 'During peak bank network congestion or for large sum payouts, transactions go through an automated audit loop to verify the social task proof logs were followed faithfully. These security safety audits are cleared within a few hours.'
  },
  {
    id: 'wd-4',
    category: 'withdrawals',
    question: 'How do I fix a "Bank Account Verification Failed" error?',
    answer: 'Our banking validation portal pulls names in real-time from the NIBSS central database. The name on your receiving bank account MUST match your registered legal name in your Profile Settings. Check for simple typographical spelling errors or verify your BVN status with your bank.'
  }
];

export default function FAQs() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'earnings' | 'referrals' | 'withdrawals'>('all');
  const [expandedId, setExpandedId] = useState<string | null>('el-1');

  const toggleAccordion = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  // Filtered list using useMemo for efficiency
  const filteredFAQs = useMemo(() => {
    return FAQ_DATABASE.filter(item => {
      // Tab filter
      if (activeTab !== 'all' && item.category !== activeTab) {
        return false;
      }
      // Search query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return (
          item.question.toLowerCase().includes(query) ||
          item.answer.toLowerCase().includes(query)
        );
      }
      return true;
    });
  }, [activeTab, searchQuery]);

  return (
    <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-6" id="interactive-faqs-panel">
      {/* FAQ Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <div className="h-7 w-7 rounded-lg bg-green-50 text-green-700 flex items-center justify-center border border-green-100">
            <HelpCircle className="h-4.5 w-4.5 stroke-[2]" />
          </div>
          <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
            KNOWLEDGE BASE
          </span>
        </div>
        <h4 className="font-display font-black text-lg text-gray-950">
          Frequently Asked Questions
        </h4>
        <p className="text-xs text-gray-500 font-sans leading-relaxed">
          Search instant answers regarding upgrade benefits, affiliate structures, tracking logs, and automated NIBSS bank payout cycles.
        </p>
      </div>

      {/* Interactive Search Tool */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
          <Search className="h-4 w-4" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search questions (e.g. Upgrade level, Bank, Referrals...)"
          className="w-full text-xs font-sans pl-9 pr-8 py-2.5 bg-gray-50 border border-gray-200 focus:bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-green-550/10 focus:border-green-600 transition"
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => setSearchQuery('')}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
          >
            <X className="h-3 w-3" />
          </button>
        )}
      </div>

      {/* Categories Switch Tabs */}
      <div className="flex flex-wrap gap-1.5 border-b border-gray-100 pb-3">
        <button
          type="button"
          onClick={() => setActiveTab('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition font-mono border ${
            activeTab === 'all'
              ? 'bg-gray-950 border-gray-950 text-white shadow-3xs'
              : 'bg-gray-50 hover:bg-gray-100 border-transparent text-gray-600'
          }`}
        >
          All Qs({FAQ_DATABASE.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('earnings')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition font-mono border flex items-center gap-1 ${
            activeTab === 'earnings'
              ? 'bg-amber-600 border-amber-600 text-white shadow-3xs'
              : 'bg-gray-50 hover:bg-gray-100 border-transparent text-gray-650'
          }`}
        >
          <TrendingUp className="h-3 w-3" />
          <span>Earning Levels</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('referrals')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition font-mono border flex items-center gap-1 ${
            activeTab === 'referrals'
              ? 'bg-sky-600 border-sky-600 text-white shadow-3xs'
              : 'bg-gray-50 hover:bg-gray-100 border-transparent text-gray-650'
          }`}
        >
          <Users className="h-3 w-3" />
          <span>Referrals</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('withdrawals')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition font-mono border flex items-center gap-1 ${
            activeTab === 'withdrawals'
              ? 'bg-green-700 border-green-700 text-white shadow-3xs'
              : 'bg-gray-50 hover:bg-gray-100 border-transparent text-gray-650'
          }`}
        >
          <Clock className="h-3 w-3" />
          <span>Withdrawals</span>
        </button>
      </div>

      {/* Collapsible Accordion Grid */}
      <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
        {filteredFAQs.map((faq) => {
          const isOpen = expandedId === faq.id;
          
          let categoryColor = 'bg-gray-100 text-gray-600';
          if (faq.category === 'earnings') categoryColor = 'bg-amber-50 text-amber-800 border-amber-200';
          if (faq.category === 'referrals') categoryColor = 'bg-sky-50 text-sky-800 border-sky-200';
          if (faq.category === 'withdrawals') categoryColor = 'bg-green-50 text-green-800 border-green-200';

          return (
            <div 
              key={faq.id}
              className={`rounded-2xl border transition duration-200 text-left overflow-hidden ${
                isOpen 
                  ? 'bg-slate-50/50 border-gray-300 ring-1 ring-gray-900/5' 
                  : 'bg-white border-gray-200 hover:border-gray-300'
              }`}
            >
              <button
                type="button"
                onClick={() => toggleAccordion(faq.id)}
                className="w-full px-4 py-3.5 flex items-start justify-between gap-3 text-left focus:outline-none cursor-pointer"
              >
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className={`px-2 py-0.5 rounded text-[8.5px] font-mono font-bold uppercase border ${categoryColor}`}>
                      {faq.category}
                    </span>
                  </div>
                  <h5 className="text-xs font-black text-gray-900 font-sans tracking-tight leading-snug">
                    {faq.question}
                  </h5>
                </div>
                <div className="shrink-0 text-gray-400 pt-0.5">
                  {isOpen ? <ChevronUp className="h-4 w-4 text-gray-700" /> : <ChevronDown className="h-4 w-4" />}
                </div>
              </button>

              {isOpen && (
                <div className="px-4 pb-4 pt-1 border-t border-gray-100 text-xs text-gray-650 leading-relaxed font-medium bg-white animate-fade-in">
                  <p>{faq.answer}</p>
                </div>
              )}
            </div>
          );
        })}

        {filteredFAQs.length === 0 && (
          <div className="text-center py-8 bg-gray-50 rounded-2xl border border-dashed border-gray-200 text-gray-400 text-xs">
            <p className="font-bold">No answers match your search key.</p>
            <p className="text-[11px] mt-1">Try another keyword or category tab filter above.</p>
          </div>
        )}
      </div>

      {/* Bottom Vendor Quick Note */}
      <div className="p-3 bg-amber-50/50 border border-amber-200 rounded-2xl flex items-start gap-2 text-[11px] text-gray-700 leading-normal">
        <Sparkles className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
        <p>
          Can't find the answer to your specific dispute? Feel free to open a support ticket to the left to raise a complaint directly with central helpdesk routers.
        </p>
      </div>
    </div>
  );
}
