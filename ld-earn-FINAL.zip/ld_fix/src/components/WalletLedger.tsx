/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { EarningActivity } from '../types';
import { formatNaira } from '../utils';
import { 
  Wallet, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Calendar, 
  Search, 
  Filter, 
  CheckCircle, 
  RefreshCw, 
  Sparkles,
  HelpCircle,
  FileSpreadsheet,
  AlertCircle,
  XCircle,
  Clock
} from 'lucide-react';

interface WalletLedgerProps {
  totalBalance: number;
  availableWithdrawal: number;
  activitiesList: EarningActivity[];
  onAddEarningFunds?: (amount: number) => void;
}

export default function WalletLedger({
  totalBalance,
  availableWithdrawal,
  activitiesList,
  onAddEarningFunds,
}: WalletLedgerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'All' | 'Task' | 'Referral' | 'Withdrawal' | 'Bonus'>('All');

  // Income vs Expenses
  const totalInflow = activitiesList
    .filter(a => a && a.isCredit && a.status === 'Successful')
    .reduce((sum, current) => sum + (current ? current.amount : 0), 0);

  const totalOutflow = activitiesList
    .filter(a => a && !a.isCredit && a.status === 'Successful')
    .reduce((sum, current) => sum + (current ? current.amount : 0), 0);

  // Filter logs list
  const filteredActivities = activitiesList.filter(act => {
    if (!act) return false;
    const titleStr = String(act.title || '');
    const idStr = String(act.id || '');
    const detailsStr = String(act.details || '');
    const matchesSearch = titleStr.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          detailsStr.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          idStr.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === 'All' || act.type === filterType;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-8 animate-fade-in max-w-5xl mx-auto">
      
      {/* Intro Header */}
      <div className="text-center max-w-2xl mx-auto select-none">
        <span className="font-mono text-[9px] tracking-widest text-green-605 text-green-600 bg-green-50 px-2.5 py-1 rounded-full uppercase font-black">
          SECURE PAYMENTS & BANK ACCOUNT STATEMENT
        </span>
        <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-gray-950 font-display">
          Your Earnings Wallet Ledger
        </h2>
        <p className="mt-2 text-sm text-gray-500 font-sans leading-relaxed">
          Audit your micro-task commission ledgers, check pending transaction statuses, and review historic outbound digital transfers.
        </p>
      </div>

      {/* Grid: Financial status card & Inflow/Outflow values */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Total Ledger Wallet Card */}
        <div className="md:col-span-1 bg-white rounded-3xl border border-gray-100 p-6 shadow-xs flex flex-col justify-between h-48">
          <div>
            <div className="flex items-center gap-1.5 text-gray-400">
              <Wallet className="h-4.5 w-4.5 text-green-600" />
              <span className="font-mono text-[9px] tracking-widest uppercase font-black">ACCOUNT BALANCE LEDGER</span>
            </div>
            
            <h3 className="text-2xl font-black mt-3 text-gray-950 font-display">
              {formatNaira(totalBalance)}
            </h3>
            <p className="text-[10px] text-gray-550 leading-relaxed font-sans mt-1">
              Includes combined bonus, referrals credit, and completed social shares.
            </p>
          </div>

          <div className="border-t border-gray-100 pt-3">
            <span className="text-[10px] text-gray-400">Available Withdrawal: </span>
            <strong className="text-xs font-bold text-gray-800">{formatNaira(availableWithdrawal)}</strong>
          </div>
        </div>

        {/* Dynamic Cash Inflows Statement */}
        <div className="md:col-span-1 bg-white rounded-3xl border border-gray-105 border-gray-100 p-6 shadow-xs flex flex-col justify-between h-48">
          <div>
            <div className="flex items-center gap-1.5 text-emerald-650 font-semibold text-xs">
              <span className="h-2 w-2 rounded-full bg-green-500" />
              <span className="font-mono text-[9px] tracking-widest text-gray-400 uppercase font-black">CUMULATIVE INCOME</span>
            </div>
            
            <h3 className="text-2xl font-black mt-3 text-green-700 font-display">
              +{formatNaira(totalInflow)}
            </h3>
            <p className="text-[10px] text-gray-500 leading-normal font-sans mt-1">
              Earnings aggregated across social scraper validation triggers and guest invitations.
            </p>
          </div>

          <div className="text-[10px] font-mono text-gray-400 bg-gray-50 px-2.5 py-1 rounded-md flex justify-between">
            <span>Aggregated Inflows</span>
            <span className="font-bold text-gray-700">✓ Fully Audited</span>
          </div>
        </div>

        {/* Dynamic Cash Outflows Statement */}
        <div className="md:col-span-1 bg-white rounded-3xl border border-gray-100 p-6 shadow-xs flex flex-col justify-between h-48">
          <div>
            <div className="flex items-center gap-1.5 text-red-650 font-semibold text-xs">
              <span className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
              <span className="font-mono text-[9px] tracking-widest text-gray-400 uppercase font-black">PENDING & COMPLETED CASHOUTS</span>
            </div>
            
            <h3 className="text-2xl font-black mt-3 text-red-600 font-display">
              -{formatNaira(totalOutflow)}
            </h3>
            <p className="text-[10px] text-gray-505 text-gray-500 leading-normal font-sans mt-1">
              Pending review outbound settlements and successfully issued standard local bank wires.
            </p>
          </div>

          <div className="text-[10px] font-mono text-gray-400 bg-gray-50 px-2.5 py-1 rounded-md flex justify-between">
            <span>Settlement Ledger</span>
            <span className="font-bold text-gray-700">✓ Secure Web3</span>
          </div>
        </div>

      </div>

      {/* Ledger statement list section */}
      <div className="bg-white rounded-3xl border border-gray-100 p-6 shadow-xs space-y-4">
        
        {/* Header filtering tools */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-100 pb-4">
          <div>
            <h3 className="text-sm font-bold text-gray-950 font-display">
              Ledger Statements & Accounts
            </h3>
            <p className="text-[10px] text-gray-500 font-mono mt-0.5">FILTER AND SEARCH VERIFIED TRANSACTIONS</p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            
            {/* Search Input */}
            <div className="relative">
              <span className="absolute inset-y-0 left-3 flex items-center text-gray-400 pointer-events-none">
                <Search className="h-3.5 w-3.5" />
              </span>
              <input
                type="text"
                placeholder="Search description/id..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8.5 pl-9 pr-3.5 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:border-green-500 w-44"
              />
            </div>

            {/* Filter buttons */}
            <div className="flex bg-gray-50 p-1 border border-gray-200 rounded-lg text-[10px] font-mono leading-none">
              {(['All', 'Task', 'Referral', 'Withdrawal', 'Bonus'] as const).map((type) => {
                const isActive = filterType === type;
                return (
                  <button
                    key={type}
                    onClick={() => setFilterType(type)}
                    className={`px-2 py-1 rounded-md font-bold transition uppercase ${
                      isActive ? 'bg-white text-gray-950 shadow-xs' : 'text-gray-400 hover:text-gray-700'
                    }`}
                  >
                    {type}
                  </button>
                );
              })}
            </div>

          </div>
        </div>

        {/* Transaction log rows */}
        <div className="space-y-3">
          {filteredActivities.length === 0 ? (
            <div className="text-center py-12 text-gray-400 font-sans border border-dashed border-gray-150 border-gray-200 rounded-2xl">
              No transactions matching the criteria in local ledgers.
            </div>
          ) : (
            filteredActivities.slice().reverse().map((act) => {
              const isCredit = act.isCredit;
              const isComp = act.status === 'Successful';
              const isPend = act.status === 'Pending';
              
              return (
                <div 
                  key={act.id}
                  id={`ledger-act-${act.id}`}
                  className="p-4 bg-gray-50/50 hover:bg-gray-50 border border-gray-100 rounded-2xl transition flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-start gap-3">
                    <div className={`h-8.5 w-8.5 w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                      isPend ? 'bg-amber-50 text-amber-600 border-amber-100' :
                      act.status === 'Failed' ? 'bg-red-50 text-red-650 border-red-100' :
                      isCredit ? 'bg-green-50 text-green-600 border-green-150' : 'bg-red-50 text-red-650 border-red-150'
                    }`}>
                      {isPend ? (
                        <Clock className="h-5.5 w-5.5 animate-pulse" />
                      ) : act.status === 'Failed' ? (
                        <XCircle className="h-5.5 w-5.5" />
                      ) : isCredit ? (
                        <ArrowDownLeft className="h-5.5 w-5.5" />
                      ) : (
                        <ArrowUpRight className="h-5.5 w-5.5" />
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-gray-950">{act.title}</span>
                        <span className="font-mono text-[9px] bg-white border border-gray-200 text-gray-500 rounded px-1.5 uppercase font-medium">{act.type}</span>
                        <span className="font-mono text-[9px] text-gray-450 text-gray-400 font-bold">Ref: {act.id}</span>
                      </div>
                      
                      {act.details && (
                        <p className="text-[10px] text-gray-500 mt-0.5 font-sans leading-normal">{act.details}</p>
                      )}
                    </div>
                  </div>

                  {/* Right side: Amount and Timestamp status */}
                  <div className="flex items-center justify-between md:justify-end gap-x-6 md:text-right border-t border-gray-100 md:border-none pt-2.5 md:pt-0">
                    <div className="md:hidden">
                      <span className="text-[9px] uppercase tracking-wider text-gray-400 font-mono">Date & Status</span>
                    </div>

                    <div className="flex items-center gap-x-3.5">
                      <div className="font-mono text-[10px] text-gray-500">
                        <span className="block text-right">{act.timestamp.split(' ')[0]}</span>
                        <span className="block text-right text-[9px] text-gray-400 font-bold">{act.timestamp.split(' ')[1] || ''}</span>
                      </div>

                      <div className="text-right">
                        <div className={`font-mono text-xs font-black ${
                          act.status === 'Failed' ? 'text-gray-400 line-through' :
                          isCredit ? 'text-green-600' : 'text-red-650'
                        }`}>
                          {isCredit ? '+' : '-'}{formatNaira(act.amount)}
                        </div>
                        
                        <span className={`inline-flex items-center gap-1 text-[8px] uppercase tracking-wider font-bold ${
                          isComp ? 'text-green-650' : isPend ? 'text-amber-600' : 'text-red-500'
                        }`}>
                          {isComp ? 'SUCCESSFUL' : isPend ? 'PENDING AUDIT' : 'DECLINED'}
                        </span>
                      </div>
                    </div>

                  </div>

                </div>
              );
            })
          )}
        </div>
      </div>

    </div>
  );
}
