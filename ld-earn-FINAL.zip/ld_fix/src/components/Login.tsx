import React, { useState, useEffect } from 'react';
import { 
  User, 
  Mail, 
  Phone, 
  Lock, 
  Key, 
  Gift, 
  Eye, 
  EyeOff, 
  Coins,
  Sparkles,
  Info,
  X,
  ShoppingBag,
  MessageCircle,
  ExternalLink,
  Check,
  ChevronRight,
  ChevronLeft,
  CheckSquare,
  Users,
  CreditCard,
  Loader2,
  Zap,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PLANS, formatNaira, PlanType, getCurrentTimestamp, generateRefID } from '../utils';
import { syncAccounts, syncTokens } from '../lib/cloudSync';
import ldLogo from '../assets/images/ld_logo_1781514983884.jpg';
import { useAdminSettings } from '../App';


interface LoginProps {
  onLogin: (email: string) => void;
  registeredEmail: string;
}

const calculatePasswordStrength = (pass: string) => {
  if (!pass) return { score: 0, label: 'None', color: 'bg-slate-850', textClass: 'text-slate-500' };
  let score = 0;
  if (pass.length >= 6) score += 1;
  if (pass.length >= 10) score += 1;
  if (/[a-z]/.test(pass) && /[A-Z]/.test(pass)) score += 1;
  if (/\d/.test(pass)) score += 1;
  if (/[^A-Za-z0-9]/.test(pass)) score += 1;

  if (score <= 1) {
    return { score, label: 'Weak', color: 'bg-rose-500/80', textClass: 'text-rose-400' };
  } else if (score === 2) {
    return { score, label: 'Fair', color: 'bg-amber-500/80', textClass: 'text-amber-400' };
  } else if (score === 3) {
    return { score, label: 'Good', color: 'bg-yellow-450/80', textClass: 'text-yellow-405' };
  } else if (score === 4) {
    return { score, label: 'Strong', color: 'bg-emerald-500/80', textClass: 'text-emerald-400' };
  } else {
    return { score, label: 'Very Secure', color: 'bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.4)]', textClass: 'text-green-400 font-extrabold' };
  }
};

const renderPasswordStrengthMeter = (pass: string) => {
  if (!pass) return null;
  const strength = calculatePasswordStrength(pass);
  const minLength = pass.length >= 6;
  const hasMixed = /[a-z]/.test(pass) && /[A-Z]/.test(pass);
  const hasNumber = /\d/.test(pass);
  const hasSpecial = /[^A-Za-z0-9]/.test(pass);

  return (
    <div className="mt-2.5 space-y-2 text-left animate-fade-in border border-slate-800/60 bg-slate-900/30 rounded-xl p-3">
      <div className="flex items-center justify-between text-[10px]">
        <span className="text-slate-400 font-mono uppercase tracking-wider">Password Strength</span>
        <span className={`font-bold font-mono tracking-wider uppercase ml-2 ${strength.textClass}`}>
          {strength.label}
        </span>
      </div>

      {/* Progress Bars */}
      <div className="grid grid-cols-5 gap-1 h-1">
        {[1, 2, 3, 4, 5].map((level) => (
          <div
            key={level}
            className={`h-full rounded-full transition-all duration-300 ${
              level <= strength.score ? strength.color : 'bg-slate-800'
            }`}
          />
        ))}
      </div>

      {/* Security Checkpoints */}
      <div className="grid grid-cols-2 gap-x-2 gap-y-1.5 pt-1.5 border-t border-slate-800/40">
        <span className="flex items-center gap-1.5 text-[9.5px]">
          <span className={`inline-flex items-center justify-center w-3 h-3 rounded-full text-[8px] font-bold ${
            minLength ? 'bg-green-950/80 text-green-400 border border-green-800/40' : 'bg-slate-900/60 text-slate-500 border border-slate-800/40'
          }`}>
            {minLength ? '✓' : '•'}
          </span>
          <span className={minLength ? 'text-slate-300 font-mono' : 'text-slate-500 font-mono'}>6+ characters</span>
        </span>

        <span className="flex items-center gap-1.5 text-[9.5px]">
          <span className={`inline-flex items-center justify-center w-3 h-3 rounded-full text-[8px] font-bold ${
            hasMixed ? 'bg-green-950/80 text-green-400 border border-green-800/40' : 'bg-slate-900/60 text-slate-500 border border-slate-800/40'
          }`}>
            {hasMixed ? '✓' : '•'}
          </span>
          <span className={hasMixed ? 'text-slate-300 font-mono' : 'text-slate-500 font-mono'}>Case (aA)</span>
        </span>

        <span className="flex items-center gap-1.5 text-[9.5px]">
          <span className={`inline-flex items-center justify-center w-3 h-3 rounded-full text-[8px] font-bold ${
            hasNumber ? 'bg-green-950/80 text-green-400 border border-green-800/40' : 'bg-slate-900/60 text-slate-500 border border-slate-800/40'
          }`}>
            {hasNumber ? '✓' : '•'}
          </span>
          <span className={hasNumber ? 'text-slate-300 font-mono' : 'text-slate-500 font-mono'}>Digits (0-9)</span>
        </span>

        <span className="flex items-center gap-1.5 text-[9.5px]">
          <span className={`inline-flex items-center justify-center w-3 h-3 rounded-full text-[8px] font-bold ${
            hasSpecial ? 'bg-green-950/80 text-green-400 border border-green-800/40' : 'bg-slate-900/60 text-slate-500 border border-slate-800/40'
          }`}>
            {hasSpecial ? '✓' : '•'}
          </span>
          <span className={hasSpecial ? 'text-slate-300 font-mono' : 'text-slate-500 font-mono'}>Symbol (@#$)</span>
        </span>
      </div>
    </div>
  );
};

export default function Login({ onLogin, registeredEmail }: LoginProps) {
  const [authMode, setAuthMode] = useState<'register' | 'login'>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('ref')) return 'register';
    }
    return (localStorage.getItem('ld_is_registered') === 'true') ? 'login' : 'register';
  });

  const [fullName, setFullName] = useState('');

  // Read live statistics from localStorage for realistic display on landing page
  const liveTotalBalance = typeof window !== 'undefined' ? Number(localStorage.getItem('naira_total_balance') || '1250000') : 1250000;
  const liveTasksCompleted = typeof window !== 'undefined' ? (() => {
    try {
      const list = JSON.parse(localStorage.getItem('naira_activities_list') || '[]');
      const completedCount = list.filter((act: any) => act && act.isCredit && act.type === 'Task').length;
      return completedCount > 0 ? completedCount : 128;
    } catch (e) {
      return 128;
    }
  })() : 128;
  
  const liveReferrals = typeof window !== 'undefined' ? (() => {
    const count = Number(localStorage.getItem('naira_total_referrals') || '0');
    return count > 0 ? count : 56;
  })() : 56;
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState(registeredEmail || '');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [activationToken, setActivationToken] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [acceptedTerms, setAcceptedTerms] = useState(true);
  const [showTermsModal, setShowTermsModal] = useState(false);

  
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [showBuyToken, setShowBuyToken] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetInput, setResetInput] = useState('');
  const [resetStep, setResetStep] = useState<'request' | 'verify' | 'newPassword' | 'success'>('request');
  const [newPassword, setNewPassword] = useState('');
  const [newConfirmPassword, setNewConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [otpCodeInput, setOtpCodeInput] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [otpErrorMsg, setOtpErrorMsg] = useState('');
  const [resetSuccessMsg, setResetSuccessMsg] = useState('');
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [isRealEmailSent, setIsRealEmailSent] = useState<boolean | null>(null);
  const [copiedTokenMsg, setCopiedTokenMsg] = useState('');
  const [selectedBuyPlan, setSelectedBuyPlan] = useState<PlanType>('Solo');
  const [paystackLoading, setPaystackLoading] = useState(false);
  const [paystackError, setPaystackError] = useState('');

  const { vendors: vendorsList, officialWhatsappLink } = useAdminSettings();

  // Pre-load Paystack script on mount to avoid browser popup blockers on mobile devices
  useEffect(() => {
    if (typeof window !== 'undefined' && !(window as any).PaystackPop) {
      const script = document.createElement('script');
      script.src = 'https://js.paystack.co/v2/inline.js';
      script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  const handlePaystackPayment = async () => {
    setPaystackError('');
    setPaystackLoading(true);
    
    // Using live key directly - no backend API call needed
    const publicKey = "pk_live_67afbe44edbc6bd7e9ced3773d7e855308011cef";

    if (!email || !email.includes('@')) {
      setPaystackError('Please enter a valid email address before making payment');
      setPaystackLoading(false);
      return;
    }

    const PaystackPop = (window as any).PaystackPop;
    const customerEmail = email.trim().toLowerCase();
    const amountInNaira = PLANS[selectedBuyPlan].tokenFee;
    const txRef = `LD-PAYSTK-${selectedBuyPlan.toUpperCase()}-${Date.now()}`;

    const handleSuccess = async (response: any) => {
      try {
        setPaystackLoading(true);
        let generatedToken = '';
        const useFallback = true;

        if (useFallback) {
          // Generate activation token locally matching backend format
          const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
          const genPart = (length: number) => {
            let result = '';
            for (let i = 0; i < length; i++) {
              result += characters.charAt(Math.floor(Math.random() * characters.length));
            }
            return result;
          };
          const planUpper = selectedBuyPlan.toUpperCase().substring(0, 4);
          generatedToken = `LD-${planUpper}-${genPart(4)}-${genPart(4)}`;

          // Save this token to the local unused list database so that offline registration validates it successfully!
          let unusedList: string[] = [];
          try {
            const stored = localStorage.getItem('ld_unused_tokens');
            unusedList = stored ? JSON.parse(stored) : [
              'LD-SOLO-WN4X-8BP2-YT9C',
              'LD-SOLO-7MQG-5V6K-RD4L',
              'LD-PREM-4KZ3-8X9B-PJ2W',
              'LD-PREM-9HQF-2TLK-7XMS',
              'LD-VIP-3XWY-9VPL-5NZ6',
              'LD-VIP-8RFT-4KCD-3WQZ',
              'LD-AUTH-9Y8K-4XMD-7WQP'
            ];
          } catch (e) {
            unusedList = [
              'LD-SOLO-WN4X-8BP2-YT9C',
              'LD-SOLO-7MQG-5V6K-RD4L',
              'LD-PREM-4KZ3-8X9B-PJ2W',
              'LD-PREM-9HQF-2TLK-7XMS',
              'LD-VIP-3XWY-9VPL-5NZ6',
              'LD-VIP-8RFT-4KCD-3WQZ',
              'LD-AUTH-9Y8K-4XMD-7WQP'
            ];
          }
          if (!unusedList.includes(generatedToken)) {
            unusedList.push(generatedToken);
            localStorage.setItem('ld_unused_tokens', JSON.stringify(unusedList));
            syncTokensWithServer();
          }
        }

        if (generatedToken) {
          setActivationToken(generatedToken);
          setShowBuyToken(false);
          setSuccessMsg(`Payment Confirmed! Your ${selectedBuyPlan.toUpperCase()} Plan activation code has been generated and autofilled automatically. Please complete registration below.`);
          
          // Smoothly scroll to the token field to guide user attention
          setTimeout(() => {
            const el = document.getElementById('reg-token-input');
            if (el) {
              el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              el.focus();
            }
          }, 100);
        }
      } catch (err: any) {
        console.error("Paystack local sync error: ", err);
        setPaystackError("Network error recording transaction. Please screenshot your payment & message support.");
      } finally {
        setPaystackLoading(false);
      }
    };

    const triggerPayment = (PopClass: any) => {
      setPaystackLoading(true);
      try {
        // v2 inline support: constructor with .newTransaction()
        if (typeof PopClass === 'function' || (PopClass.prototype && PopClass.prototype.newTransaction)) {
          const paystack = new PopClass();
          paystack.newTransaction({
            key: publicKey,
            email: customerEmail,
            amount: amountInNaira * 100, // Paystack works in Kobo (Naira * 100)
            currency: "NGN",
            ref: txRef,
            onSuccess: (response: any) => {
              handleSuccess(response);
            },
            onCancel: () => {
              setPaystackLoading(false);
            }
          });
        } 
        // v1 inline support fallback
        else if (PopClass.setup) {
          const handler = PopClass.setup({
            key: publicKey,
            email: customerEmail,
            amount: amountInNaira * 100,
            currency: "NGN",
            ref: txRef,
            callback: (response: any) => {
              handleSuccess(response);
            },
            onClose: () => {
              setPaystackLoading(false);
            }
          });
          handler.openIframe();
        } else {
          throw new Error("Paystack POP SDK is loaded but could not be initialized.");
        }
      } catch (err: any) {
        console.error("Failed opening paystack popup:", err);
        setPaystackError(err.message || "Failed to launch Paystack payment module.");
        setPaystackLoading(false);
      }
    };

    if (PaystackPop) {
      // If script is already loaded (from our useEffect pre-load), trigger payment synchronously!
      // This is crucial to prevent Safari/mobile popup-blockers from blocking the checkout popup.
      triggerPayment(PaystackPop);
    } else {
      // Fallback dynamic script injection
      setPaystackLoading(true);
      const script = document.createElement('script');
      script.src = 'https://js.paystack.co/v2/inline.js';
      script.async = true;
      script.onload = () => {
        const loadedPop = (window as any).PaystackPop;
        if (loadedPop) {
          triggerPayment(loadedPop);
        } else {
          setPaystackError('Paystack script loaded but payment module was not found.');
          setPaystackLoading(false);
        }
      };
      script.onerror = () => {
        setPaystackError('Failed to load Paystack script. Please check your internet connection.');
        setPaystackLoading(false);
      };
      document.body.appendChild(script);
    }
  };

  const syncAccountsWithServer = async (): Promise<any[]> => {
    try {
      const localStr = localStorage.getItem('ld_accounts_database') || '[]';
      let localAccounts = [];
      try {
        localAccounts = JSON.parse(localStr);
      } catch (e) {
        localAccounts = [];
      }
      
      const updatedAccounts = await syncAccounts(localAccounts);
      localStorage.setItem('ld_accounts_database', JSON.stringify(updatedAccounts));
      return updatedAccounts;
    } catch (err) {
      console.warn('Failed to sync accounts with server:', err);
    }
    return JSON.parse(localStorage.getItem('ld_accounts_database') || '[]');
  };

  const syncTokensWithServer = async (): Promise<void> => {
    try {
      const localUnusedStr = localStorage.getItem('ld_unused_tokens');
      const localUsedStr = localStorage.getItem('ld_used_tokens');
      let localUnused: string[] = [];
      let localUsed: string[] = [];
      try {
        if (localUnusedStr) localUnused = JSON.parse(localUnusedStr);
      } catch (e) {}
      try {
        if (localUsedStr) localUsed = JSON.parse(localUsedStr);
      } catch (e) {}
      
      const localItems: { token: string; status: 'Unused' | 'Used' }[] = [];
      localUnused.forEach(t => {
        if (t && typeof t === 'string') localItems.push({ token: t.trim().toUpperCase(), status: 'Unused' });
      });
      localUsed.forEach(t => {
        if (t && typeof t === 'string') localItems.push({ token: t.trim().toUpperCase(), status: 'Used' });
      });

      const tokensList = await syncTokens(localItems);
      if (tokensList) {
        const unused = tokensList.filter((item: any) => item.status === 'Unused').map((item: any) => item.token);
        const used = tokensList.filter((item: any) => item.status === 'Used').map((item: any) => item.token);
        localStorage.setItem('ld_unused_tokens', JSON.stringify(unused));
        localStorage.setItem('ld_used_tokens', JSON.stringify(used));
      }
    } catch (err) {
      console.warn('Failed to sync tokens with server/cloud:', err);
    }
  };

  React.useEffect(() => {
    // Sync on mount
    syncAccountsWithServer();
    syncTokensWithServer();

    // Parse referral code/slug from URL query parameters on startup
    try {
      const params = new URLSearchParams(window.location.search);
      const ref = params.get('ref');
      if (ref) {
        const uppercaseRef = ref.toUpperCase().trim();
        setReferralCode(uppercaseRef);
        localStorage.setItem('pending_referral_code', uppercaseRef);
        setAuthMode('register');
        setSuccessMsg(`Referral promo code "${uppercaseRef}" detected and applied automatically!`);
        setTimeout(() => setSuccessMsg(''), 4000);
      } else {
        const savedRef = localStorage.getItem('pending_referral_code');
        if (savedRef) {
          setReferralCode(savedRef);
        }
      }
    } catch (err) {
      console.error('Failed to parse URL referral parameter:', err);
    }
  }, []);

  const handleAutoFillDemo = () => {
    setFullName('Livingstone');
    setUsername('livingstone_user');
    setEmail(registeredEmail || 'livingstone0806382@gmail.com');
    setPhoneNumber('+234 803 123 4567');
    setPassword('demo1234');
    setConfirmPassword('demo1234');
    setActivationToken('LD-AUTH-9Y8K-4XMD-7WQP');
    setReferralCode('LD-500');
    setAcceptedTerms(true);
    setErrorMsg('');
    setSuccessMsg('Fields pre-filled successfully!');
    setTimeout(() => setSuccessMsg(''), 2000);
  };

  const handleClearForm = () => {
    setFullName('');
    setUsername('');
    setEmail('');
    setPhoneNumber('');
    setPassword('');
    setConfirmPassword('');
    setActivationToken('');
    setReferralCode('');
    setAcceptedTerms(false);
    setErrorMsg('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (authMode === 'login') {
      if (!email.trim() || !email.includes('@')) {
        setErrorMsg('A valid Email Address is required.');
        return;
      }
      if (!password || password.length < 5) {
        setErrorMsg('Password must be at least 5 characters long.');
        return;
      }

      setIsLoading(true);
      const accounts = await syncAccountsWithServer();
      setIsLoading(false);

      let account = accounts.find((a: any) => a.email.toLowerCase() === email.toLowerCase());

      // If account does not exist in db, check if we can migrate existing global session keys or create default admin
      if (!account) {
        const existingEmail = localStorage.getItem('naira_profile_email');
        if (existingEmail && email.toLowerCase() === existingEmail.toLowerCase()) {
          // Migrate current keys
          account = {
            email: existingEmail,
            password: localStorage.getItem('naira_profile_password') || 'demo1234',
            fullName: localStorage.getItem('naira_profile_name') || 'John Doe',
            profileLevel: localStorage.getItem('naira_profile_level') || 'Solo',
            totalBalance: Number(localStorage.getItem('naira_total_balance') || '0'),
            availableWithdrawal: Number(localStorage.getItem('naira_available_withdrawal') || '0'),
            referralEarnings: Number(localStorage.getItem('naira_referral_earnings') || '0'),
            referralBalance: Number(localStorage.getItem('naira_referral_balance') || '0'),
            taskBalance: Number(localStorage.getItem('naira_task_balance') || '0'),
            totalReferrals: Number(localStorage.getItem('naira_total_referrals') || '0'),
            referralsList: JSON.parse(localStorage.getItem('naira_referrals_list') || '[]'),
            activitiesList: JSON.parse(localStorage.getItem('naira_activities_list') || '[]'),
            refSlug: localStorage.getItem('ld_user_ref_slug') || 'USER-1234',
            refCode: localStorage.getItem('ld_user_ref_code') || '1234',
            profilePhoto: localStorage.getItem('naira_profile_photo') || null
          };
          accounts.push(account);
          localStorage.setItem('ld_accounts_database', JSON.stringify(accounts));
        } else if (email.toLowerCase() === 'livingstone0806382@gmail.com') {
          // Create default pioneer admin account
          account = {
            email: 'livingstone0806382@gmail.com',
            password: 'Stone44@',
            fullName: 'John Doe',
            profileLevel: 'Solo',
            totalBalance: 3500,
            availableWithdrawal: 3500,
            referralEarnings: 0,
            referralBalance: 0,
            taskBalance: 3500,
            totalReferrals: 0,
            referralsList: [],
            activitiesList: [
              {
                id: "BY-5775",
                type: "Bonus",
                title: "First-Time Login Bonus",
                amount: 3500,
                isCredit: true,
                timestamp: "2026-06-30 16:59",
                details: "₦3,500 welcome bonus credited automatically upon your first-time login.",
                status: "Successful"
              }
            ],
            refSlug: 'LD-SOLO-PIONEER',
            refCode: 'PIONEER',
            profilePhoto: null,
            tasks: []
          };
          accounts.push(account);
          localStorage.setItem('ld_accounts_database', JSON.stringify(accounts));
        }
      }

      // If still not found, show error
      if (!account) {
        setErrorMsg('Account not found. Please register to create your secure wallet.');
        return;
      }

      if (password !== account.password) {
        setErrorMsg('Incorrect Password. Please check your credentials or reset your password.');
        return;
      }

      setIsLoading(true);

      // Save user session keys back into global localStorage keys
      localStorage.setItem('naira_profile_email', account.email);
      localStorage.setItem('naira_profile_password', account.password);
      localStorage.setItem('naira_profile_name', account.fullName);
      localStorage.setItem('naira_profile_level', account.profileLevel || 'Solo');
      localStorage.setItem('naira_total_balance', (account.totalBalance || 0).toString());
      localStorage.setItem('naira_available_withdrawal', (account.availableWithdrawal || 0).toString());
      localStorage.setItem('naira_referral_earnings', (account.referralEarnings || 0).toString());
      localStorage.setItem('naira_referral_balance', (account.referralBalance || 0).toString());
      localStorage.setItem('naira_task_balance', (account.taskBalance || 0).toString());
      localStorage.setItem('naira_total_referrals', (account.totalReferrals || 0).toString());
      localStorage.setItem('naira_referrals_list', JSON.stringify(account.referralsList || []));
      localStorage.setItem('naira_activities_list', JSON.stringify(account.activitiesList || []));
      localStorage.setItem('naira_tasks', JSON.stringify(account.tasks || []));
      localStorage.setItem('ld_user_ref_slug', account.refSlug || '');
      localStorage.setItem('ld_user_ref_code', account.refCode || '');
      if (account.profilePhoto) {
        localStorage.setItem('naira_profile_photo', account.profilePhoto);
      } else {
        localStorage.removeItem('naira_profile_photo');
      }

      // Load latest referrals from Supabase (cross-device sync)
      try {
        const { getUserReferrals, getTotalReferralEarnings } = await import('../services/supabaseService');
        const cloudReferrals = await getUserReferrals(account.email);
        if (cloudReferrals && cloudReferrals.length > 0) {
          const totalEarnings = await getTotalReferralEarnings(account.email);
          const referralsList = cloudReferrals.map((r: any) => ({
            id: r.id,
            fullName: r.new_user_name,
            email: r.new_user_email,
            joinedDate: r.created_at ? r.created_at.split('T')[0] : '',
            commissionEarned: r.amount,
            status: r.status || 'Active'
          }));
          localStorage.setItem('naira_referrals_list', JSON.stringify(referralsList));
          localStorage.setItem('naira_referral_earnings', totalEarnings.toString());
          localStorage.setItem('naira_total_referrals', cloudReferrals.length.toString());
        }
      } catch (err) {
        console.warn('Could not load referrals from Supabase, using local data:', err);
      }

      // Simulate authentication postback
      setTimeout(() => {
        setIsLoading(false);
        setSuccessMsg('Logged in successfully!');
        // Keep registration status true
        localStorage.setItem('ld_is_registered', 'true');
        setTimeout(() => {
          onLogin(email);
        }, 1200);
      }, 1000);
    } else {
      // Validations
      if (!fullName.trim()) {
        setErrorMsg('Full Name is required.');
        return;
      }
      if (!username.trim()) {
        setErrorMsg('Username is required.');
        return;
      }
      if (!email.trim() || !email.includes('@')) {
        setErrorMsg('A valid Email Address is required.');
        return;
      }
      if (!phoneNumber.trim()) {
        setErrorMsg('Phone Number is required.');
        return;
      }
      if (!password || password.length < 5) {
        setErrorMsg('Password must be at least 5 characters long.');
        return;
      }
      if (password !== confirmPassword) {
        setErrorMsg('Password and Confirm Password do not match.');
        return;
      }
      const inputToken = activationToken.trim().toUpperCase();
      if (!inputToken) {
        setErrorMsg('An Activation Token is required.');
        return;
      }

      if (!acceptedTerms) {
        setErrorMsg('You must agree to the Terms & Conditions to proceed.');
        return;
      }

      setIsLoading(true);

      let validationSuccess = false;
      let detectedPlan: PlanType = 'Solo';

      const SECURE_FALLBACK_TOKENS = [
        'LD-SOLO-WN4X-8BP2-YT9C',
        'LD-SOLO-7MQG-5V6K-RD4L',
        'LD-PREM-4KZ3-8X9B-PJ2W',
        'LD-PREM-9HQF-2TLK-7XMS',
        'LD-VIP-3XWY-9VPL-5NZ6',
        'LD-VIP-8RFT-4KCD-3WQZ',
        'LD-AUTH-9Y8K-4XMD-7WQP'
      ];

      // Validate token locally (no backend server in this deployment)
      let unusedList: string[] = [];
      try {
        const stored = localStorage.getItem('ld_unused_tokens');
        unusedList = stored ? JSON.parse(stored) : SECURE_FALLBACK_TOKENS;
      } catch (e) {
        unusedList = SECURE_FALLBACK_TOKENS;
      }

      if (unusedList.includes(inputToken)) {
        validationSuccess = true;
        const t = inputToken.toUpperCase().trim();
        if (t.includes('PREM')) detectedPlan = 'Prem';
        else if (t.includes('VIP')) detectedPlan = 'Vip';
        else detectedPlan = 'Solo';

        // Mark used locally
        const updatedUnused = unusedList.filter(t => t !== inputToken);
        localStorage.setItem('ld_unused_tokens', JSON.stringify(updatedUnused));

        let usedList: string[] = [];
        try {
          const storedUsed = localStorage.getItem('ld_used_tokens');
          usedList = storedUsed ? JSON.parse(storedUsed) : [];
        } catch (e) {}
        if (!usedList.includes(inputToken)) {
          usedList.push(inputToken);
          localStorage.setItem('ld_used_tokens', JSON.stringify(usedList));
        }
        syncTokensWithServer();
      }

      if (!validationSuccess) {
        setErrorMsg('Invalid or already used Activation Token. Please buy a unique code from our official Support Admin below.');
        setIsLoading(false);
        return;
      }

      // Simulate secure node verification delay
      setTimeout(async () => {
        setIsLoading(false);

        // Load database of accounts from server
        const accounts = await syncAccountsWithServer();

        // Check if user already exists
        const exists = accounts.some((a: any) => a.email.toLowerCase() === email.toLowerCase());
        if (exists) {
          setErrorMsg('An account with this Email Address is already registered. Please login.');
          return;
        }

        // Determine starting balances based on selected plan - crediting first-time login bonus
        let bonusAmount = 3500;
        if (detectedPlan === 'Prem') {
          bonusAmount = 8000;
        } else if (detectedPlan === 'Vip') {
          bonusAmount = 12500;
        }

        const welcomeBonusActivity = {
          id: generateRefID('BY'),
          type: 'Bonus',
          title: 'First-Time Login Bonus',
          amount: bonusAmount,
          isCredit: true,
          timestamp: getCurrentTimestamp(),
          details: `₦${bonusAmount.toLocaleString()} welcome bonus credited automatically upon your first-time login.`,
          status: 'Successful'
        };

        // Handle referral link/code if provided
        const cleanRefCode = referralCode.replace(/^@/, '').replace(/^LD-/, '').trim().toUpperCase();
        const rawRefCode = referralCode.trim().toUpperCase();
        let referrerCodeFound = '';
        if (rawRefCode) {
          // Find the referrer by refSlug, refCode, username, name, or email
          const referrerIndex = accounts.findIndex((a: any) => {
            const upSlug = a.refSlug?.toUpperCase() || '';
            const upCode = a.refCode?.toUpperCase() || '';
            const upUser = a.username?.toUpperCase() || '';
            const upName = a.fullName?.toUpperCase() || '';
            const upEmail = a.email?.toUpperCase() || '';
            
            return (
              (upSlug && (upSlug === rawRefCode || upSlug === cleanRefCode || upSlug.replace(/^LD-/, '') === cleanRefCode)) ||
              (upCode && (upCode === rawRefCode || upCode === cleanRefCode)) ||
              (upUser && (upUser === rawRefCode || upUser === cleanRefCode)) ||
              (upName && upName === rawRefCode) ||
              (upEmail && upEmail === rawRefCode)
            );
          });

          if (referrerIndex !== -1) {
            const referrer = accounts[referrerIndex];
            const refPlan = referrer.profileLevel || 'Solo';
            const inviteRewardAmount = refPlan === 'Vip' ? 4500 : refPlan === 'Prem' ? 3500 : 1500;

            // Credit the referrer
            referrer.totalReferrals = (referrer.totalReferrals || 0) + 1;
            referrer.referralEarnings = (referrer.referralEarnings || 0) + inviteRewardAmount;
            referrer.totalBalance = (referrer.totalBalance || 0) + inviteRewardAmount;
            referrer.availableWithdrawal = (referrer.availableWithdrawal || 0) + inviteRewardAmount;
            referrer.referralBalance = (referrer.referralBalance || 0) + inviteRewardAmount;

            // Add to referrer's referrals list
            referrer.referralsList = referrer.referralsList || [];
            referrer.referralsList.push({
              id: `uref-${Math.random().toString(36).substring(2, 7)}`,
              fullName: fullName,
              email: email,
              joinedDate: new Date().toISOString().split('T')[0],
              commissionEarned: inviteRewardAmount,
              status: 'Active'
            });

            // Add referral activity log for referrer
            referrer.activitiesList = referrer.activitiesList || [];
            referrer.activitiesList.unshift({
              id: generateRefID('RF'),
              type: 'Referral',
              title: `Referral Registered: ${fullName}`,
              amount: inviteRewardAmount,
              isCredit: true,
              timestamp: getCurrentTimestamp(),
              details: `Your friend ${fullName} (${email}) registered using your code! +₦${inviteRewardAmount.toLocaleString()} has been credited to your Referral Balance.`,
              status: 'Successful'
            });

            referrerCodeFound = referrer.refSlug;

            // Save referral to Supabase for cross-device sync
            try {
              const { addReferral } = await import('../services/supabaseService');
              await addReferral(referrer.email, email, fullName, inviteRewardAmount);
            } catch (err) {
              console.warn('Could not save referral to Supabase:', err);
            }
          }
        }

        // Generate custom ref slug for the new user
        let cleanName = fullName
          .toLowerCase()
          .replace(/[^a-z0-9]/g, '-')
          .replace(/-+/g, '-')
          .replace(/(^-|-$)/g, '');
        const generatedCode = Math.floor(1000 + Math.random() * 9000).toString();
        const newRefSlug = `${cleanName || 'user'}-${generatedCode}`.toUpperCase();

        const newAccount = {
          email,
          password,
          fullName,
          username,
          phoneNumber,
          profileLevel: detectedPlan,
          totalBalance: bonusAmount,
          availableWithdrawal: bonusAmount,
          referralEarnings: 0,
          referralBalance: 0,
          taskBalance: bonusAmount,
          totalReferrals: 0,
          referralsList: [],
          activitiesList: [welcomeBonusActivity],
          refSlug: newRefSlug,
          refCode: generatedCode,
          profilePhoto: null
        };

        accounts.push(newAccount);
        localStorage.setItem('ld_accounts_database', JSON.stringify(accounts));

        // Load new account into global session keys
        localStorage.setItem('naira_profile_email', email);
        localStorage.setItem('naira_profile_name', fullName);
        localStorage.setItem('naira_profile_password', password);
        localStorage.setItem('naira_profile_level', detectedPlan);
        localStorage.setItem('naira_total_balance', bonusAmount.toString());
        localStorage.setItem('naira_available_withdrawal', bonusAmount.toString());
        localStorage.setItem('naira_referral_earnings', '0');
        localStorage.setItem('naira_referral_balance', '0');
        localStorage.setItem('naira_task_balance', bonusAmount.toString());
        localStorage.setItem('naira_total_referrals', '0');
        localStorage.setItem('naira_referrals_list', JSON.stringify([]));
        localStorage.setItem('naira_activities_list', JSON.stringify([welcomeBonusActivity]));
        localStorage.setItem('naira_tasks', JSON.stringify([]));
        localStorage.setItem('ld_user_ref_slug', newRefSlug);
        localStorage.setItem('ld_user_ref_code', generatedCode);
        localStorage.removeItem('naira_profile_photo');
        localStorage.setItem(`ld_first_login_credited_${email}`, 'true');

        // Mark as registered so it only displays login on subsequent visits
        localStorage.setItem('ld_is_registered', 'true');

        // Sync back to server
        await syncAccountsWithServer();

        setSuccessMsg(referrerCodeFound 
          ? `Account created under sponsor "${referrerCodeFound}"! Authenticating...`
          : 'Account created successfully on secure ledger! Authenticating...'
        );
        setTimeout(() => {
          onLogin(email);
        }, 1500);
      }, 1200);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f5af19] via-[#e65c00] to-[#b45309] flex items-center justify-center p-4 sm:p-6 lg:p-8 font-sans antialiased text-white selection:bg-yellow-400 selection:text-slate-900">
      
      {/* Dynamic ambient background features for visual depth */}
      <div className="absolute top-0 left-0 right-0 h-96 bg-gradient-to-b from-white/10 to-transparent pointer-events-none -z-10" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,rgba(230,92,0,0.15),transparent_70%)] pointer-events-none -z-10" />

      {/* Main Container: Original premium dark slate login container style, elevated design */}
      <div className="w-full max-w-3xl bg-slate-950/90 border border-slate-800/80 rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.5)] overflow-hidden flex flex-col transition-all duration-350 backdrop-blur-md">
        
        {/* Top vibrant golden-green visual status strip */}
        <div className="h-1 bg-gradient-to-r from-yellow-450 via-green-400 to-yellow-500" />
        
        {/* Header Panel (Rich Dark Slate theme inside with pure white write-up and key elements) */}
        <div className="bg-slate-900/80 text-white p-6 sm:p-8 flex items-center justify-between relative overflow-hidden border-b border-slate-800/60">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_10%_20%,rgba(34,197,94,0.06),transparent_60%)] pointer-events-none" />
          
          <div className="flex items-center gap-3.5 relative z-10 w-full sm:w-auto">
            <div className="h-11 w-11 rounded-xl overflow-hidden flex items-center justify-center border border-slate-700 bg-slate-900 p-0.5 shadow-inner hover:scale-105 transition-transform duration-300">
              <img 
                src={ldLogo} 
                alt="LD Logo" 
                className="h-full w-full object-cover rounded-lg" 
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="text-left select-none">
              <h2 className="font-display font-black text-xs tracking-widest text-white uppercase block leading-none">LD PORTAL</h2>
              <p className="text-[9px] font-mono font-bold text-green-400 uppercase tracking-widest leading-none mt-1.5">DAILY REWARDS & SECURE WALLET</p>
            </div>
          </div>
        </div>

        {/* Form Workspace with original login slate container background & crisp white write-up */}
        <div className="p-6 sm:p-8 flex-1 bg-slate-950/20">
          
          {/* Header & Slogan Description Block */}
          <div className="mb-6 space-y-4">
            <div className="text-center md:text-left select-none">
              <h1 className="font-display font-black text-lg tracking-tight text-white uppercase">
                {authMode === 'login' ? 'SECURE ACCOUNT SIGN IN' : 'REGISTRATION FORM'}
              </h1>
            </div>

            {/* Premium original-style platform info box with pure white write-up */}
            <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-2xl space-y-3 backdrop-blur-sm shadow-lg border-l-4 border-l-green-500">
              <div className="flex gap-2.5 items-center">
                <div className="h-7 w-7 rounded-lg bg-green-500/10 border border-green-500/20 flex items-center justify-center text-green-400 shrink-0">
                  <Info className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-[11px] font-black font-mono text-green-400 tracking-wider uppercase">
                    {authMode === 'login' ? 'Welcome Back!' : 'Welcome to LD NairaEarn'}
                  </h3>
                </div>
              </div>

              <div className="text-[12px] text-slate-300 leading-relaxed font-sans font-medium pl-1 text-left">
                <p>
                  {authMode === 'login' ? (
                    <>
                      Log in to access your active micro-tasks daily, track your direct referral bonuses, and request fast automated withdrawals to your Nigerian bank account.
                    </>
                  ) : (
                    <>
                      Join our decentralized campaign ecosystem. Interact with sponsored content, review products, refer partners, and receive stable payouts daily.
                    </>
                  )}
                </p>
              </div>
            </div>

            {/* Visual 'How It Works' Stepper for Registration Page */}
            {authMode === 'register' && (
              <div className="bg-slate-905/40 border border-slate-900 p-4 rounded-2xl space-y-3 shadow-md animate-scale-in" id="how-it-works-stepper">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black text-green-400 tracking-widest uppercase font-mono">
                    HOW IT WORKS
                  </span>
                  <div className="h-px bg-slate-850 flex-grow" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5">
                  <div className="p-3 bg-slate-900/40 border border-slate-800/50 rounded-xl relative overflow-hidden flex flex-col justify-between hover:border-slate-700/80 transition-all cursor-default group">
                    <span className="absolute right-2.5 top-1 text-[20px] font-extrabold text-slate-800/30 group-hover:text-green-500/20 transition-colors select-none font-mono">1</span>
                    <div className="text-left">
                      <h4 className="text-[10px] font-bold text-white uppercase font-mono tracking-wide leading-tight group-hover:text-green-400 transition-colors">Register</h4>
                      <p className="text-[9px] text-slate-400 leading-normal mt-1">Create your secure user credentials profile.</p>
                    </div>
                  </div>
                  <div className="p-3 bg-slate-900/40 border border-slate-800/50 rounded-xl relative overflow-hidden flex flex-col justify-between hover:border-slate-700/80 transition-all cursor-default group">
                    <span className="absolute right-2.5 top-1 text-[20px] font-extrabold text-slate-800/30 group-hover:text-green-500/20 transition-colors select-none font-mono">2</span>
                    <div className="text-left">
                      <h4 className="text-[10px] font-bold text-green-400 uppercase font-mono tracking-wide leading-tight group-hover:text-green-300 transition-colors">Activate</h4>
                      <p className="text-[9px] text-slate-400 leading-normal mt-1">Acquire an official activation key from our Support Admin.</p>
                    </div>
                  </div>
                  <div className="p-3 bg-slate-900/40 border border-slate-800/50 rounded-xl relative overflow-hidden flex flex-col justify-between hover:border-slate-700/80 transition-all cursor-default group">
                    <span className="absolute right-2.5 top-1 text-[20px] font-extrabold text-slate-800/30 group-hover:text-green-500/20 transition-colors select-none font-mono">3</span>
                    <div className="text-left">
                      <h4 className="text-[10px] font-bold text-white uppercase font-mono tracking-wide leading-tight group-hover:text-green-400 transition-colors">Tasks</h4>
                      <p className="text-[9px] text-slate-400 leading-normal mt-1">Follow simple daily media & promo links.</p>
                    </div>
                  </div>
                  <div className="p-3 bg-slate-900/40 border border-slate-800/50 rounded-xl relative overflow-hidden flex flex-col justify-between hover:border-slate-700/80 transition-all cursor-default group">
                    <span className="absolute right-2.5 top-1 text-[20px] font-extrabold text-slate-800/30 group-hover:text-green-500/20 transition-colors select-none font-mono">4</span>
                    <div className="text-left">
                      <h4 className="text-[10px] font-bold text-green-400 uppercase font-mono tracking-wide leading-tight group-hover:text-green-300 transition-colors">Earn</h4>
                      <p className="text-[9px] text-slate-400 leading-normal mt-1">Receive daily credits & referral commissions.</p>
                    </div>
                  </div>
                  <div className="p-3 bg-slate-900/40 border border-slate-800/50 rounded-xl relative overflow-hidden flex flex-col justify-between hover:border-slate-700/80 transition-all cursor-default group">
                    <span className="absolute right-2.5 top-1 text-[20px] font-extrabold text-slate-800/30 group-hover:text-green-500/20 transition-colors select-none font-mono">5</span>
                    <div className="text-left">
                      <h4 className="text-[10px] font-bold text-white uppercase font-mono tracking-wide leading-tight group-hover:text-green-400 transition-colors">Withdraw</h4>
                      <p className="text-[9px] text-slate-400 leading-normal mt-1">Liquidate instantly to your local bank account.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Form validation alert badges */}
          {errorMsg && (
            <div id="registration-error-alert" className="bg-rose-950/80 border border-rose-500/30 text-rose-200 p-3.5 rounded-xl text-xs font-semibold mb-5 leading-relaxed shadow-lg text-left animate-shake">
              ⚠️ {errorMsg}
            </div>
          )}
          {successMsg && (
            <div id="registration-success-alert" className="bg-green-950/80 border border-green-500/30 text-green-200 p-3.5 rounded-xl text-xs font-bold mb-5 leading-relaxed shadow-lg text-left animate-pulse">
              ✓ {successMsg}
            </div>
          )}

          {/* Welcome to ldearn Promo/Introductory Card Headered with Emerald Gradient Accent */}
          {authMode === 'register' && (
            <div className="bg-gradient-to-r from-slate-900 to-slate-950/80 border border-slate-800 p-5 rounded-2xl space-y-4 backdrop-blur-sm bg-opacity-95 shadow-xl animate-fade-in mb-6 text-left" id="ldearn-welcomer">
              <div className="flex gap-2.5 items-center justify-between border-b border-slate-800/80 pb-3">
                <div className="flex gap-2.5 items-center">
                  <div className="h-8 w-8 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 shrink-0">
                    <Sparkles className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black font-display tracking-tight text-white uppercase">
                      Welcome to ldearn
                    </h3>
                  </div>
                </div>
                <span className="px-2 py-0.5 bg-green-500/15 text-green-400 border border-green-500/30 text-[8px] rounded font-black font-mono tracking-wider">OFFICIAL REWARDS PORTAL</span>
              </div>

              <div className="text-xs text-slate-350 leading-relaxed space-y-3 pl-1 font-sans font-medium">
                <p>
                  We're excited to have you join our growing community!
                </p>
                <p>
                  <strong className="text-white font-semibold">ldearn</strong> is a trusted rewards platform where members can earn money by completing simple daily tasks, participating in promotional activities, and inviting friends through our referral program. Our goal is to provide a rewarding and engaging experience while helping users create additional income opportunities online.
                </p>
                <p>
                  Create your account today to access daily earning opportunities, track your progress through your personal dashboard, and start building your rewards.
                </p>
                <p>
                  Join thousands of members already earning on our platform.
                </p>
              </div>

              <div className="bg-slate-950/50 rounded-xl p-3 border border-slate-800/60 flex items-center gap-2 mt-2">
                <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse shrink-0" />
                <span className="text-[11px] font-bold text-green-400 leading-none">
                  Register now and begin your earning journey today!
                </span>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {authMode === 'login' ? (
              /* LOGIN FORM INPUTS */
              <div className="grid grid-cols-1 gap-4 max-w-md mx-auto">
                {/* Email Address */}
                <div className="space-y-1.5 animate-fade-in text-left">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                    Email Address
                  </label>
                  <div className="relative group">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                      <Mail className="h-4 w-4" />
                    </span>
                    <input
                      id="login-email-input"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. yourname@example.com"
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 focus:bg-slate-900/90 transition duration-240"
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-1.5 animate-fade-in text-left">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      Secure Password
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setResetInput(email || '');
                        setResetSuccessMsg('');
                        setOtpErrorMsg('');
                        setResetStep('request');
                        setNewPassword('');
                        setNewConfirmPassword('');
                        setShowNewPassword(false);
                        setOtpCodeInput('');
                        setShowForgotPassword(true);
                      }}
                      className="text-[10px] font-semibold text-green-400 hover:text-green-300 hover:underline cursor-pointer focus:outline-none transition-colors"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative group">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                      <Lock className="h-4 w-4" />
                    </span>
                    <input
                      id="login-password-input"
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-10 py-2.5 bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 focus:bg-slate-900/90 transition duration-240"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-350 cursor-pointer transition-colors"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* REGISTRATION FORM INPUTS */
              <>
                {/* 2-Column Responsive Input Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-fade-in text-left">
                  
                  {/* 1. Full Name */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      <span className="text-green-450 font-extrabold bg-green-950/40 border border-green-800/20 px-1 py-0.5 rounded text-[9px]">01</span> Full Name
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <User className="h-4 w-4" />
                      </span>
                      <input
                        id="reg-fullname-input"
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="e.g. John Doe"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 focus:bg-slate-900/90 transition duration-240"
                      />
                    </div>
                  </div>

                  {/* 2. Username */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      <span className="text-green-450 font-extrabold bg-green-950/40 border border-green-800/20 px-1 py-0.5 rounded text-[9px]">02</span> Username
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <User className="h-4 w-4" />
                      </span>
                      <input
                        id="reg-username-input"
                        type="text"
                        required
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="e.g. john_ld"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 focus:bg-slate-900/90 transition duration-240"
                      />
                    </div>
                  </div>

                  {/* 3. Email Address */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      <span className="text-green-450 font-extrabold bg-green-950/40 border border-green-800/20 px-1 py-0.5 rounded text-[9px]">03</span> Email Address
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <Mail className="h-4 w-4" />
                      </span>
                      <input
                        id="reg-email-input"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="john.doe@example.com"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 focus:bg-slate-900/90 transition duration-240"
                      />
                    </div>
                  </div>

                  {/* 4. Phone Number */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      <span className="text-green-450 font-extrabold bg-green-950/40 border border-green-800/20 px-1 py-0.5 rounded text-[9px]">04</span> Phone Number
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <Phone className="h-4 w-4" />
                      </span>
                      <input
                        id="reg-phone-input"
                        type="text"
                        required
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        placeholder="e.g. +234 803 123 4567"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 focus:bg-slate-900/90 transition duration-240"
                      />
                    </div>
                  </div>

                  {/* 5. Password */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      <span className="text-green-450 font-extrabold bg-green-950/40 border border-green-800/20 px-1 py-0.5 rounded text-[9px]">05</span> Password
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <Lock className="h-4 w-4" />
                      </span>
                      <input
                        id="reg-password-input"
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-10 pr-10 py-2.5 bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 focus:bg-slate-900/90 transition duration-240"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-350 cursor-pointer transition-colors"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    {renderPasswordStrengthMeter(password)}
                  </div>

                  {/* 6. Confirm Password */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      <span className="text-green-450 font-extrabold bg-green-950/40 border border-green-800/20 px-1 py-0.5 rounded text-[9px]">06</span> Confirm Password
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <Lock className="h-4 w-4" />
                      </span>
                      <input
                        id="reg-confirmpassword-input"
                        type={showConfirmPassword ? 'text' : 'password'}
                        required
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-10 pr-10 py-2.5 bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 focus:bg-slate-900/90 transition duration-240"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-350 cursor-pointer transition-colors"
                      >
                        {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  {/* 7. Activation Token */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                        <span className="text-green-45a font-extrabold bg-green-950/40 border border-green-800/20 px-1 py-0.5 rounded text-[9px]">07</span> Activation Code
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowBuyToken(true)}
                        className="text-[9px] font-bold text-green-400 hover:text-green-300 transition-colors uppercase font-mono flex items-center gap-0.5 cursor-pointer bg-green-500/10 border border-green-500/20 px-1.5 py-0.5 rounded"
                      >
                        🔑 No Token? Buy One
                      </button>
                    </div>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <Key className="h-4 w-4" />
                      </span>
                      <input
                        id="reg-token-input"
                        type="text"
                        required
                        value={activationToken}
                        onChange={(e) => setActivationToken(e.target.value)}
                        placeholder="e.g. LD-SOLO-WN4X-8BP2-YT9C"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs font-mono text-white placeholder-slate-600 uppercase focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 focus:bg-slate-900/90 transition duration-240"
                      />
                    </div>
                  </div>

                  {/* 8. Referral Code (Optional) */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      <span className="text-green-45a font-extrabold bg-green-950/40 border border-green-800/20 px-1 py-0.5 rounded text-[9px]">08</span> Inviter Code (Optional)
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <Gift className="h-4 w-4" />
                      </span>
                      <input
                        id="reg-refcode-input"
                        type="text"
                        value={referralCode}
                        onChange={(e) => setReferralCode(e.target.value)}
                        placeholder="e.g. LD-500"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs font-mono text-white placeholder-slate-600 uppercase focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 focus:bg-slate-900/90 transition duration-240"
                      />
                    </div>
                  </div>

                </div>

                {/* Terms and Conditions Checkbox */}
                <div className="pt-2 text-left">
                  <label className="flex items-start gap-2.5 cursor-pointer select-none group">
                    <input
                      id="reg-terms-checkbox"
                      type="checkbox"
                      required
                      checked={acceptedTerms}
                      onChange={(e) => setAcceptedTerms(e.target.checked)}
                      className="h-4 w-4 mt-0.5 rounded text-green-500 focus:ring-green-500/20 border-slate-700 bg-slate-900 transition cursor-pointer"
                    />
                    <span className="text-[11px] font-semibold text-slate-350 leading-normal transition">
                      I agree to the{' '}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setShowTermsModal(true);
                        }}
                        className="text-green-400 hover:text-green-300 underline font-bold cursor-pointer bg-transparent border-0 p-0 hover:no-underline transition"
                      >
                        Terms & Conditions
                      </button>
                    </span>
                  </label>
                </div>
              </>
            )}

            {/* Create Account Submission Button in pristine format matching login */}
            <div className="pt-3 font-semibold">
              <button
                id="create-account-submit-btn"
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 py-3.5 bg-green-500 hover:bg-green-400 disabled:bg-slate-800 text-slate-950 font-black text-xs uppercase tracking-widest rounded-xl transition duration-200 cursor-pointer shadow-lg active:scale-[0.99] border border-green-400/20"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-slate-900/40 border-t-slate-900 rounded-full animate-spin" />
                    <span>{authMode === 'login' ? 'SIGNING IN...' : 'CREATING ACCOUNT...'}</span>
                  </>
                ) : (
                  <>
                    <span>{authMode === 'login' ? 'SIGN IN / ENTER PORTAL' : 'CREATE ACCOUNT'}</span>
                  </>
                )}
              </button>
            </div>

            {/* Toggle Switch helper action button */}
            <div className="text-center pt-3 border-t border-slate-900/60 mt-3 flex flex-col gap-2.5 items-center">
              <button
                id="toggle-auth-mode-btn"
                type="button"
                onClick={() => {
                  setErrorMsg('');
                  setSuccessMsg('');
                  setAuthMode(authMode === 'login' ? 'register' : 'login');
                }}
                className="text-xs font-semibold text-slate-350 hover:text-green-400 transition underline decoration-dotted underline-offset-4 cursor-pointer"
              >
                {authMode === 'login' 
                  ? "Don't have an account? Access Registration Form" 
                  : "Already registered? Go to Secure Sign In"}
              </button>


            </div>
          </form>
        </div>

        {/* Footer Info Label in high quality dark typography */}
        <div className="bg-slate-950/80 border-t border-slate-900 px-8 py-3.5 flex items-center justify-between text-[10px] text-slate-500 font-mono">
          <span>SECURE WALLET CORE v5.0</span>
          <span className="flex items-center gap-1.5 text-green-400 font-semibold select-none">
            <span className="h-1.5 w-1.5 rounded-full bg-green-400 animate-pulse" />
            LEDGER SECURE
          </span>
        </div>

      </div>

      {/* PURCHASE TOKEN SECURE DIALOG OVERLAY */}
      {showBuyToken && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-sm overflow-y-auto animate-fade-in">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
            
            {/* Header decoration */}
            <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5 text-green-400" />
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider font-display">Token Dispatch Desk</h3>
                  <p className="text-[10px] text-slate-400 font-mono">AUTOMATED & MERCHANDISED ROUTING</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowBuyToken(false);
                  setCopiedTokenMsg('');
                }}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-6 max-h-[85vh] overflow-y-auto">
              
              {/* Plan Picker Selector inside Purchase modal */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                  1. Select Your Target Earning Tier
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Solo', 'Prem', 'Vip'] as PlanType[]).map((pType) => {
                    const plan = PLANS[pType];
                    const isSel = selectedBuyPlan === pType;
                    return (
                      <button
                        key={pType}
                        type="button"
                        onClick={() => {
                          setSelectedBuyPlan(pType);
                          setCopiedTokenMsg('');
                        }}
                        className={`p-2.5 rounded-xl border text-center flex flex-col items-center justify-center transition cursor-pointer ${
                          isSel
                            ? 'bg-green-500/10 border-green-500 text-green-400 font-bold'
                            : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-705'
                        }`}
                      >
                        <span className="text-[10px] uppercase font-black tracking-wide block">{pType} Plan</span>
                        <span className="text-[9px] text-slate-400 mt-0.5 block">{formatNaira(plan.tokenFee)}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Real details of chosen plan */}
              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-850 space-y-2 text-[11px] text-slate-350">
                <div className="flex justify-between items-center pb-1.5 border-b border-slate-800/40">
                  <span className="text-slate-405">Purchase Fee:</span>
                  <strong className="text-white text-xs font-mono">{formatNaira(PLANS[selectedBuyPlan].tokenFee)}</strong>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-y-1.5 gap-x-4 pt-1 font-mono text-[9.5px]">
                  <div>• Daily earnings: <strong className="text-amber-400">+{formatNaira(PLANS[selectedBuyPlan].dailyTaskPaid)}/day</strong></div>
                  <div>• Referral bonus: <strong className="text-emerald-400">+{formatNaira(PLANS[selectedBuyPlan].refPaid)}/ref</strong></div>
                  <div>• Min Draw: <strong className="text-slate-200">{formatNaira(PLANS[selectedBuyPlan].minWithdrawalTask)}</strong></div>
                </div>
              </div>

              {/* Pay Instantly with Paystack (Automated Method) */}
              <div className="space-y-4 border-t border-slate-800/50 pt-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CreditCard className="h-4.5 w-4.5 text-blue-400" />
                    <h4 className="text-[11px] font-bold text-white uppercase tracking-wider font-mono">⚡ Pay Online (Instant Code)</h4>
                  </div>
                  <span className="bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[8px] font-black font-mono uppercase px-1.5 py-0.5 rounded animate-pulse">
                    AUTOMATED
                  </span>
                </div>

                <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-3.5 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full blur-2xl pointer-events-none" />
                  
                  <p className="text-[10.5px] text-slate-350 leading-relaxed font-sans">
                    Skip manual WhatsApp transfers! Securely pay <strong>{formatNaira(PLANS[selectedBuyPlan].tokenFee)}</strong> instantly with your Debit Card, Bank App, or USSD via Paystack. Your activation code will be generated and filled automatically!
                  </p>

                  <button
                    type="button"
                    onClick={handlePaystackPayment}
                    disabled={paystackLoading}
                    className="w-full py-3 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 disabled:opacity-50 text-white text-xs font-black uppercase tracking-wider rounded-xl transition duration-200 cursor-pointer shadow-md shadow-blue-500/15 flex items-center justify-center gap-2"
                  >
                    {paystackLoading ? (
                      <>
                        <Loader2 className="h-3.5 w-3.5 animate-spin text-white" />
                        <span>Initializing Secure Gateway...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="h-3.5 w-3.5 text-white fill-current animate-pulse" />
                        <span>Instant Pay {formatNaira(PLANS[selectedBuyPlan].tokenFee)}</span>
                      </>
                    )}
                  </button>

                  {paystackError && (
                    <p className="text-[10px] text-red-400 font-mono text-center bg-red-950/20 border border-red-900/30 py-1.5 px-2 rounded-lg">
                      ⚠ {paystackError}
                    </p>
                  )}
                </div>
              </div>

              {/* Buy via WhatsApp (Official Method) */}
              <div className="space-y-4 border-t border-slate-800/50 pt-5">
                <div className="flex items-center gap-2">
                  <MessageCircle className="h-4.5 w-4.5 text-green-400" />
                  <h4 className="text-[11px] font-bold text-white uppercase tracking-wider font-mono">Contact Verified Admin & Vendor Agents (WhatsApp)</h4>
                </div>
                
                <p className="text-[11px] text-slate-350 leading-relaxed font-sans">
                  Contact our official Support Admin or any of our registered vendor distributors below on WhatsApp to purchase your secure activation token:
                </p>

                <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
                  {/* Official Support Admin */}
                  <a
                    href={officialWhatsappLink.startsWith('http') ? officialWhatsappLink : `https://wa.me/${officialWhatsappLink.replace(/\D/g, '')}?text=${encodeURIComponent(
                      `Hello, I want to purchase a ${selectedBuyPlan.toUpperCase()} PLAN Activation Token. My name is ${fullName || 'New User'}. Please send me the payment details.`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-between gap-3 p-3 bg-slate-950/80 hover:bg-emerald-950/20 border border-slate-800 hover:border-emerald-700/50 rounded-xl transition cursor-pointer group"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="h-7 w-7 rounded-lg bg-green-500/10 flex items-center justify-center text-green-400">
                        <MessageCircle className="h-4 w-4" />
                      </div>
                      <div className="text-left">
                        <span className="text-[10px] font-black text-emerald-400 uppercase tracking-wider block font-mono">Official Support Admin</span>
                        <span className="text-[9px] text-slate-400 font-mono block">Direct Primary Verification</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 bg-emerald-500/5 border border-emerald-500/15 text-emerald-400 text-[9px] font-bold font-mono uppercase tracking-wider px-2 py-1 rounded-lg group-hover:bg-emerald-500 group-hover:text-slate-950 transition">
                      <span>Message Admin</span>
                      <ExternalLink className="h-2.5 w-2.5 stroke-[2.5]" />
                    </div>
                  </a>

                  {/* Registered Vendors list */}
                  {vendorsList && vendorsList.map((agent, idx) => (
                    <a
                      key={idx}
                      href={`https://wa.me/${agent.phone}?text=${encodeURIComponent(
                        `Hello, I want to purchase a ${selectedBuyPlan.toUpperCase()} PLAN Activation Token. My name is ${fullName || 'New User'}. Please send me the payment details.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full flex items-center justify-between gap-3 p-3 bg-slate-950/80 hover:bg-emerald-950/20 border border-slate-800 hover:border-emerald-800/50 rounded-xl transition cursor-pointer group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="h-7 w-7 rounded-lg bg-green-500/10 flex items-center justify-center text-green-400">
                          <MessageCircle className="h-4 w-4" />
                        </div>
                        <div className="text-left">
                          <span className="text-[10px] font-black text-white uppercase tracking-wider block font-mono">{agent.label}</span>
                          <span className="text-[9.5px] text-slate-450 font-mono block">{agent.display}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 bg-emerald-500/5 border border-emerald-500/15 text-emerald-400 text-[9px] font-bold font-mono uppercase tracking-wider px-2 py-1 rounded-lg group-hover:bg-emerald-500 group-hover:text-slate-950 transition">
                        <span>Message Agent</span>
                        <ExternalLink className="h-2.5 w-2.5 stroke-[2.5]" />
                      </div>
                    </a>
                  ))}
                </div>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="bg-slate-950/85 px-6 py-3 border-t border-slate-850 flex items-center justify-between text-[9px] text-slate-500 font-mono">
              <span>LD NAIRA TOKEN CO.</span>
              <span>SECURE ACCESS v5.0</span>
            </div>

          </div>
        </div>
      )}

      {/* FORGOT PASSWORD DIALOG OVERLAY */}
      {showForgotPassword && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-sm overflow-y-auto animate-fade-in" id="forgot-password-modal">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
            
            {/* Header decoration */}
            <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-green-400" />
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider font-display">Secure Recovery Vault</h3>
                  <p className="text-[10px] text-slate-400 font-mono">CLIENT LEDGER OTP RECOVERY SYSTEM</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowForgotPassword(false);
                  setResetSuccessMsg('');
                  setOtpCodeInput('');
                  setOtpErrorMsg('');
                  setResetStep('request');
                }}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-5 max-h-[85vh] overflow-y-auto text-left">
              
              <div className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-4 space-y-3">
                <div className="flex items-start gap-2.5">
                  <span className="text-[18px] select-none">🔑</span>
                  <div>
                    <h4 className="text-xs font-bold text-white uppercase font-mono tracking-wider text-green-405 border-b border-slate-800 pb-1.5">Reset Your Password</h4>
                    <p className="text-[11px] text-slate-350 leading-relaxed mt-2 font-sans">
                      Enter your registered email address or phone number below. We will send you a secure recovery code to reset your password instantly.
                    </p>
                  </div>
                </div>
              </div>

              {resetStep === 'request' && (
                /* Step 1: Input email/phone and trigger OTP */
                <div className="space-y-4 animate-fade-in">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      Your Registered Email or Phone Number
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        {resetInput.trim() && (resetInput.includes('@') || !/^\+?\d+$/.test(resetInput.trim().replace(/\s/g, ''))) ? (
                          <Mail className="h-4 w-4" />
                        ) : (
                          <Phone className="h-4 w-4" />
                        )}
                      </span>
                      <input
                        type="text"
                        required
                        value={resetInput}
                        onChange={(e) => setResetInput(e.target.value)}
                        placeholder="e.g. name@example.com or +234 803 123 4567"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 transition duration-240"
                      />
                    </div>

                  </div>

                  {otpErrorMsg && (
                    <div className="p-3 bg-rose-950/30 border border-rose-800/40 rounded-xl text-[10.5px] text-rose-400 font-mono leading-relaxed animate-fade-in">
                      ⚠️ {otpErrorMsg}
                    </div>
                  )}

                  <button
                    type="button"
                    disabled={isSendingOtp}
                    onClick={async () => {
                      const trimmed = resetInput.trim();
                      if (!trimmed) {
                        setOtpErrorMsg('Please specify your registered Email or Phone Number first.');
                        return;
                      }
                      if (trimmed.includes('@') && !trimmed.includes('.')) {
                        setOtpErrorMsg('Please double check and enter a valid email address.');
                        return;
                      }

                      setIsSendingOtp(true);
                      setOtpErrorMsg('');
                      setResetSuccessMsg('');

                      const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
                      setGeneratedOtp(randomCode);

                      // No backend server in this deployment - use local OTP flow directly
                      setIsRealEmailSent(false);
                      setResetStep('verify');
                      setIsSendingOtp(false);
                    }}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:from-slate-800 disabled:to-slate-850 disabled:text-slate-500 text-slate-950 font-bold font-mono text-[10.5px] uppercase tracking-wider text-center transition cursor-pointer select-none flex items-center justify-center gap-1.5"
                  >
                    {isSendingOtp ? (
                      <>
                        <span className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                        <span>Sending Recovery Code...</span>
                      </>
                    ) : (
                      <span>Send Recovery Code</span>
                    )}
                  </button>
                </div>
              )}

              {resetStep === 'verify' && (
                /* Step 2: Verification field & simulated incoming message preview */
                <div className="space-y-4 animate-fade-in">
                  
                  {isRealEmailSent ? (
                    /* Clean email sent confirmation alert */
                    <div className="p-4 bg-emerald-950/25 border border-emerald-850/50 rounded-xl text-left animate-fade-in">
                      <p className="text-[11px] text-emerald-200 leading-relaxed font-sans">
                        A secure 6-digit recovery code has been sent to your email address: <strong className="text-white font-mono">{resetInput}</strong>. Please check your Inbox and Spam/Junk folder.
                      </p>
                    </div>
                  ) : (
                    /* Realtime simulated Mailbox inbox presentation */
                    <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-[11px] font-sans space-y-2.5 text-left relative overflow-hidden shadow-inner">
                      <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 text-[10px] uppercase font-mono text-slate-400">
                        <span className="flex items-center gap-1.5">
                          <span className="h-1.5 w-1.5 rounded-full bg-yellow-450 animate-pulse" />
                          📬 SIMULATED INCOMING EMAIL INBOX
                        </span>
                        <span>1 SECOND AGO</span>
                      </div>

                      <div className="space-y-1">
                        <div className="text-[10px] text-slate-400"><span className="text-slate-550 font-mono">From:</span> security@ldearn.com.ng</div>
                        <div className="text-[10px] text-slate-400"><span className="text-slate-550 font-mono">To:</span> <strong className="text-slate-300 font-mono">{resetInput}</strong></div>
                        <div className="text-xs font-bold text-white mt-1">Subject: Secure Authorization Passcode - ldearn Recovery Check</div>
                      </div>

                      <div className="bg-slate-900 border border-slate-800/80 rounded-lg p-3 space-y-2 mt-2 font-sans relative">
                        <p className="text-slate-300 text-[10.5px] leading-relaxed">
                          Hello user,
                        </p>
                        <p className="text-slate-350 text-[10.5px] leading-relaxed">
                          We received a secure credentials lookup check from your device. Please use the high-availability security passcode below to synchronize your browser storage and reset your password safely:
                        </p>
                        <div className="text-center py-2.5 bg-slate-950/80 rounded border border-slate-800/60 my-2 flex items-center justify-center gap-3">
                          <strong className="text-teal-400 font-mono text-lg tracking-widest pr-1 select-all">{generatedOtp}</strong>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(generatedOtp);
                              alert('Code Copied to clipboard!');
                            }}
                            className="text-[9px] bg-slate-800 hover:bg-slate-770 font-bold px-2 py-1 text-slate-300 rounded font-mono border border-slate-750"
                          >
                            COPY CODE
                          </button>
                        </div>
                        <p className="text-[9.5px] text-slate-500 font-mono leading-none">
                          Ref Code: LD-RECOVERY-KEY // SECURE CLIENT LEDGER
                        </p>
                      </div>

                      {/* Helpful tip about SMTP setup */}
                      <div className="mt-2.5 pt-2 border-t border-slate-850/60 text-[9.5px] text-slate-500 leading-relaxed italic">
                        💡 Want to get real emails? Define your own SMTP credentials (<code className="text-slate-450 font-mono">SMTP_USER</code> and <code className="text-slate-450 font-mono">SMTP_PASS</code>) in your AI Studio secrets panel!
                      </div>
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      Enter 6-Digit Verification Code
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <Key className="h-4 w-4" />
                      </span>
                      <input
                        type="text"
                        maxLength={6}
                        required
                        value={otpCodeInput}
                        onChange={(e) => setOtpCodeInput(e.target.value.replace(/\D/g, ''))}
                        placeholder="e.g. 123456"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs font-sans text-white text-center tracking-widest font-mono placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 transition duration-240"
                      />
                    </div>
                  </div>

                  {otpErrorMsg && (
                    <div className="p-3 bg-rose-950/30 border border-rose-800/40 rounded-xl text-[10.5px] text-rose-400 font-mono leading-relaxed animate-fade-in">
                      ⚠️ {otpErrorMsg}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setResetStep('request');
                        setOtpCodeInput('');
                        setOtpErrorMsg('');
                      }}
                      className="w-1/3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold font-mono text-[10.5px] uppercase tracking-wider text-center transition cursor-pointer select-none"
                    >
                      Back
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (otpCodeInput.trim() !== generatedOtp) {
                          setOtpErrorMsg('The verification code you entered is invalid. Please double check.');
                          return;
                        }
                        setOtpErrorMsg('');
                        setResetStep('newPassword');
                      }}
                      className="w-2/3 py-2.5 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-slate-950 font-bold font-mono text-[10.5px] uppercase tracking-wider text-center transition cursor-pointer select-none"
                    >
                      Confirm Code
                    </button>
                  </div>
                </div>
              )}

              {resetStep === 'newPassword' && (
                /* Step 3: Enter new secure password with live visual strength meter */
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!newPassword || newPassword.length < 5) {
                      setOtpErrorMsg('Password must be at least 5 characters long.');
                      return;
                    }
                    if (newPassword !== newConfirmPassword) {
                      setOtpErrorMsg('Passwords do not match. Please verify.');
                      return;
                    }

                    // Save the new password to local cache registry
                    localStorage.setItem('naira_profile_password', newPassword);
                    localStorage.setItem('naira_profile_email', resetInput);
                    localStorage.setItem('ld_is_registered', 'true');
                    
                    // Pre-fill main screen credentials for immediate seamless entry
                    setEmail(resetInput);
                    setPassword(newPassword);
                    setConfirmPassword(newPassword);

                    setOtpErrorMsg('');
                    setResetStep('success');
                  }}
                  className="space-y-4 animate-fade-in"
                >
                  <div className="bg-slate-950/50 border border-slate-800 rounded-xl p-3 text-[10.5px] text-green-400 font-mono flex items-center gap-2">
                    <span>⚡</span>
                    <span>Verification Successful! Choose a robust new passcode.</span>
                  </div>

                  {/* New Password input */}
                  <div className="space-y-1.5 text-left">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center justify-between opacity-90">
                      <span>Define New Password</span>
                      <button
                        type="button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        className="text-slate-500 hover:text-white transition cursor-pointer font-semibold"
                      >
                        {showNewPassword ? 'Hide Password' : 'Show Password'}
                      </button>
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <Lock className="h-4 w-4" />
                      </span>
                      <input
                        type={showNewPassword ? 'text' : 'password'}
                        required
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="At least 5 characters"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 transition duration-240"
                      />
                    </div>
                    {/* Instant password strength visual feedback inside recovery wizard */}
                    {renderPasswordStrengthMeter(newPassword)}
                  </div>

                  {/* Confirm New Password input */}
                  <div className="space-y-1.5 text-left">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono flex items-center gap-1 opacity-90">
                      Confirm New Password
                    </label>
                    <div className="relative group">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-500 group-focus-within:text-green-400 transition-colors">
                        <Lock className="h-4 w-4" />
                      </span>
                      <input
                        type={showNewPassword ? 'text' : 'password'}
                        required
                        value={newConfirmPassword}
                        onChange={(e) => setNewConfirmPassword(e.target.value)}
                        placeholder="Re-enter password passcode"
                        className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs font-sans text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-green-450/10 focus:border-green-450 transition duration-240"
                      />
                    </div>
                  </div>

                  {otpErrorMsg && (
                    <div className="p-3 bg-rose-950/30 border border-rose-800/40 rounded-xl text-[10.5px] text-rose-400 font-mono leading-relaxed animate-fade-in">
                      ⚠️ {otpErrorMsg}
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-slate-950 font-bold font-mono text-[10.5px] uppercase tracking-wider text-center transition cursor-pointer select-none"
                  >
                    Confirm & Reset Password
                  </button>
                </form>
              )}

              {resetStep === 'success' && (
                /* Step 4: Success card redirecting to auth screen */
                <div className="space-y-4 animate-fade-in text-center py-3">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-green-500/10 border border-green-500/30 text-green-450 text-lg mb-1">
                    ✓
                  </div>
                  <h4 className="text-sm font-bold text-white uppercase font-display tracking-wider">Access Restored successfully!</h4>
                  <p className="text-[11px] text-slate-350 leading-relaxed font-sans max-w-sm mx-auto">
                    Your password has been successfully configured over this device's local memory registry. For your convenience, the login credentials form has been pre-filled with your newly restored information.
                  </p>

                  <button
                    type="button"
                    onClick={() => {
                      setShowForgotPassword(false);
                      setResetSuccessMsg('');
                      setOtpCodeInput('');
                      setOtpErrorMsg('');
                      setResetStep('request');
                      setNewPassword('');
                      setNewConfirmPassword('');
                    }}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-slate-950 font-bold font-mono text-[10.5px] uppercase tracking-wider text-center transition cursor-pointer select-none"
                  >
                    Log In Now
                  </button>
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="bg-slate-950/85 px-6 py-3 border-t border-slate-850 flex items-center justify-between text-[9px] text-slate-500 font-mono">
              <span>LD NAIRA TOKEN CO.</span>
              <span>SECURE ACCESS v5.0</span>
            </div>

          </div>
        </div>
      )}

      {/* TERMS & CONDITIONS DIALOG OVERLAY */}
      {showTermsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md overflow-y-auto animate-fade-in text-left text-white" id="terms-conditions-modal">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
            
            {/* Header decoration */}
            <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-green-450" />
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider font-display">Terms & Conditions</h3>
                  <p className="text-[10px] text-slate-400 font-mono">LD NAIRA TOKEN CO. / PLATFORM AGREEMENT & CHARTER</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowTermsModal(false)}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Content - beautifully formatted legal scroll */}
            <div className="p-6 space-y-5 max-h-[65vh] overflow-y-auto text-left scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-slate-950">
              
              <div className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-4 space-y-2">
                <div className="flex items-start gap-2.5">
                  <span className="text-[18px] select-none">⚖️</span>
                  <div>
                    <h4 className="text-xs font-bold text-white uppercase font-mono tracking-wider text-green-400 border-b border-slate-800 pb-1.5">Official Membership Rules</h4>
                    <p className="text-[11px] text-slate-350 leading-relaxed mt-2 font-sans">
                      Please read these Terms and Conditions carefully before creating an account or purchasing any activation tokens. By registering, verifying, or completing tasks on this platform, you agree to be bound by these rules.
                    </p>
                  </div>
                </div>
              </div>

              {/* Sections */}
              <div className="space-y-4 font-sans text-xs text-slate-300 leading-relaxed">
                
                <section className="space-y-1.5">
                  <h5 className="font-bold text-white uppercase font-mono text-[11px] text-green-400 flex items-center gap-1.5">
                    <span className="text-slate-500 font-mono">01.</span> Account Eligibility & Activation
                  </h5>
                  <p className="pl-5 text-slate-400">
                    To access the platform's sponsored premium earning systems, members must register and activate their account using an official One-Time Activation Token. These tokens can be acquired directly from our official Support Admin or registered vendor agents. Activation fees are strictly non-refundable and constitute an active pledge for platform service maintenance.
                  </p>
                </section>

                <section className="space-y-1.5 border-t border-slate-800/40 pt-3">
                  <h5 className="font-bold text-white uppercase font-mono text-[11px] text-green-400 flex items-center gap-1.5">
                    <span className="text-slate-500 font-mono">02.</span> Legitimate Task Completion Rules
                  </h5>
                  <p className="pl-5 text-slate-400">
                    Members earn tokens and credit rewards by completing sponsored daily tasks (including YouTube subscriptions, social posts, following profiles, or watching videos). All tasks must be completed manually and legitimately. Any use of automated scripts, browser extensions, artificial bots, spoofed API payloads, or clicking tasks without actual completion will result in an immediate and permanent lock on your account and forfeiture of all accumulated earnings.
                  </p>
                </section>

                <section className="space-y-1.5 border-t border-slate-800/40 pt-3">
                  <h5 className="font-bold text-white uppercase font-mono text-[11px] text-green-400 flex items-center gap-1.5">
                    <span className="text-slate-500 font-mono">03.</span> Multi-Account & Sybil Policy
                  </h5>
                  <p className="pl-5 text-slate-400">
                    To maintain fairness and ensure high-quality traffic for our daily business sponsors, each individual is strictly limited to one primary account. Registering multiple accounts using the same internet IP address, device fingerprints, or recycled wallet addresses to harvest daily rewards is prohibited. Violation of this multi-account policy will lead to automatic system blacklist restrictions.
                  </p>
                </section>

                <section className="space-y-1.5 border-t border-slate-800/40 pt-3">
                  <h5 className="font-bold text-white uppercase font-mono text-[11px] text-green-400 flex items-center gap-1.5">
                    <span className="text-slate-500 font-mono">04.</span> Wallet Earnings, Upgrades & Settlement
                  </h5>
                  <p className="pl-5 text-slate-400">
                    Wallet balances represent virtual earnings that are eligible for settlement into bank accounts once minimum cashout thresholds are reached. Earning tiers (Solo, Silver, Gold, or Ultimate) dictate the daily cap and the referral multipliers. Withdrawal requests undergo a manual verification pipeline to audit the validity of tasks completed. Processing times typically range from 1 to 24 hours depending on network traffic and banking queues.
                  </p>
                </section>

                <section className="space-y-1.5 border-t border-slate-800/40 pt-3">
                  <h5 className="font-bold text-white uppercase font-mono text-[11px] text-green-400 flex items-center gap-1.5">
                    <span className="text-slate-500 font-mono">05.</span> Referral Program & Abuse
                  </h5>
                  <p className="pl-5 text-slate-400">
                    We offer promotional referral bonuses for members who invite active new users. Referrals must be genuine, unique individuals. Self-referrals (referring your own secondary accounts) or deploying promotional spam bots on WhatsApp/Telegram groups is strictly prohibited. The system automatically flags pattern matches and reserves the right to freeze suspicious referral credits.
                  </p>
                </section>

                <section className="space-y-1.5 border-t border-slate-800/40 pt-3">
                  <h5 className="font-bold text-white uppercase font-mono text-[11px] text-green-400 flex items-center gap-1.5">
                    <span className="text-slate-500 font-mono">06.</span> Disclaimers & Discretionary Limitations
                  </h5>
                  <p className="pl-5 text-slate-400">
                    LD Naira Token Co. acts as a mediator bridging brand sponsors with micro-earning participants. Sponsor campaign budgets fluctuate, and the availability of Daily Tasks or specific reward sizes is subject to external commercial factors. We make no guarantees of continuous uninterrupted task pools. The system administration reserves the ultimate right to update reward algorithms, service charges, or terminate accounts of non-compliant members.
                  </p>
                </section>

              </div>

            </div>

            {/* Accept / Done Button */}
            <div className="bg-slate-950 px-6 py-4 border-t border-slate-800 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => {
                  setAcceptedTerms(true);
                  setShowTermsModal(false);
                }}
                className="px-5 py-2.5 rounded-xl bg-green-500 hover:bg-green-400 text-slate-950 font-bold font-mono text-[10px] uppercase tracking-wider transition cursor-pointer"
              >
                Accept Terms
              </button>
            </div>

            {/* Modal Footer */}
            <div className="bg-slate-950/85 px-6 py-3 border-t border-slate-850 flex items-center justify-between text-[9px] text-slate-500 font-mono">
              <span>LD NAIRA TOKEN CO.</span>
              <span>VERIFIED POLICY AGREEMENT v5.0</span>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
