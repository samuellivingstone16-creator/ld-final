import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Search, 
  Copy, 
  Check, 
  Banknote, 
  ShieldAlert, 
  Coins, 
  Download, 
  User, 
  ArrowDownLeft, 
  TrendingUp, 
  Building,
  CheckCircle,
  X,
  Plus,
  Eye,
  Camera,
  AlertCircle
} from 'lucide-react';
import { SocialTask } from '../types';

export interface GlobalWithdrawal {
  id: string;
  email: string;
  fullName: string;
  amount: number;
  bankName: string;
  accountNumber: string;
  accountName: string;
  category: 'Referral' | 'Task';
  status: 'Pending' | 'Successful' | 'Failed';
  timestamp: string;
  details?: string;
  txHash?: string; // Simulated reference code post payment
}

// Prepopulated mock cashout requests to bring the dashboard to life immediately if empty
const INITIAL_GLOBAL_WITHDRAWALS: GlobalWithdrawal[] = [];

interface AdminWithdrawalsProps {
  triggerToast: (msg: string) => void;
  // Trigger user session activities list synchronization if needed
  onWithdrawalProcessed?: (wdId: string, nextStatus: 'Successful' | 'Failed', remarks: string) => void;
  tasks?: SocialTask[];
  onApproveTask?: (taskId: string) => void;
  onRejectTask?: (taskId: string, reason: string) => void;
  withdrawals?: GlobalWithdrawal[];
}

export default function AdminWithdrawals({ 
  triggerToast, 
  onWithdrawalProcessed,
  tasks = [],
  onApproveTask,
  onRejectTask,
  withdrawals: propWithdrawals
}: AdminWithdrawalsProps) {
  const [withdrawals, setWithdrawals] = useState<GlobalWithdrawal[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Successful' | 'Failed'>('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  // Tab State: 'withdrawals' | 'tasks'
  const [activeAdminView, setActiveAdminView] = useState<'withdrawals' | 'tasks'>('withdrawals');
  const [taskFilter, setTaskFilter] = useState<'All' | 'Verifying' | 'Completed' | 'Available' | 'Expired'>('Verifying');
  const [rejectReason, setRejectReason] = useState('');
  const [selectedRejectTaskId, setSelectedRejectTaskId] = useState<string | null>(null);
  const [zoomedTaskScreenshot, setZoomedTaskScreenshot] = useState<string | null>(null);
  
  // Selected withdrawal for decision modal
  const [selectedWd, setSelectedWd] = useState<GlobalWithdrawal | null>(null);
  const [actionRemarks, setActionRemarks] = useState('');
  const [manualTxHash, setManualTxHash] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync prop withdrawals with state if supplied
  useEffect(() => {
    if (propWithdrawals && Array.isArray(propWithdrawals) && propWithdrawals.length > 0) {
      setWithdrawals(propWithdrawals);
    }
  }, [propWithdrawals]);

  // Load withdrawals from localStorage
  useEffect(() => {
    if (propWithdrawals && Array.isArray(propWithdrawals) && propWithdrawals.length > 0) {
      setWithdrawals(propWithdrawals);
      return;
    }
    const saved = localStorage.getItem('naira_global_withdrawals');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Filter out dummy/demo/mock prepopulated entries to ensure "only real ones not demo" shows
          const filtered = parsed.filter((w: any) => 
            w.id !== 'WD-889102-X' && 
            w.id !== 'WD-771239-Y' && 
            w.id !== 'WD-113420-K' && 
            w.id !== 'WD-112349-B' && 
            w.id !== 'WD-551092-Z'
          );
          setWithdrawals(filtered);
          if (filtered.length !== parsed.length) {
            localStorage.setItem('naira_global_withdrawals', JSON.stringify(filtered));
          }
        } else {
          setWithdrawals(INITIAL_GLOBAL_WITHDRAWALS);
        }
      } catch (e) {
        setWithdrawals(INITIAL_GLOBAL_WITHDRAWALS);
      }
    } else {
      localStorage.setItem('naira_global_withdrawals', JSON.stringify(INITIAL_GLOBAL_WITHDRAWALS));
      setWithdrawals(INITIAL_GLOBAL_WITHDRAWALS);
    }
  }, []);

  // Save changes helper
  const saveWithdrawalsList = (updated: GlobalWithdrawal[]) => {
    const filtered = updated.filter((w: any) => 
      w.id !== 'WD-889102-X' && 
      w.id !== 'WD-771239-Y' && 
      w.id !== 'WD-113420-K' && 
      w.id !== 'WD-112349-B' && 
      w.id !== 'WD-551092-Z'
    );
    setWithdrawals(filtered);
    localStorage.setItem('naira_global_withdrawals', JSON.stringify(filtered));
  };

  // Sync listener: listen to local storage writes for new withdrawals placed in other views
  useEffect(() => {
    const handleStorageChange = () => {
      const saved = localStorage.getItem('naira_global_withdrawals');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const filtered = parsed.filter((w: any) => 
              w.id !== 'WD-889102-X' && 
              w.id !== 'WD-771239-Y' && 
              w.id !== 'WD-113420-K' && 
              w.id !== 'WD-112349-B' && 
              w.id !== 'WD-551092-Z'
            );
            setWithdrawals(filtered);
          }
        } catch (e) {}
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Copy quick routing string for bank application input 
  const handleCopyClipboard = (text: string, identifier: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(identifier);
    triggerToast('Copied to clipboard!');
    setTimeout(() => setCopiedId(null), 1500);
  };

  // Copy combined payout details for fast manual transfer (A huge help!)
  const handleCopyBulkDetails = (wd: GlobalWithdrawal) => {
    const textToCopy = `Bank: ${wd.bankName} | A/C: ${wd.accountNumber} | Name: ${wd.accountName} | Amount: ₦${wd.amount.toLocaleString()}`;
    handleCopyClipboard(textToCopy, `bulk-${wd.id}`);
    triggerToast('Direct Transfer template copied!');
  };

  // Trigger processed workflow
  const handleProcessAction = (nextStatus: 'Successful' | 'Failed') => {
    if (!selectedWd) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const updated = withdrawals.map(w => {
        if (w.id === selectedWd.id) {
          const finalRemarks = actionRemarks.trim() || (nextStatus === 'Successful' 
            ? 'Approved and disbursed manually via bank application transfers.' 
            : 'Rejected compliance audit check. Linked details failed verification.');
          
          return {
            ...w,
            status: nextStatus,
            details: finalRemarks,
            txHash: manualTxHash.trim() || undefined
          };
        }
        return w;
      });

      saveWithdrawalsList(updated);

      // Propagate state sync back to primary user activities tracker in parent component
      if (onWithdrawalProcessed) {
        onWithdrawalProcessed(
          selectedWd.id, 
          nextStatus, 
          actionRemarks.trim() || (nextStatus === 'Successful' 
            ? `Disbursed to A/C: ${selectedWd.accountNumber} (${selectedWd.accountName}). Manual payment confirmed.` 
            : `Declined: ${actionRemarks || "Verification audit failed."}`)
        );
      }

      triggerToast(`Transaction ${selectedWd.id} successfully marked as ${nextStatus.toUpperCase()}!`);
      setSelectedWd(null);
      setActionRemarks('');
      setManualTxHash('');
      setIsSubmitting(false);
    }, 1200);
  };

  // Force add a dummy pending withdrawal for testing
  const handleCreateTestWithdrawal = () => {
    const names = ['Emmanuel Nwachukwu', 'Blessing Alabi', 'Yusuf Ibrahim', 'Oluwatobi Adebambo'];
    const banks = ['Access Bank', 'OPay', 'Moneypoint MFB', 'Zenith Bank', 'Kuda Bank'];
    const selectedName = names[Math.floor(Math.random() * names.length)];
    const selectedBank = banks[Math.floor(Math.random() * banks.length)];
    const dummyId = `WD-${Math.floor(100000 + Math.random() * 900000)}`;
    const randomAmount = Math.floor((3000 + Math.random() * 25000) / 500) * 500;
    
    const testWd: GlobalWithdrawal = {
      id: dummyId,
      email: `${selectedName.toLowerCase().replace(' ', '.')}@gmail.com`,
      fullName: selectedName,
      amount: randomAmount,
      bankName: selectedBank,
      accountNumber: String(Math.floor(1000000000 + Math.random() * 9000000000)),
      accountName: selectedName.toUpperCase(),
      category: Math.random() > 0.4 ? 'Task' : 'Referral',
      status: 'Pending',
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    const updated = [testWd, ...withdrawals];
    saveWithdrawalsList(updated);
    triggerToast(`Created a simulated withdrawal request from ${selectedName} for testing!`);
  };

  // Filtering and sorting lists
  const filteredWithdrawals = withdrawals
    .filter(w => {
      if (!w) return false;
      const fn = String(w.fullName || '');
      const accNum = String(w.accountNumber || '');
      const bn = String(w.bankName || '');
      const an = String(w.accountName || '');
      const em = String(w.email || '');
      const wid = String(w.id || '');
      const matchesSearch = 
        fn.toLowerCase().includes(searchTerm.toLowerCase()) ||
        accNum.includes(searchTerm) ||
        bn.toLowerCase().includes(searchTerm.toLowerCase()) ||
        an.toLowerCase().includes(searchTerm.toLowerCase()) ||
        em.toLowerCase().includes(searchTerm.toLowerCase()) ||
        wid.toLowerCase().includes(searchTerm.toLowerCase());
      
      if (statusFilter === 'All') return matchesSearch;
      return w.status === statusFilter && matchesSearch;
    })
    .sort((a, b) => {
      // 1. Pending status priority (always show pending at the top)
      if (a.status === 'Pending' && b.status !== 'Pending') return -1;
      if (a.status !== 'Pending' && b.status === 'Pending') return 1;
      
      const timeA = new Date(a.timestamp.replace(' ', 'T')).getTime();
      const timeB = new Date(b.timestamp.replace(' ', 'T')).getTime();
      
      // 2. Both are Pending: sort by timestamp ascending (oldest first, i.e. FIFO)
      if (a.status === 'Pending' && b.status === 'Pending') {
        return timeA - timeB;
      }
      
      // 3. Both are completed (Successful or Failed): sort by timestamp descending (newest first)
      return timeB - timeA;
    });

  // Calculate sum counts for audit metrics
  const pendingCount = withdrawals.filter(w => w.status === 'Pending').length;
  const pendingVolume = withdrawals.filter(w => w.status === 'Pending').reduce((acc, c) => acc + c.amount, 0);
  
  const successCount = withdrawals.filter(w => w.status === 'Successful').length;
  const successVolume = withdrawals.filter(w => w.status === 'Successful').reduce((acc, c) => acc + c.amount, 0);

  const failedCount = withdrawals.filter(w => w.status === 'Failed').length;

  return (
    <div className="bg-white rounded-3xl border border-gray-150 p-6 sm:p-8 shadow-xs space-y-6" id="admin-withdrawals-ledger-panel">
      
      {/* Tab Header Dashboard controls */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-gray-200/80 pb-5">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 bg-emerald-550 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-xl flex items-center justify-center">
            <Coins className="h-5.5 w-5.5" />
          </div>
          <div>
            <h3 className="font-extrabold text-base uppercase tracking-wider text-slate-900 font-mono">
              Cashout Verification desk
            </h3>
            <p className="text-[11px] text-gray-500 leading-normal mt-0.5">
              Review, copy bank parameters, process transfers, and update compliance payout statuses for all users.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleCreateTestWithdrawal}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-800 border border-gray-250 rounded-xl text-[10.5px] font-bold font-mono uppercase tracking-wide transition cursor-pointer active:scale-95"
            title="Inject simulated user cashout to test payouts layout"
          >
            <Plus className="h-3.5 w-3.5 text-slate-500" />
            <span>Simulate User Payout</span>
          </button>
        </div>
      </div>

      {/* Admin View Option Toggle */}
      <div className="flex border-b border-gray-150 p-1 bg-gray-50/80 rounded-2xl max-w-md">
        <button
          onClick={() => setActiveAdminView('withdrawals')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold rounded-xl transition cursor-pointer ${
            activeAdminView === 'withdrawals' 
              ? 'bg-white text-gray-900 shadow-3xs border border-gray-150' 
              : 'text-gray-500 hover:text-gray-900'
          }`}
        >
          <Banknote className="h-4 w-4 text-emerald-600" />
          <span>Payout Requests ({pendingCount})</span>
        </button>
        <button
          onClick={() => setActiveAdminView('tasks')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-bold rounded-xl transition cursor-pointer ${
            activeAdminView === 'tasks' 
              ? 'bg-white text-gray-900 shadow-3xs border border-gray-150' 
              : 'text-gray-500 hover:text-gray-900'
          }`}
        >
          <Camera className="h-4 w-4 text-indigo-600" />
          <span>Task Proof Submissions ({tasks.filter(t => t.status === 'Verifying').length})</span>
        </button>
      </div>

      {activeAdminView === 'withdrawals' ? (
        <>
          {/* Grid Summary widgets */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Widget: Pending */}
            <div className="p-4 rounded-2xl bg-amber-50/40 border border-amber-100 flex items-start justify-between min-h-[96px] relative overflow-hidden">
              <div className="space-y-1 z-10">
                <span className="text-[9px] font-black font-mono text-amber-600 block uppercase tracking-widest">Awaiting Settle (Pending)</span>
                <h4 className="text-xl font-black text-slate-900 font-mono">₦{pendingVolume.toLocaleString()}</h4>
                <span className="text-[10px] text-amber-700 font-medium block">{pendingCount} active payout requests in queue</span>
              </div>
              <div className="h-8 w-8 bg-amber-500/10 border border-amber-500/20 text-amber-600 rounded-lg flex items-center justify-center">
                <Clock className="h-4 w-4" />
              </div>
            </div>

            {/* Widget: Disbursed / Settled */}
            <div className="p-4 rounded-2xl bg-emerald-50/40 border border-emerald-100 flex items-start justify-between min-h-[96px] relative overflow-hidden">
              <div className="space-y-1 z-10">
                <span className="text-[9px] font-black font-mono text-emerald-600 block uppercase tracking-widest">Released (Successful)</span>
                <h4 className="text-xl font-black text-slate-900 font-mono">₦{successVolume.toLocaleString()}</h4>
                <span className="text-[10px] text-emerald-700 font-medium block">{successCount} payouts marked as PAID</span>
              </div>
              <div className="h-8 w-8 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-lg flex items-center justify-center">
                <CheckCircle2 className="h-4 w-4" />
              </div>
            </div>

            {/* Widget: Flagged/Failed */}
            <div className="p-4 rounded-2xl bg-gray-50 border border-gray-200/80 flex items-start justify-between min-h-[96px] relative overflow-hidden">
              <div className="space-y-1 z-10">
                <span className="text-[9px] font-black font-mono text-gray-500 block uppercase tracking-widest">Rejected (Failed)</span>
                <h4 className="text-xl font-black text-slate-900 font-mono">{failedCount} <span className="text-xs text-gray-400 font-medium font-sans">Rejected</span></h4>
                <span className="text-[10px] text-gray-550 block mt-1 font-medium">Compliance or fraud flags triggered</span>
              </div>
              <div className="h-8 w-8 bg-gray-200 border border-gray-300 text-gray-600 rounded-lg flex items-center justify-center">
                <XCircle className="h-4 w-4" />
              </div>
            </div>
          </div>

          {/* Filter and search parameters */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 justify-between bg-slate-50 p-3 rounded-2xl border border-gray-150">
            {/* Search Input bar */}
            <div className="relative flex-grow">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-450" />
              <input
                type="text"
                placeholder="Search by recipient name, account, email, bank or transaction ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-white text-xs text-slate-900 border border-gray-250 rounded-xl focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/10 transition h-10"
              />
            </div>

            {/* Status segment control */}
            <div className="flex bg-slate-200/60 p-1 rounded-xl border border-slate-200 shrink-0">
              {(['All', 'Pending', 'Successful', 'Failed'] as const).map(f => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setStatusFilter(f)}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-black font-mono uppercase tracking-wider transition-all duration-150 cursor-pointer ${
                    statusFilter === f 
                      ? 'bg-white text-slate-950 shadow-2xs font-bold' 
                      : 'text-gray-500 hover:text-slate-800'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* Main Ledger Table */}
          <div className="overflow-x-auto rounded-2xl border border-gray-150 shadow-3xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-gray-150">
                  <th className="py-3 px-4 text-[10px] font-black font-mono text-gray-500 uppercase tracking-widest">Transaction / Date</th>
                  <th className="py-3 px-4 text-[10px] font-black font-mono text-gray-500 uppercase tracking-widest">User Profile</th>
                  <th className="py-3 px-4 text-[10px] font-black font-mono text-gray-500 uppercase tracking-widest">Bank Clearing Parameters (NUBAN)</th>
                  <th className="py-3 px-4 text-[10px] font-black font-mono text-gray-500 uppercase tracking-widest">Category</th>
                  <th className="py-3 px-4 text-[10px] font-black font-mono text-gray-500 uppercase tracking-widest text-right">Amount</th>
                  <th className="py-3 px-4 text-[10px] font-black font-mono text-gray-500 uppercase tracking-widest text-center">Audit Status</th>
                  <th className="py-3 px-4 text-[10px] font-black font-mono text-gray-500 uppercase tracking-widest text-center">Settlement Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-[11.5px] text-gray-700">
                {filteredWithdrawals.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/50 transition">
                    {/* ID & Date */}
                    <td className="py-4 px-4 whitespace-nowrap">
                      <span className="font-mono font-bold text-slate-800 text-xs block">{item.id}</span>
                      <span className="text-[10px] text-gray-400 block mt-0.5">{item.timestamp}</span>
                    </td>

                    {/* User email & name */}
                    <td className="py-4 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <div className="h-6 w-6 bg-slate-100 rounded-full flex items-center justify-center border border-slate-200 text-slate-600">
                          <User className="h-3 w-3" />
                        </div>
                        <div>
                          <span className="font-bold text-gray-900 block">{item.fullName}</span>
                          <span className="text-[10px] text-gray-400 block font-mono mt-0.2">{item.email}</span>
                        </div>
                      </div>
                    </td>

                    {/* Bank / NUBAN */}
                    <td className="py-4 px-4">
                      <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-150 space-y-1.5 max-w-xs">
                        <div className="flex items-center justify-between gap-2 border-b border-gray-150 pb-1">
                          <span className="font-bold text-gray-900 text-[10.5px] truncate flex items-center gap-1">
                            <Building className="h-3 w-3 text-emerald-600" />
                            {item.bankName}
                          </span>
                        </div>
                        <div className="font-mono text-[11.5px] font-black text-slate-900 flex items-center justify-between bg-white px-2 py-1 rounded border border-gray-200 shadow-3xs">
                          <span>{item.accountNumber}</span>
                          <button
                            onClick={() => handleCopyClipboard(item.accountNumber, `num-${item.id}`)}
                            className="text-[9px] text-emerald-600 hover:text-emerald-800 font-bold tracking-wider hover:underline flex items-center gap-0.5"
                            title="Copy Account Number to Clipboard"
                          >
                            {copiedId === `num-${item.id}` ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
                            <span>Copy</span>
                          </button>
                        </div>
                        <div className="text-[10px] uppercase font-bold text-gray-500 truncate mt-1 select-all" title="Verified NUBAN Recipient Name">
                          {item.accountName}
                        </div>
                      </div>
                    </td>

                    {/* Category badge */}
                    <td className="py-4 px-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[9.5px] font-black font-mono uppercase tracking-wider ${
                        item.category === 'Referral' 
                          ? 'bg-purple-50 text-purple-700 border border-purple-100' 
                          : 'bg-blue-50 text-blue-700 border border-blue-100'
                      }`}>
                        {item.category} Wallet
                      </span>
                    </td>

                    {/* Amount */}
                    <td className="py-4 px-4 whitespace-nowrap text-right font-mono font-black text-slate-900 text-xs">
                      ₦{item.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>

                    {/* Status */}
                    <td className="py-4 px-4 whitespace-nowrap text-center">
                      <span className={`inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[9px] font-bold font-mono tracking-wider uppercase border ${
                        item.status === 'Successful' 
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-100' 
                          : item.status === 'Pending'
                          ? 'bg-amber-50 text-amber-600 border-amber-100 animate-pulse'
                          : 'bg-red-50 text-red-600 border-red-100'
                      }`}>
                        {item.status}
                      </span>
                      {item.txHash && (
                        <span className="block mt-1 font-mono text-[8px] text-gray-400 select-all truncate max-w-[120px] mx-auto">
                          Ref: {item.txHash}
                        </span>
                      )}
                    </td>

                    {/* Direct Action buttons */}
                    <td className="py-4 px-4 whitespace-nowrap text-center">
                      {item.status === 'Pending' ? (
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Copy Helper (Copies everything needed to process) */}
                          <button
                            onClick={() => handleCopyBulkDetails(item)}
                            className="p-1 px-2 bg-slate-100 text-slate-800 hover:bg-slate-200 border border-gray-255 rounded-lg text-[9.5px] font-bold font-mono uppercase tracking-wide transition cursor-pointer flex items-center gap-1"
                            title="Copy full parameters to clipboard for quick paste in bank app"
                          >
                            {copiedId === `bulk-${item.id}` ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3 text-gray-500" />}
                            <span>Copy Details</span>
                          </button>

                          {/* Process button */}
                          <button
                            onClick={() => {
                              setSelectedWd(item);
                              setActionRemarks('');
                              setManualTxHash('');
                            }}
                            className="p-1 px-2.5 bg-slate-950 text-white hover:bg-emerald-600 rounded-lg text-[9.5px] font-bold font-mono uppercase tracking-wide transition cursor-pointer flex items-center gap-1 shadow-2xs"
                          >
                            <Banknote className="h-3 w-3" />
                            <span>Settle</span>
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] text-gray-400 font-mono font-bold uppercase select-none">
                          Audit Closed
                        </span>
                      )}
                    </td>
                  </tr>
                ))}

                {filteredWithdrawals.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-gray-455 text-xs font-semibold">
                      No matching registered withdrawal settlements found inside active bounds.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      ) : (
        <>
          {/* Grid Summary widgets for Task Verification */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Widget: Pending review */}
            <div className="p-4 rounded-2xl bg-indigo-50/40 border border-indigo-100 flex items-start justify-between min-h-[96px] relative overflow-hidden text-left">
              <div className="space-y-1 z-10 text-left">
                <span className="text-[9px] font-black font-mono text-indigo-600 block uppercase tracking-widest">Pending Verification</span>
                <h4 className="text-xl font-black text-slate-900 font-mono">
                  {tasks.filter(t => t.status === 'Verifying').length}
                </h4>
                <p className="text-[10px] text-indigo-700 font-medium">Awaiting administrator approval</p>
              </div>
              <div className="h-8 w-8 bg-indigo-500/10 border border-indigo-500/20 text-indigo-600 rounded-lg flex items-center justify-center">
                <Clock className="h-4 w-4" />
              </div>
            </div>

            {/* Widget: Approved tasks */}
            <div className="p-4 rounded-2xl bg-green-50/40 border border-green-100 flex items-start justify-between min-h-[96px] relative overflow-hidden text-left">
              <div className="space-y-1 z-10 text-left">
                <span className="text-[9px] font-black font-mono text-green-600 block uppercase tracking-widest">Approved & Paid</span>
                <h4 className="text-xl font-black text-slate-900 font-mono">
                  {tasks.filter(t => t.status === 'Completed').length}
                </h4>
                <p className="text-[10px] text-green-700 font-medium">Earned Naira payouts successfully issued</p>
              </div>
              <div className="h-8 w-8 bg-green-500/10 border border-green-500/20 text-green-600 rounded-lg flex items-center justify-center">
                <CheckCircle className="h-4 w-4" />
              </div>
            </div>

            {/* Widget: Available microtasks */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-start justify-between min-h-[96px] relative overflow-hidden text-left">
              <div className="space-y-1 z-10 text-left">
                <span className="text-[9px] font-black font-mono text-slate-550 block uppercase tracking-widest font-sans">Active Campaigns</span>
                <h4 className="text-xl font-black text-slate-900 font-mono">
                  {tasks.length}
                </h4>
                <p className="text-[10px] text-slate-550 font-medium">Total active microtasks on network</p>
              </div>
              <div className="h-8 w-8 bg-slate-100 border border-slate-250 text-slate-500 rounded-lg flex items-center justify-center">
                <Camera className="h-4 w-4" />
              </div>
            </div>
          </div>

          {/* Task filtering tools */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 justify-between bg-slate-50 p-3 rounded-2xl border border-gray-150">
            <span className="text-xs font-bold text-slate-700 px-1">Filter campaign submissions:</span>
            <div className="flex bg-slate-200/60 p-1 rounded-xl border border-slate-200 shrink-0">
              {([
                { id: 'Verifying', label: 'Pending Review' },
                { id: 'Completed', label: 'Approved & Paid' },
                { id: 'Expired', label: 'Expired Tasks' },
                { id: 'All', label: 'All Tasks' }
              ] as const).map(tf => (
                <button
                  key={tf.id}
                  type="button"
                  onClick={() => setTaskFilter(tf.id)}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-black font-mono uppercase tracking-wider transition-all duration-150 cursor-pointer ${
                    taskFilter === tf.id 
                      ? 'bg-white text-indigo-950 shadow-2xs font-bold' 
                      : 'text-gray-500 hover:text-slate-800'
                  }`}
                >
                  {tf.label}
                </button>
              ))}
            </div>
          </div>

          {/* Submissions List Container */}
          <div className="space-y-4">
            {tasks.filter(t => {
              if (taskFilter === 'All') return true;
              return t.status === taskFilter;
            }).length === 0 ? (
              <div className="p-12 border border-dashed border-slate-200 rounded-3xl bg-slate-50/50 text-center space-y-3">
                <div className="h-10 w-10 bg-slate-100 border border-slate-250 text-slate-400 rounded-xl flex items-center justify-center mx-auto">
                  <AlertCircle className="h-5 w-5" />
                </div>
                <div className="text-slate-800 text-xs font-bold">No submissions found</div>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                  No task proof submissions are currently in {taskFilter === 'Verifying' ? 'pending review' : taskFilter === 'Completed' ? 'completed' : taskFilter === 'Expired' ? 'expired' : 'selected'} status.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {tasks.filter(t => {
                  if (taskFilter === 'All') return true;
                  return t.status === taskFilter;
                }).map(task => (
                  <div 
                     key={task.id}
                     className="bg-white border rounded-2xl p-5 shadow-3xs flex flex-col justify-between relative overflow-hidden transition-all duration-300 hover:border-slate-300 text-left"
                     style={{ borderLeftColor: task.status === 'Verifying' ? '#6366f1' : task.status === 'Completed' ? '#10b981' : task.status === 'Expired' ? '#ef4444' : undefined, borderLeftWidth: '4px' }}
                  >
                    <div className="space-y-3">
                      {/* Sub card header */}
                      <div className="flex items-center justify-between">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-black font-mono uppercase tracking-widest ${
                          task.platform === 'Twitter' ? 'bg-sky-50 text-sky-600 border border-sky-100' :
                          task.platform === 'YouTube' ? 'bg-red-50 text-red-600 border border-red-105' :
                          'bg-slate-100 text-slate-700'
                        }`}>
                          {task.platform}
                        </span>
                        
                        <span className="font-mono text-xs font-extrabold text-indigo-650">
                          ₦{task.reward.toLocaleString()}
                        </span>
                      </div>

                      {/* Main info */}
                      <div>
                        <h4 className="font-extrabold text-sm text-slate-900 leading-snug">{task.title}</h4>
                        <p className="text-[10px] text-gray-550 mt-1 leading-normal italic font-sans">{task.instruction}</p>
                      </div>

                      {/* Submitted proofs block */}
                      {task.status !== 'Available' && (
                        <div className="bg-slate-50 border border-slate-150 rounded-xl p-3 text-[11px] font-mono space-y-2 mt-2 text-left">
                          <div className="flex justify-between border-b border-dashed border-slate-200 pb-1 text-[10px] text-slate-400 font-bold uppercase">
                            <span>Proof Info</span>
                            <span>{task.submittedAt || 'Just now'}</span>
                          </div>
                          
                          <div className="text-slate-800 break-words font-sans bg-white p-2 rounded-lg border border-slate-150 text-xs">
                            <span className="text-slate-450 block text-[9px] uppercase font-bold font-mono">Proof Details / Handle:</span>
                            {task.proofOfWork || 'Not provided'}
                          </div>
                          
                          {task.verificationImage && (
                            <div className="space-y-1">
                              <span className="text-slate-450 text-[10px] uppercase font-bold block">Screenshot Evidence:</span>
                              <div 
                                onClick={() => setZoomedTaskScreenshot(task.verificationImage || null)}
                                className="relative aspect-video max-h-[145px] rounded-lg overflow-hidden bg-slate-950 border border-slate-205 cursor-pointer group flex items-center justify-center transition-all duration-150 hover:opacity-90 hover:scale-[1.01]"
                                title="Click to open Full Screen Lightbox"
                              >
                                <img 
                                  src={task.verificationImage} 
                                  alt="Proof proof" 
                                  referrerPolicy="no-referrer"
                                  className="w-full h-full object-contain"
                                />
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                  <div className="px-3 py-1.5 bg-black/70 rounded-full text-white text-[10px] font-bold flex items-center gap-1.5 font-sans">
                                    <Eye className="h-3.5 w-3.5" />
                                    <span>Preview Proof</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Action buttons footer */}
                    <div className="pt-4 border-t border-slate-100 mt-4 flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className={`h-1.5 w-1.5 rounded-full ${
                          task.status === 'Verifying' ? 'bg-indigo-600 animate-pulse' :
                          task.status === 'Completed' ? 'bg-green-600' :
                          task.status === 'Expired' ? 'bg-red-600 animate-none' : 'bg-slate-400'
                        }`} />
                        <span className="text-[10px] font-bold text-slate-500 tracking-wide uppercase">
                          {task.status === 'Verifying' ? 'Awaiting Settle' :
                           task.status === 'Completed' ? 'Payout Disbursed' :
                           task.status === 'Expired' ? 'Expired / Lapsed' : 'Incomplete'}
                        </span>
                      </div>

                      {task.status === 'Verifying' && (
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => setSelectedRejectTaskId(task.id)}
                            className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg text-[10px] font-extrabold uppercase transition cursor-pointer"
                          >
                            Decline
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (onApproveTask) {
                                onApproveTask(task.id);
                              }
                            }}
                            className="px-3.5 py-1.5 bg-indigo-650 hover:bg-green-600 text-white rounded-lg text-[10px] font-extrabold uppercase transition cursor-pointer shadow-3xs"
                          >
                            Approve & Pay
                          </button>
                        </div>
                      )}

                      {task.status === 'Completed' && (
                        <div className="flex items-center gap-1 text-green-700 bg-green-50/50 border border-green-150 px-2.5 py-1 rounded-lg text-[10px] font-bold">
                          <Check className="h-3 w-3" />
                          <span>Cleared Success</span>
                        </div>
                      )}
                    </div>

                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {/* Decline Task Reason Modal */}
      {selectedRejectTaskId && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl p-6 text-left space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-sm sm:text-base text-slate-900 font-display">
                Decline Task Proof
              </h3>
              <button 
                onClick={() => setSelectedRejectTaskId(null)} 
                className="p-1 hover:bg-slate-100 rounded-full transition text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="space-y-3">
              <p className="text-xs text-gray-400">
                Specify a clear reason for rejecting this member's proof of work. They will be notified and can upload correct proof.
              </p>
              <div>
                <label className="block text-[10px] font-black uppercase text-gray-400 font-mono mb-1">
                  Rejection Reason
                </label>
                <select 
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500"
                >
                  <option value="">-- Choose pre-set reason --</option>
                  <option value="Unclear screenshot or low resolution image.">Unclear screenshot or low resolution image</option>
                  <option value="Social account handle is missing or incorrect.">Social account handle is missing or incorrect</option>
                  <option value="Proof does not show required subscription or comment.">Proof does not show required subscription or comment</option>
                  <option value="Duplicate image proof submitted.">Duplicate image proof submitted</option>
                </select>
                <textarea
                  placeholder="Or type a custom reason..."
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  className="w-full px-3 py-2 mt-2 text-xs bg-slate-50 border border-slate-205 rounded-xl focus:outline-none focus:border-indigo-505 min-h-[60px]"
                />
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setSelectedRejectTaskId(null)}
                className="flex-1 py-2 bg-slate-100 hover:bg-slate-202 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (onRejectTask && selectedRejectTaskId) {
                    onRejectTask(selectedRejectTaskId, rejectReason || 'Incomplete action details.');
                    setSelectedRejectTaskId(null);
                    setRejectReason('');
                    triggerToast('Proof Rejected!');
                  }
                }}
                className="flex-1 py-2 bg-red-650 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Decline & Notify
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Zoomed Screenshot Lightbox modal */}
      {zoomedTaskScreenshot && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-4 border-b border-gray-150 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Camera className="h-5 w-5 text-indigo-650" />
                <span className="font-bold text-sm text-slate-900 font-display">
                  HD Screenshot Proof Viewer
                </span>
              </div>
              <button 
                onClick={() => setZoomedTaskScreenshot(null)} 
                className="p-1.5 hover:bg-slate-202 rounded-full text-slate-400 hover:text-slate-700 transition cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 bg-slate-900 overflow-y-auto flex items-center justify-center min-h-[300px] flex-grow">
              <img 
                src={zoomedTaskScreenshot} 
                alt="Zoomed Proof Details" 
                referrerPolicy="no-referrer"
                className="max-h-[60vh] object-contain rounded-lg border border-slate-750"
              />
            </div>
            <div className="p-4 bg-slate-50 border-t border-gray-150 flex justify-end">
              <button
                onClick={() => setZoomedTaskScreenshot(null)}
                className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Close Viewer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Settle Transaction Workspace */}
      {selectedWd && (
        <div className="fixed inset-0 bg-slate-950/70 flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full border border-gray-150 shadow-2xl relative space-y-5 animate-scale-in">
            
            {/* Close button */}
            <button
              onClick={() => setSelectedWd(null)}
              className="absolute right-4 top-4 text-gray-400 hover:text-gray-700 h-6 w-6 rounded-full bg-slate-100 flex items-center justify-center cursor-pointer"
            >
              <X className="h-4.5 w-4.5" />
            </button>

            {/* Header */}
            <div className="text-left space-y-1.5">
              <span className="text-[9px] font-black text-amber-600 bg-amber-50 border border-amber-100 px-2 py-0.5 rounded-full uppercase font-mono tracking-widest inline-block">
                Manual Settlement Release
              </span>
              <h4 className="text-base font-black text-slate-900 font-mono uppercase">
                Process Payout Details
              </h4>
              <p className="text-[11px] text-gray-500 leading-normal">
                Verify parameters and release payout clearance block for this transaction. Confirm payment from your business banking registry before approval.
              </p>
            </div>

            {/* Verification summary cards */}
            <div className="p-4 bg-slate-50 border border-slate-150 rounded-2xl text-[11px] space-y-2.5">
              <div className="flex justify-between items-center border-b border-gray-200/60 pb-1.5">
                <span className="text-gray-400 font-mono tracking-wide uppercase">Recipient:</span>
                <span className="font-bold text-slate-800 uppercase text-right truncate max-w-[200px]">{selectedWd.accountName}</span>
              </div>
              <div className="flex justify-between items-center border-b border-gray-200/60 pb-1.5">
                <span className="text-gray-400 font-mono tracking-wide uppercase">NUBAN Code:</span>
                <span className="font-black font-mono text-slate-900 text-right">{selectedWd.accountNumber} ({selectedWd.bankName})</span>
              </div>
              <div className="flex justify-between items-center border-b border-gray-200/60 pb-1.5">
                <span className="text-gray-400 font-mono tracking-wide uppercase">Source:</span>
                <span className="font-bold text-slate-800 text-right">{selectedWd.category} Wallet</span>
              </div>
              <div className="flex justify-between items-center mt-1 pt-1 font-mono text-xs">
                <span className="text-slate-800 font-black">NET CLEARANCE AMOUNT:</span>
                <span className="font-black text-slate-950 text-sm">₦{selectedWd.amount.toLocaleString()}</span>
              </div>
            </div>

            {/* Form Inputs */}
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] font-black uppercase tracking-wider text-gray-500 font-mono mb-1 text-left">
                  Compliance Remarks / Note (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Paid successfully via GTPay Business app."
                  value={actionRemarks}
                  onChange={(e) => setActionRemarks(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/10 transition h-10"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black uppercase tracking-wider text-gray-500 font-mono mb-1 text-left">
                  Manual Bank Ref/Transaction ID (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Ref NIBSS-TX-991A"
                  value={manualTxHash}
                  onChange={(e) => setManualTxHash(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/10 transition h-10 font-mono"
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-2">
              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => handleProcessAction('Failed')}
                className="flex-1 py-3 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200/60 font-mono font-black text-[10px] uppercase tracking-wider rounded-xl transition cursor-pointer text-center flex items-center justify-center gap-1"
              >
                <XCircle className="h-3.5 w-3.5" />
                <span>Decline Payout</span>
              </button>

              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => handleProcessAction('Successful')}
                className="flex-1 py-3 bg-slate-950 hover:bg-emerald-600 text-white font-mono font-black text-[10px] uppercase tracking-wider rounded-xl transition cursor-pointer text-center flex items-center justify-center gap-1 shadow-md hover:shadow-lg disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span className="h-3 w-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <CheckCircle className="h-3.5 w-3.5" />
                )}
                <span>Approve & Settle</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
