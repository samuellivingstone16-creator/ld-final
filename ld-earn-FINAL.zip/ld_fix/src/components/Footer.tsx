/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, Sparkles } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-950 text-gray-400 border-t border-gray-900 py-10 mt-16 select-none font-sans">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-start justify-between gap-6 border-b border-gray-900 pb-8">
          <div className="max-w-md">
            <h4 className="text-xs font-bold uppercase tracking-widest text-emerald-400 font-mono">
              LD Platform Security
            </h4>
            <p className="mt-2.5 text-xs text-gray-400 leading-relaxed font-sans">
              LD represents a premium secure campaign and affiliate distribution network. It enables users to earn steady affiliate bonuses, complete daily brand engagement tasks, and request direct payout settlements in Naira (₦) directly to any verified bank registry.
            </p>
          </div>
          <div className="bg-gray-900 border border-gray-800 p-3.5 rounded-xl max-w-xs flex flex-col gap-1">
            <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold font-mono">
              <Shield className="h-4 w-4 text-emerald-500" />
              <span>Secure Payment Compliance</span>
            </div>
            <p className="text-[10px] text-gray-450 leading-normal">
              All electronic transaction handshakes and settlement requests are processed through fully compliant payment pathways matching federal clearing house guides.
            </p>
          </div>
        </div>

        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-gray-500">
          <p>© 2026 LD Systems Ltd.</p>
          <p className="flex items-center gap-1.5">
            Engineered with <Sparkles className="h-3 w-3 text-emerald-400" /> Web3 Attributor v4.2
          </p>
        </div>
      </div>
    </footer>
  );
}
