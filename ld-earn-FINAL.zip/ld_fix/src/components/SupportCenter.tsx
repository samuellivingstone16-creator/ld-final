/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HelpCircle, Send, MessageSquare, AlertCircle, ShieldAlert, BadgeHelp, CheckCircle2, LifeBuoy } from 'lucide-react';
import FAQs from './FAQs';

interface Ticket {
  id: string;
  category: string;
  subject: string;
  description: string;
  timestamp: string;
  status: 'Open' | 'Replied' | 'Resolved';
  replies: { author: string; message: string; timestamp: string; isAgent: boolean }[];
}

const FAQ_ITEMS = [
  {
    q: 'How long do micro-task reviews take?',
    a: 'Most automated social tasks (Twitter/TikTok follows) are scraped and approved within minutes. Paid surveys and manually screened campaigns take up to 24 hours.'
  },
  {
    q: 'Why does my bank transfer say "Pending"?',
    a: 'Withdrawal requests are processed via Nigerian Inter-Bank Settlement System (NIBSS) instant electronic fund transfer rails. All settlement balances undergo rigorous audit vetting on a 2-hour compliance queue to prevent fraudulent payout routing.'
  },
  {
    q: 'What is the referral bonus scheme?',
    a: 'For every user who registers through your unique affiliating referral code and completes one task, you instantly receive ₦500. There are no referral capping limits.'
  },
  {
    q: 'My bank account verification failed. What do I do?',
    a: 'Ensure the recipient account name perfectly matches your registered profile settings name. Profile names must match NIBSS databases.'
  }
];

interface SupportCenterProps {
  officialChannelLink?: string;
  officialWhatsappLink?: string;
}

export default function SupportCenter({ 
  officialChannelLink = 'https://t.me/+8aDqe4G00v8xOGI0',
  officialWhatsappLink = 'https://whatsapp.com/channel/0029Vb8MwfN4CrfZB97sry1r'
}: SupportCenterProps) {
  const [tickets, setTickets] = useState<Ticket[]>(() => {
    const saved = localStorage.getItem('naira_support_tickets');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      {
        id: 'TCK-2940',
        category: 'Withdrawal Delayed',
        subject: 'Wema Bank transfer pending review',
        description: 'I initiated my cashout of ₦5,000 to Wema Bank but the status says pending. Just wanted to double check.',
        timestamp: '2026-06-10 09:30',
        status: 'Replied',
        replies: [
          {
            author: 'LD Financial Agent',
            message: 'Hello, we reviewed your transaction! NIBSS ledger confirmation was processed. Your bank is currently clearing the funds, please check your balance. Let us know if you need any other assistance!',
            timestamp: '2026-06-10 10:15',
            isAgent: true
          }
        ]
      }
    ];
  });

  const [category, setCategory] = useState('Task Verification');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const saveTickets = (newTickets: Ticket[]) => {
    setTickets(newTickets);
    localStorage.setItem('naira_support_tickets', JSON.stringify(newTickets));
  };

  const handleSubmitTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !description.trim()) return;

    setSubmitting(true);

    setTimeout(() => {
      const ticketId = `TCK-${Math.floor(1000 + Math.random() * 9000)}`;
      const newTicket: Ticket = {
        id: ticketId,
        category,
        subject,
        description,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
        status: 'Open',
        replies: []
      };

      const updated = [newTicket, ...tickets];
      saveTickets(updated);

      setSubject('');
      setDescription('');
      setSubmitting(false);
      setSuccessMessage(`Ticket ${ticketId} successfully reported! Our helpdesk agents are inspecting this.`);

      // Simulate a helpful system bot replying after 6 seconds
      setTimeout(() => {
        setTickets((currentTickets) => {
          const fresh = currentTickets.map((t) => {
            if (t.id === ticketId) {
              return {
                ...t,
                status: 'Replied' as const,
                replies: [
                  ...t.replies,
                  {
                    author: 'LD Assistant Bot',
                    message: `Hi there! Thanks for filing a support query under "${category}". We have scheduled this request for deep diagnostic checkups. Rest assured that level 2 security parameters are inspecting your active social claims. We appreciate your patience!`,
                    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
                    isAgent: true
                  }
                ]
              };
            }
            return t;
          });
          localStorage.setItem('naira_support_tickets', JSON.stringify(fresh));
          return fresh;
        });
      }, 6000);

      setTimeout(() => setSuccessMessage(''), 5000);
    }, 800);
  };

  // Resolve ticket helper
  const handleResolveTicket = (id: string) => {
    const updated = tickets.map(t => t.id === id ? { ...t, status: 'Resolved' as const } : t);
    saveTickets(updated);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in" id="support-view">
      
      {/* Left 2 cols: Ticket Portal */}
      <div className="lg:col-span-2 space-y-8">
        
        {/* Create Ticket */}
        <div className="bg-white rounded-2xl border border-gray-150 p-6 sm:p-8 shadow-xs">
          <div className="flex items-center gap-3 pb-4 border-b border-gray-100">
            <div className="h-10 w-10 rounded-xl bg-green-50 text-green-700 flex items-center justify-center">
              <LifeBuoy className="h-5 w-5 stroke-[2]" />
            </div>
            <div>
              <h2 className="font-display text-xl font-bold text-gray-900">Open a Support Ticket</h2>
              <p className="text-xs text-gray-500 mt-0.5">Need immediate assistance with tasks, ledger balances, or cashouts?</p>
            </div>
          </div>

          {successMessage && (
            <div className="mt-4 p-4 rounded-xl bg-emerald-50 border border-emerald-150 text-emerald-800 text-xs font-medium flex items-center space-x-2 animate-fade-in">
              <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmitTicket} className="mt-6 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-sans font-bold text-gray-700 uppercase tracking-wider mb-1.5">Issue Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full text-sm rounded-xl border border-gray-200 p-2.5 bg-gray-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition"
                >
                  <option value="Task Verification">Task Verification / Rejected Proofs</option>
                  <option value="Withdrawal Delayed">Withdrawal Pending review</option>
                  <option value="Level Upgrade">Level 2 Rank upgrades</option>
                  <option value="Referral Tracking">Missing Referral Comms</option>
                  <option value="Other Feedback">Other Account Issues</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-sans font-bold text-gray-700 uppercase tracking-wider mb-1.5">Brief Subject</label>
                <input
                  type="text"
                  placeholder="e.g. My referral earnings didn't clear..."
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full text-sm rounded-xl border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-sans font-bold text-gray-700 uppercase tracking-wider mb-1.5">Detailed Description</label>
              <textarea
                rows={4}
                required
                placeholder="Describe your issue with exact proof IDs or banking screenshots details..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full text-sm rounded-xl border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white font-bold text-sm px-5 py-2.5 rounded-xl cursor-pointer transition shadow-xs disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              <span>{submitting ? 'Filing Ticket...' : 'File Support Ticket'}</span>
            </button>
          </form>
        </div>

        {/* Existing tickets list */}
        <div className="space-y-4">
          <h3 className="font-display text-lg font-bold text-gray-900 px-1">Your Support History</h3>
          
          {tickets.length === 0 ? (
            <div className="bg-white rounded-2xl border border-gray-150 p-8 text-center">
              <p className="text-sm font-medium text-gray-650">No filed support tickets yet.</p>
              <p className="text-xs text-gray-400 mt-1">If you have technical questions, use the open-ticket form above.</p>
            </div>
          ) : (
            tickets.map((t) => (
              <div key={t.id} className="bg-white rounded-2xl border border-gray-150 p-6 shadow-xs space-y-4">
                <div className="flex items-start justify-between gap-4 border-b border-gray-100 pb-4">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-xs font-bold text-gray-500 bg-gray-100 px-2 py-0.5 rounded">
                        {t.id}
                      </span>
                      <span className="text-xs text-gray-400">{t.timestamp}</span>
                    </div>
                    <h4 className="font-display font-bold text-gray-900 text-base mt-1">{t.subject}</h4>
                    <p className="text-xs text-green-700 font-medium mt-0.5">{t.category}</p>
                  </div>

                  <span className={`inline-flex items-center text-xs font-bold font-mono tracking-wider uppercase px-2.5 py-0.5 rounded-full ${
                    t.status === 'Resolved'
                      ? 'bg-emerald-50 text-emerald-700'
                      : t.status === 'Replied'
                      ? 'bg-blue-50 text-blue-700'
                      : 'bg-amber-50 text-amber-600'
                  }`}>
                    {t.status}
                  </span>
                </div>

                <div className="text-xs text-gray-700 leading-relaxed bg-gray-50/50 p-3.5 rounded-xl border border-gray-100">
                  <span className="block text-[10px] font-mono uppercase tracking-wider font-extrabold text-gray-400 mb-1">YOUR INQUIRY:</span>
                  {t.description}
                </div>

                {/* Replies queue */}
                {t.replies.map((rep, idx) => (
                  <div key={idx} className="p-4 rounded-xl text-xs bg-slate-50 border border-slate-150 space-y-1.5 ml-4">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-green-950 font-display flex items-center space-x-1">
                        <MessageSquare className="h-3.5 w-3.5 inline text-green-600" />
                        <span>{rep.author}</span>
                      </span>
                      <span className="text-[9px] font-mono text-gray-400">{rep.timestamp}</span>
                    </div>
                    <p className="text-gray-650 leading-relaxed">{rep.message}</p>
                  </div>
                ))}

                {t.status !== 'Resolved' && (
                  <div className="flex justify-end pt-2">
                    <button
                      onClick={() => handleResolveTicket(t.id)}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-lg border border-emerald-150 transition cursor-pointer"
                    >
                      Mark Issue as Resolved
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

      </div>

      {/* Right col: FAQs FAQ Panel */}
      <div className="space-y-6">
        {/* Official Channel Card */}
        <div className="bg-white rounded-2xl border border-gray-150 p-6 shadow-xs space-y-4">
          <div className="flex items-center space-x-2 text-amber-600">
            <LifeBuoy className="h-4.5 w-4.5 text-amber-500" />
            <h3 className="font-display font-bold text-sm text-gray-950 uppercase tracking-wider">Official Communities</h3>
          </div>
          <p className="text-xs text-gray-500 leading-relaxed">
            Need real-time support from moderators or want to engage with other earners? Join our official community networks for direct, immediate assistance.
          </p>
          <div className="space-y-2 pt-1">
            <a
              href={officialWhatsappLink}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2 w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black uppercase tracking-wider text-center rounded-xl transition duration-150 cursor-pointer"
            >
              <MessageSquare className="h-4 w-4" />
              <span>Join WhatsApp Group</span>
            </a>
            <a
              href={officialChannelLink}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2 w-full py-2.5 bg-slate-950 hover:bg-slate-900 text-white hover:text-amber-400 text-xs font-black uppercase tracking-wider text-center rounded-xl transition duration-150 cursor-pointer"
            >
              <Send className="h-4 w-4" />
              <span>Join Telegram Channel</span>
            </a>
          </div>
        </div>

        <div className="bg-gradient-to-br from-gray-900 to-slate-800 rounded-2xl p-6 text-white shadow-sm relative overflow-hidden">
          <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 opacity-5 h-28 w-28 rounded-full border-4 border-white" />
          <BadgeHelp className="h-8 w-8 text-emerald-400 mb-3" />
          <h3 className="font-display font-bold text-lg">Instant Knowledge base</h3>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            Find immediate diagnostic answers to Nigeria social microtask payouts, rates, and platform mechanics.
          </p>
        </div>

        <FAQs />
      </div>

    </div>
  );
}
