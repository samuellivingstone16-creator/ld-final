/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Bell, Check, Trash2, MailOpen, MessageSquare, AlertCircle, Sparkles, Award } from 'lucide-react';

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  category: 'system' | 'task' | 'finance' | 'referral';
}

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'Welcome to LD!',
    message: 'Start participating in daily activities to instantly receive payouts to your bank account. Earn ₦500 per friend you invite!',
    time: '2 hours ago',
    read: false,
    category: 'system'
  },
  {
    id: 'notif-2',
    title: 'Level 2 Status Unlocked!',
    message: 'Congratulations! You have completed initial tasks and earned Level 2 access, increasing your daily task limits.',
    time: '4 hours ago',
    read: true,
    category: 'system'
  },
  {
    id: 'notif-3',
    title: 'Payout Pipeline Ready',
    message: 'Your banking settlement routing has been synchronized under CBN protocol standards. You can initiate NIBSS bank wires.',
    time: '1 day ago',
    read: true,
    category: 'finance'
  },
  {
    id: 'notif-4',
    title: 'Commission Credit: ₦3,500',
    message: 'Your direct referrals finished testing surveys. Passive reward bonus of ₦3,500 credited to total ledger.',
    time: '2 days ago',
    read: true,
    category: 'referral'
  }
];

export default function NotificationsCenter() {
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved = localStorage.getItem('naira_notifications');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_NOTIFICATIONS;
  });

  React.useEffect(() => {
    const handleSync = () => {
      const saved = localStorage.getItem('naira_notifications');
      if (saved) {
        try {
          setNotifications(JSON.parse(saved));
        } catch (e) {}
      }
    };
    window.addEventListener('storage', handleSync);
    window.addEventListener('naira_notifications_sync', handleSync);
    return () => {
      window.removeEventListener('storage', handleSync);
      window.removeEventListener('naira_notifications_sync', handleSync);
    };
  }, []);

  const saveToStorage = (updatedNotifs: NotificationItem[]) => {
    setNotifications(updatedNotifs);
    localStorage.setItem('naira_notifications', JSON.stringify(updatedNotifs));
  };

  const handleToggleRead = (id: string) => {
    const nextList = notifications.map(n => n.id === id ? { ...n, read: !n.read } : n);
    saveToStorage(nextList);
  };

  const handleMarkAllRead = () => {
    const nextList = notifications.map(n => ({ ...n, read: true }));
    saveToStorage(nextList);
  };

  const handleDeleteNotification = (id: string) => {
    const nextList = notifications.filter(n => n.id !== id);
    saveToStorage(nextList);
  };

  const handleClearAll = () => {
    saveToStorage([]);
  };

  const handleSimulateAlert = () => {
    const randomAlerts: { title: string; message: string; category: 'task' | 'finance' | 'referral' }[] = [
      {
        title: 'New Task Alert: ₦1,200',
        message: 'A brand-new brand awareness survey on TikTok integrity is now available in your task board!',
        category: 'task'
      },
      {
        title: 'Settlement Complete: Transfer Success',
        message: 'Your electronic wallet bank withdrawal has been successfully cleared and routed through real-time settlement rails.',
        category: 'finance'
      },
      {
        title: 'Referral Signed Up successfully',
        message: 'A new user registered using your exclusive link. ₦500 pending approval credited!',
        category: 'referral'
      }
    ];

    const pick = randomAlerts[Math.floor(Math.random() * randomAlerts.length)];
    const newNotif: NotificationItem = {
      id: `notif-${Math.random().toString(36).substring(2, 6)}`,
      title: pick.title,
      message: pick.message,
      time: 'Just now',
      read: false,
      category: pick.category
    };

    saveToStorage([newNotif, ...notifications]);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="bg-white rounded-2xl border border-gray-150 p-6 sm:p-8 shadow-xs animate-fade-in" id="notifications-view">
      
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-gray-100 pb-6 gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="inline-flex h-2 w-2 rounded-full bg-red-500 animate-ping" />
            <span className="text-xs font-bold text-red-600 font-mono tracking-wider uppercase">Live Activity Dispatcher</span>
          </div>
          <h2 className="font-display text-2xl font-bold text-gray-900 mt-1 flex items-center gap-2">
            <span>Notifications Centre</span>
            {unreadCount > 0 && (
              <span className="text-xs font-extrabold bg-red-100 text-red-700 px-2 py-0.5 rounded-full ml-1">
                {unreadCount} new
              </span>
            )}
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Realtime alerts on complete tasks, ledger approvals, and referral payouts.
          </p>
        </div>

        {/* Action controllers */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleSimulateAlert}
            className="inline-flex items-center space-x-1.5 bg-green-50 hover:bg-green-100 text-green-700 text-xs font-bold px-3 py-2 rounded-xl border border-green-200 transition cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Refresh Alert Feed</span>
          </button>

          {notifications.length > 0 && (
            <>
              <button
                onClick={handleMarkAllRead}
                className="inline-flex items-center space-x-1 bg-gray-50 hover:bg-gray-100 text-gray-650 text-xs font-bold px-3 py-2 rounded-xl border border-gray-200 transition cursor-pointer"
              >
                <Check className="h-3.5 w-3.5" />
                <span>Mark All Read</span>
              </button>
              <button
                onClick={handleClearAll}
                className="inline-flex items-center space-x-1 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold px-3 py-2 rounded-xl border border-rose-200 transition cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Clear Logs</span>
              </button>
            </>
          )}
        </div>
      </div>

      {notifications.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="h-14 w-14 rounded-full bg-slate-50 flex items-center justify-center text-gray-350 border border-gray-100 mb-4 shadow-2xs">
            <Bell className="h-6 w-6 stroke-[1.5]" />
          </div>
          <h3 className="font-display font-medium text-gray-800">Your log registry is clear</h3>
          <p className="text-xs text-gray-400 mt-1 max-w-sm">
            Everything is completely up-to-date! Click the "Refresh Alert Feed" button above to fetch new real-time social task campaigns, commission credits, and notifications.
          </p>
        </div>
      ) : (
        <div className="mt-6 space-y-4">
          {notifications.map((notif) => {
            return (
              <div
                key={notif.id}
                className={`p-5 rounded-2xl border transition-all duration-200 flex items-start gap-4 ${
                  notif.read 
                    ? 'border-gray-100 bg-gray-50/50 hover:bg-gray-50' 
                    : 'border-green-150 bg-green-50/20 hover:bg-green-50/35 shadow-xs'
                }`}
              >
                {/* Visual icon badge */}
                <div className={`p-2.5 rounded-xl border mt-0.5 flex-shrink-0 ${
                  notif.category === 'finance'
                    ? 'bg-blue-50 border-blue-200 text-blue-700'
                    : notif.category === 'referral'
                    ? 'bg-purple-50 border-purple-200 text-purple-700'
                    : notif.category === 'task'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                    : 'bg-orange-50 border-orange-200 text-orange-700'
                }`}>
                  {notif.category === 'finance' && <Award className="h-4.5 w-4.5" />}
                  {notif.category === 'referral' && <MessageSquare className="h-4.5 w-4.5" />}
                  {notif.category === 'task' && <Sparkles className="h-4.5 w-4.5" />}
                  {notif.category === 'system' && <AlertCircle className="h-4.5 w-4.5" />}
                </div>

                {/* Typography message */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className={`text-sm font-bold text-gray-900 ${!notif.read && 'font-extrabold text-green-950'}`}>
                      {notif.title}
                    </h4>
                    <span className="text-[10px] font-mono text-gray-400 whitespace-nowrap">{notif.time}</span>
                  </div>
                  <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                    {notif.message}
                  </p>
                  
                  {/* Micro Actions */}
                  <div className="flex items-center space-x-3 mt-3">
                    <button
                      onClick={() => handleToggleRead(notif.id)}
                      className="text-[10.5px] font-bold font-mono tracking-wider uppercase text-gray-400 hover:text-green-600 transition cursor-pointer flex items-center space-x-1"
                    >
                      {notif.read ? (
                        <>
                          <MailOpen className="h-3 w-3 inline" />
                          <span>Mark Unread</span>
                        </>
                      ) : (
                        <>
                          <Check className="h-3 w-3 inline" />
                          <span>Mark Read</span>
                        </>
                      )}
                    </button>
                    <span className="text-gray-200 text-xs">|</span>
                    <button
                      onClick={() => handleDeleteNotification(notif.id)}
                      className="text-[10.5px] font-bold font-mono tracking-wider uppercase text-gray-400 hover:text-red-500 transition cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}
