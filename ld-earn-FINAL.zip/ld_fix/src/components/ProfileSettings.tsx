/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, Shield, Key, BellRing, Smartphone, CheckCircle2, ChevronRight, HelpCircle, RefreshCw, Sun, Moon, Plus, Trash2, Save, Camera, RotateCcw, Upload, MessageSquare, Send, Monitor } from 'lucide-react';
import { PLANS, normalizePlan } from '../utils';
import { useAdminSettings } from '../App';


interface ProfileSettingsProps {
  onUpdateSuccess: (msg: string) => void;
  theme: 'light' | 'dark' | 'system';
  onThemeChange: (theme: 'light' | 'dark' | 'system') => void;
  profilePhoto?: string | null;
  onProfilePhotoChange?: (photo: string | null) => void;
}

export default function ProfileSettings({ 
  onUpdateSuccess, 
  theme, 
  onThemeChange,
  profilePhoto,
  onProfilePhotoChange
}: ProfileSettingsProps) {
  const [fullName, setFullName] = useState(() => localStorage.getItem('naira_profile_name') || 'John Doe');
  const [email, setEmail] = useState(() => localStorage.getItem('naira_profile_email') || 'livingstone0806382@gmail.com');
  const [currentLevel, setCurrentLevel] = useState(() => localStorage.getItem('naira_profile_level') || 'Level 2 Contributor');
  
  // Profile Photo states
  const [photoData, setPhotoData] = useState<string | null>(() => localStorage.getItem('naira_profile_photo'));

  // Sync photoData state with parent profilePhoto prop when it changes
  React.useEffect(() => {
    if (profilePhoto !== undefined && profilePhoto !== photoData) {
      setPhotoData(profilePhoto);
    }
  }, [profilePhoto]);
  const [tempPhotoData, setTempPhotoData] = useState<string | null>(null);
  const [confirmDeletePhoto, setConfirmDeletePhoto] = useState(false);
  const [confirmResetState, setConfirmResetState] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [videoStream, setVideoStream] = useState<MediaStream | null>(null);
  const videoRef = React.useRef<HTMLVideoElement | null>(null);

  // Clean play stream on unmount
  React.useEffect(() => {
    return () => {
      if (videoStream) {
        videoStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [videoStream]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 300, height: 300, facingMode: 'user' }
      });
      setVideoStream(stream);
      setIsCameraActive(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 100);
    } catch (err: any) {
      console.error(err);
      alert('Could not access camera. Please make sure camera permissions are granted.');
    }
  };

  const stopCamera = () => {
    if (videoStream) {
      videoStream.getTracks().forEach(track => track.stop());
      setVideoStream(null);
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 300;
      canvas.height = video.videoHeight || 300;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Since we scale-x-[-1] for natural mirror mode in preview, let's also mirror the captured frame to match!
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setTempPhotoData(dataUrl);
        // Do not persist yet, just notify of selection
        onUpdateSuccess('Photo captured! Review the preview below and click Save.');
        stopCamera();
      }
    }
  };

  const saveConfirmedPhoto = () => {
    if (tempPhotoData) {
      setPhotoData(tempPhotoData);
      localStorage.setItem('naira_profile_photo', tempPhotoData);
      onProfilePhotoChange?.(tempPhotoData);
      setTempPhotoData(null);
      onUpdateSuccess('Profile photo updated successfully!');
      window.dispatchEvent(new Event('storage'));
    }
  };

  const discardTempPhoto = () => {
    setTempPhotoData(null);
    onUpdateSuccess('Draft preview discarded.');
  };

  const removePhoto = () => {
    localStorage.removeItem('naira_profile_photo');
    setPhotoData(null);
    setTempPhotoData(null);
    onProfilePhotoChange?.(null);
    onUpdateSuccess('Profile photo removed successfully.');
    window.dispatchEvent(new Event('storage'));
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select a valid image file (PNG, JPG, JPEG, GIF, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setTempPhotoData(dataUrl);
        onUpdateSuccess('Photo uploaded! Review the preview below and click Save.');
      }
    };
    reader.onerror = () => {
      alert('Error reading image file. Please try again.');
    };
    reader.readAsDataURL(file);
  };
  
  // Bank settlement fields synced with WithdrawalForm pre-fills
  const [bankName, setBankName] = useState(() => localStorage.getItem('naira_withdraw_bank') || 'Access Bank PLC');
  const [accountNumber, setAccountNumber] = useState(() => localStorage.getItem('naira_withdraw_account_number') || '0123456789');
  const [accountName, setAccountName] = useState(() => localStorage.getItem('naira_withdraw_account_name') || 'John Doe');

  const [tfaEnabled, setTfaEnabled] = useState(() => localStorage.getItem('naira_profile_tfa') === 'true');
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [smsAlerts, setSmsAlerts] = useState(false);
  
  const isEligibleAdmin = (() => {
    const savedEmail = email || localStorage.getItem('naira_profile_email') || 'livingstone0806382@gmail.com';
    return savedEmail.toLowerCase() === 'livingstone0806382@gmail.com' || savedEmail.toLowerCase().includes('admin');
  })();

  const [isAdminState, setIsAdminState] = useState(() => {
    if (!isEligibleAdmin) return false;
    const saved = localStorage.getItem('ld_user_is_admin');
    if (saved !== null) return saved === 'true';
    return true; // Default true for the admin email
  });

  React.useEffect(() => {
    if (!isEligibleAdmin) {
      setIsAdminState(false);
    }
  }, [isEligibleAdmin]);
  
  const [saving, setSaving] = useState(false);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    
    setTimeout(() => {
      localStorage.setItem('naira_profile_name', fullName);
      localStorage.setItem('naira_profile_email', email);
      localStorage.setItem('naira_profile_level', currentLevel);
      localStorage.setItem('naira_withdraw_bank', bankName);
      localStorage.setItem('naira_withdraw_account_number', accountNumber);
      localStorage.setItem('naira_withdraw_account_name', accountName);
      localStorage.setItem('naira_profile_tfa', tfaEnabled ? 'true' : 'false');
      
      setSaving(false);
      onUpdateSuccess('Profile preferences and bank settlement records successfully saved!');
    }, 700);
  };

  const handleResetSimState = () => {
    localStorage.clear();
    window.location.reload();
  };

  return (
    <div className="space-y-8 animate-fade-in" id="profile-settings-view">
      
      {/* Overview Card */}
      <div className="bg-white rounded-2xl border border-gray-150 p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="h-16 w-16 rounded-2xl bg-green-50 text-green-700 flex items-center justify-center font-display text-2xl font-bold border border-green-200 overflow-hidden">
            {photoData ? (
              <img src={photoData} alt="Profile" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              fullName.charAt(0)
            )}
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold text-gray-950">{fullName}</h2>
            <p className="text-xs text-gray-400 mt-0.5">{email}</p>
            <div className="mt-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-green-50 text-green-700 font-mono tracking-wider uppercase">
              {currentLevel}
            </div>
          </div>
        </div>

        {confirmResetState ? (
          <div className="flex items-center gap-2 border border-red-150 bg-red-50 p-2 rounded-xl animate-scale-in">
            <span className="text-[10px] font-mono font-bold text-red-700 uppercase">Confirm reset?</span>
            <button
              type="button"
              onClick={handleResetSimState}
              className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg text-[10px] font-bold uppercase font-mono tracking-wider transition cursor-pointer"
            >
              Confirm
            </button>
            <button
              type="button"
              onClick={() => setConfirmResetState(false)}
              className="px-2.5 py-1 bg-gray-200 hover:bg-gray-300 text-gray-700 border border-gray-300 rounded-lg text-[10px] font-bold uppercase font-mono tracking-wider transition cursor-pointer"
            >
              Cancel
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setConfirmResetState(true)}
            className="inline-flex items-center space-x-1.5 border border-red-200 hover:border-red-300 bg-red-50 text-red-700 font-mono font-bold text-[11px] uppercase tracking-wider px-3.5 py-2 rounded-xl transition cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Reset Account State</span>
          </button>
        )}
      </div>

      <form onSubmit={handleSaveSettings} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left 2 Cols: Form Fields */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Identity Info */}
          <div className="bg-white rounded-2xl border border-gray-150 p-6 sm:p-8 shadow-xs space-y-4">
            <h3 className="font-display font-bold text-lg text-gray-950 flex items-center space-x-2 border-b border-gray-100 pb-3">
              <User className="h-5 w-5 text-green-600" />
              <span>Personal Identity Settings</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-sans font-bold text-gray-700 uppercase tracking-wider mb-1.5">Full Legal Name</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full text-sm rounded-xl border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-sans font-bold text-gray-700 uppercase tracking-wider mb-1.5">Email Contact Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full text-sm rounded-xl border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-sans font-bold text-gray-700 uppercase tracking-wider mb-1.5">Account Membership Plan</label>
              <div className="w-full text-sm rounded-xl border border-gray-200 dark:border-slate-800 p-3 bg-gray-50 dark:bg-slate-900 text-gray-900 dark:text-gray-100 font-medium select-none">
                {currentLevel === 'Solo' || currentLevel.toLowerCase().includes('solo') ? 'Solo Plan (₦5,000 Fee / ₦800 Daily Task reward)' :
                 currentLevel === 'Prem' || currentLevel.toLowerCase().includes('prem') ? 'Premium Plan (₦10,000 Fee / ₦1,500 Daily Task reward)' :
                 currentLevel === 'Vip' || currentLevel.toLowerCase().includes('vip') ? 'VIP Plan (₦15,000 Fee / ₦2,100 Daily Task reward)' :
                 `${currentLevel}`}
              </div>
            </div>
          </div>

          {/* Sync Bank details */}
          <div className="bg-white rounded-2xl border border-gray-150 p-6 sm:p-8 shadow-xs space-y-4">
            <h3 className="font-display font-medium text-lg text-gray-950 flex items-center space-x-2 border-b border-gray-100 pb-3">
              <Smartphone className="h-5 w-5 text-green-600" />
              <span>Nigerian Bank Payout Settlement Info</span>
            </h3>
            
            <p className="text-xs text-gray-500">
              Update your default withdrawal bank details here to automatically populate the Naira instant bank payout form.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-sans font-bold text-gray-700 uppercase tracking-wider mb-1.5">Default Bank</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Access Bank PLC"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full text-sm rounded-xl border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-sans font-bold text-gray-700 uppercase tracking-wider mb-1.5">Account Number</label>
                <input
                  type="text"
                  required
                  pattern="[0-9]{10}"
                  placeholder="10-digit NUBAN"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  className="w-full text-sm rounded-xl border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-sans font-bold text-gray-700 uppercase tracking-wider mb-1.5">Beneficiary Name</label>
                <input
                  type="text"
                  required
                  placeholder="Recipient Name"
                  value={accountName}
                  onChange={(e) => setAccountName(e.target.value)}
                  className="w-full text-sm rounded-xl border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-green-500/20 focus:border-green-600 transition font-sans"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 bg-green-600 hover:bg-green-700 text-white font-bold text-sm px-6 py-3 rounded-xl cursor-pointer transition shadow-xs disabled:opacity-50"
          >
            {saving ? 'Saving changes...' : 'Save Profile Changes'}
          </button>

        </div>

        {/* Right Col: Security Toggles */}
        <div className="space-y-6">

          {/* CAMERA PROFILE CAPTURE CARD */}
          <div className="bg-white rounded-2xl border border-gray-150 p-6 shadow-xs space-y-4">
            <h4 className="font-display font-medium text-sm text-gray-950 uppercase tracking-widest border-b border-gray-100 pb-2.5 flex items-center space-x-2">
              <Camera className="h-4.5 w-4.5 text-green-600" />
              <span>Profile Photo</span>
            </h4>
            
            <p className="text-xs text-gray-500 leading-normal">
              Capture a live photo using your device camera or upload an image from your device gallery.
            </p>

            {/* Display / Capture Stage */}
            <div className="relative flex flex-col items-center justify-center mt-2">
              {tempPhotoData ? (
                /* Temporary Pre-save Image Preview Area */
                <div id="temp-photo-preview-area" className="w-full flex flex-col items-center justify-center p-4 border border-dashed border-amber-300 rounded-2xl bg-amber-50/15 animate-fade-in shadow-inner">
                  <div className="text-[9px] uppercase font-mono font-extrabold text-amber-700 mb-3 bg-amber-100/70 border border-amber-200 px-2.5 py-1 rounded-full tracking-wider flex items-center gap-1 select-none">
                    <span className="h-1.5 w-1.5 bg-amber-500 rounded-full animate-ping" />
                    <span>⚠️ Unsaved Draft Preview</span>
                  </div>
                  
                  <div className="relative w-full aspect-square max-w-[180px] rounded-2xl overflow-hidden border border-amber-200 shadow-md mb-3 bg-white">
                    <img 
                      src={tempPhotoData} 
                      alt="Temporary pre-save avatar preview" 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <p className="text-[10px] text-gray-500 text-center mb-4 leading-normal font-sans">
                    Confirm if you would like to apply this image as your brand new profile photo.
                  </p>

                  <div className="flex flex-col gap-2 w-full">
                    <button
                      type="button"
                      onClick={saveConfirmedPhoto}
                      className="w-full py-2.5 bg-green-600 hover:bg-green-700 text-white font-mono font-bold text-[11px] uppercase tracking-wider rounded-xl transition cursor-pointer text-center flex items-center justify-center gap-1.5"
                    >
                      <Save className="h-3.5 w-3.5" />
                      <span>Confirm & Save Photo</span>
                    </button>
                    <button
                      type="button"
                      onClick={discardTempPhoto}
                      className="w-full py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-mono font-bold text-[11px] uppercase tracking-wider rounded-xl transition cursor-pointer text-center"
                    >
                      Discard Preview
                    </button>
                  </div>
                </div>
              ) : isCameraActive ? (
                <div className="w-full flex flex-col items-center">
                  <div className="relative w-full aspect-square max-w-[200px] rounded-2xl overflow-hidden border-2 border-green-600 shadow-inner bg-slate-950">
                    <video 
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover scale-x-[-1]" 
                    />
                    {/* Visual Guide Overlay */}
                    <div className="absolute inset-0 border-[16px] border-black/45 rounded-full pointer-events-none" />
                  </div>
                  
                  <div className="mt-4 w-full flex gap-2">
                    <button
                      type="button"
                      onClick={capturePhoto}
                      className="flex-1 py-2 bg-green-600 hover:bg-green-700 text-white font-mono font-bold text-[11px] uppercase tracking-wider rounded-xl transition cursor-pointer text-center"
                    >
                      Capture Photo
                    </button>
                    <button
                      type="button"
                      onClick={stopCamera}
                      className="px-3.5 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-mono font-bold text-[11px] uppercase tracking-wider rounded-xl transition cursor-pointer text-center"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="w-full flex flex-col items-center">
                  <div className="relative w-full aspect-square max-w-[200px] rounded-2xl overflow-hidden border border-gray-150 shadow-2xs bg-gray-50 flex items-center justify-center">
                    {photoData ? (
                      <img 
                        src={photoData} 
                        alt="Captured profile" 
                        className="w-full h-full object-cover" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="text-center p-4">
                        <div className="h-12 w-12 rounded-full bg-green-50 text-green-600 flex items-center justify-center mx-auto mb-2 border border-green-200">
                          <Camera className="h-6 w-6" />
                        </div>
                        <span className="text-[10px] text-gray-400 font-mono">No Photo Active</span>
                      </div>
                    )}
                  </div>

                  {/* Camera & Gallery Actions */}
                  <div className="mt-4 w-full flex flex-col gap-2">
                    <button
                      type="button"
                      onClick={startCamera}
                      className="w-full py-2 bg-green-50 hover:bg-green-100 border border-green-200 text-green-700 font-mono font-bold text-[11px] uppercase tracking-wider rounded-xl transition cursor-pointer text-center flex items-center justify-center gap-1.5"
                    >
                      <Camera className="h-3.5 w-3.5" />
                      <span>{photoData ? 'Retake with Camera' : 'Take with Camera'}</span>
                    </button>

                    <label
                      htmlFor="photo-upload-input"
                      className="w-full py-2 bg-slate-50 hover:bg-slate-150 border border-slate-200 text-slate-700 font-mono font-bold text-[11px] uppercase tracking-wider rounded-xl transition cursor-pointer text-center flex items-center justify-center gap-1.5 align-middle"
                    >
                      <Upload className="h-3.5 w-3.5 text-slate-500" />
                      <span>Upload from Gallery</span>
                    </label>
                    <input
                      type="file"
                      id="photo-upload-input"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                    
                    {photoData && (
                      confirmDeletePhoto ? (
                        <div className="flex flex-col gap-1.5 p-2 bg-red-50/50 border border-red-150 rounded-xl animate-scale-in">
                          <span className="text-[9px] font-mono font-bold text-red-700 text-center uppercase">Delete avatar?</span>
                          <div className="flex gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                removePhoto();
                                setConfirmDeletePhoto(false);
                              }}
                              className="flex-1 py-1 bg-red-600 hover:bg-red-700 text-white font-mono text-[9px] font-black uppercase rounded transition cursor-pointer"
                            >
                              Yes
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeletePhoto(false)}
                              className="flex-1 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-mono text-[9px] font-black uppercase rounded transition cursor-pointer"
                            >
                              No
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmDeletePhoto(true)}
                          className="w-full py-1.5 bg-red-50 hover:bg-red-100 border border-red-200 text-red-650 font-mono font-bold text-[10px] uppercase tracking-wider rounded-xl transition cursor-pointer text-center flex items-center justify-center gap-1 animate-fade-in"
                        >
                          <Trash2 className="h-3 w-3" />
                          <span>Delete Photo</span>
                        </button>
                      )
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Theme Preference Toggle Card */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-150 dark:border-gray-800 p-6 shadow-xs space-y-4">
            <h4 id="theme-settings-title" className="font-display font-medium text-sm text-gray-950 dark:text-white uppercase tracking-widest border-b border-gray-100 dark:border-gray-800 pb-2.5 flex items-center space-x-2">
              {theme === 'dark' ? (
                <Moon className="h-4.5 w-4.5 text-green-600" />
              ) : theme === 'light' ? (
                <Sun className="h-4.5 w-4.5 text-green-600" />
              ) : (
                <Monitor className="h-4.5 w-4.5 text-green-600" />
              )}
              <span>Theme Preference</span>
            </h4>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Customize your default viewing preference. Choose between Light, Dark, or sync with your device system settings.
            </p>
            <div className="grid grid-cols-3 gap-2.5 pt-2">
              <button
                type="button"
                id="theme-light-btn"
                onClick={() => onThemeChange('light')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all cursor-pointer ${
                  theme === 'light'
                    ? 'border-green-600 bg-green-50/50 dark:bg-green-950/20 text-green-700 dark:text-green-400 font-medium shadow-2xs'
                    : 'border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-400'
                }`}
              >
                <Sun className="h-5 w-5 mb-1.5" />
                <span className="text-[11px] font-mono uppercase tracking-wider">Light</span>
              </button>

              <button
                type="button"
                id="theme-dark-btn"
                onClick={() => onThemeChange('dark')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all cursor-pointer ${
                  theme === 'dark'
                    ? 'border-green-600 bg-green-50/50 dark:bg-green-950/20 text-green-700 dark:text-green-400 font-medium shadow-2xs'
                    : 'border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-400'
                }`}
              >
                <Moon className="h-5 w-5 mb-1.5" />
                <span className="text-[11px] font-mono uppercase tracking-wider">Dark</span>
              </button>

              <button
                type="button"
                id="theme-system-btn"
                onClick={() => onThemeChange('system')}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all cursor-pointer ${
                  theme === 'system'
                    ? 'border-green-600 bg-green-50/50 dark:bg-green-950/20 text-green-700 dark:text-green-400 font-medium shadow-2xs'
                    : 'border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-400'
                }`}
              >
                <Monitor className="h-5 w-5 mb-1.5" />
                <span className="text-[11px] font-mono uppercase tracking-wider">System</span>
              </button>
            </div>
          </div>

          {/* Admin Privileges Toggle Card */}
          {isEligibleAdmin && (
            <div className="bg-white rounded-2xl border border-gray-150 p-6 shadow-xs space-y-4">
              <h4 className="font-display font-medium text-sm text-gray-950 uppercase tracking-widest border-b border-gray-100 pb-2.5 flex items-center space-x-2">
                <Shield className="h-4.5 w-4.5 text-amber-600" />
                <span>Admin Privileges</span>
              </h4>
              <p className="text-xs text-gray-500">
                Only authorized system administrators can access the "My Business" and "One-Time Token Control Panel".
              </p>
              <div className="flex items-center justify-between pt-1">
                <div>
                  <h5 className="text-xs font-bold text-gray-900 font-sans">Admin Access</h5>
                  <p className="text-[11px] text-gray-400 mt-0.5 font-sans">Toggle admin role over the platform.</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const nextVal = !isAdminState;
                    setIsAdminState(nextVal);
                    localStorage.setItem('ld_user_is_admin', nextVal ? 'true' : 'false');
                    // Dispatch a storage event to alert high-order listeners in App.tsx
                    window.dispatchEvent(new Event('storage'));
                    onUpdateSuccess(nextVal ? 'Admin privileges granted! "My Business" portal is now unlocked.' : 'Admin privileges revoked. "My Business" portal is restricted.');
                  }}
                  className={`w-11 h-6 rounded-full transition-colors focus:outline-none relative cursor-pointer shrink-0 ${
                    isAdminState ? 'bg-amber-600' : 'bg-gray-200'
                  }`}
                >
                  <span className={`block h-5 w-5 rounded-full bg-white shadow-sm transition-transform absolute top-0.5 ${
                    isAdminState ? 'translate-x-5.5' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>
              {isAdminState && (
                <div className="bg-amber-50/75 p-3 rounded-xl border border-amber-150 text-[10.5px] text-amber-800 font-mono leading-relaxed select-none">
                  🛡️ ACTIVE ADMIN: You have full clearance to generate single-use tokens and publish promotion campaigns in Advertiser Mode.
                </div>
              )}
            </div>
          )}

          <div className="bg-white rounded-2xl border border-gray-150 p-6 shadow-xs space-y-6">
            <h4 className="font-display font-medium text-sm text-gray-950 uppercase tracking-widest border-b border-gray-100 pb-2.5 flex items-center space-x-2">
              <Shield className="h-4.5 w-4.5 text-green-600" />
              <span>Security & Integrity</span>
            </h4>

            {/* 2FA */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h5 className="text-xs font-bold text-gray-900">2-Factor Authentication</h5>
                  <p className="text-[11px] text-gray-400 mt-0.5">Encrypt with PIN before withdrawal clearance.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setTfaEnabled(!tfaEnabled)}
                  className={`w-11 h-6 rounded-full transition-colors focus:outline-none relative cursor-pointer ${
                    tfaEnabled ? 'bg-green-600' : 'bg-gray-200'
                  }`}
                >
                  <span className={`block h-5 w-5 rounded-full bg-white shadow-sm transition-transform absolute top-0.5 ${
                    tfaEnabled ? 'translate-x-5.5' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>

              {/* Email Alerts */}
              <div className="flex items-center justify-between">
                <div>
                  <h5 className="text-xs font-bold text-gray-900">Email Transaction Alerts</h5>
                  <p className="text-[11px] text-gray-400 mt-0.5">Receive prompt mail warnings on approvals.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setEmailAlerts(!emailAlerts)}
                  className={`w-11 h-6 rounded-full transition-colors focus:outline-none relative cursor-pointer ${
                    emailAlerts ? 'bg-green-600' : 'bg-gray-200'
                  }`}
                >
                  <span className={`block h-5 w-5 rounded-full bg-white shadow-sm transition-transform absolute top-0.5 ${
                    emailAlerts ? 'translate-x-5.5' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>

              {/* SMS Alerts */}
              <div className="flex items-center justify-between">
                <div>
                  <h5 className="text-xs font-bold text-gray-900">SMS Direct Alerts</h5>
                  <p className="text-[11px] text-gray-400 mt-0.5">Send instant micro-sms notifications (₦4 charge).</p>
                </div>
                <button
                  type="button"
                  onClick={() => setSmsAlerts(!smsAlerts)}
                  className={`w-11 h-6 rounded-full transition-colors focus:outline-none relative cursor-pointer ${
                    smsAlerts ? 'bg-green-600' : 'bg-gray-200'
                  }`}
                >
                  <span className={`block h-5 w-5 rounded-full bg-white shadow-sm transition-transform absolute top-0.5 ${
                    smsAlerts ? 'translate-x-5.5' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 text-[11px] text-gray-500 leading-relaxed space-y-2">
              <div className="flex items-center space-x-1 font-bold text-green-950 uppercase tracking-wider">
                <Key className="h-3.5 w-3.5 text-green-600" />
                <span>Verification Pin Key</span>
              </div>
              <p>Your unique account verification cryptographic checkkey:</p>
              <code className="block bg-gray-100 p-1.5 rounded font-mono font-bold text-[10px] text-green-800 text-center uppercase tracking-widest">
                key_naira_integrity_cleared
              </code>
            </div>
          </div>
        </div>

      </form>

    </div>
  );
}
