import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, 
  Delete, 
  Lock, 
  KeyRound, 
  Check, 
  X, 
  RefreshCw, 
  Mail, 
  Key, 
  ArrowRight,
  Sparkles,
  Info
} from 'lucide-react';

interface PinProtectionOverlayProps {
  onUnlock: () => void;
  sectionName: string;
}

type Mode = 'unlock' | 'forgot' | 'set_new_pin' | 'change_pin';

export default function PinProtectionOverlay({ onUnlock, sectionName }: PinProtectionOverlayProps) {
  const [mode, setMode] = useState<Mode>('unlock');
  const [pin, setPin] = useState<string>('');
  const [storedPin, setStoredPin] = useState<string>(() => {
    return localStorage.getItem('ld_security_pin') || '1234';
  });
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState<boolean>(false);
  
  // User profile email details
  const [userEmail] = useState<string>(() => {
    return localStorage.getItem('naira_profile_email') || 'livingstone0806382@gmail.com';
  });

  // Change PIN mode state
  const [oldPinInput, setOldPinInput] = useState<string>('');
  const [newPinInput, setNewPinInput] = useState<string>('');
  const [newPinConfirm, setNewPinConfirm] = useState<string>('');
  const [changeError, setChangeError] = useState<string | null>(null);
  const [changeSuccess, setChangeSuccess] = useState<string | null>(null);

  // Forgot PIN OTP flow state
  const [isSendingOtp, setIsSendingOtp] = useState<boolean>(false);
  const [isRealEmailSent, setIsRealEmailSent] = useState<boolean | null>(null);
  const [generatedOtp, setGeneratedOtp] = useState<string>('');
  const [otpCodeInput, setOtpCodeInput] = useState<string>('');
  const [otpErrorMsg, setOtpErrorMsg] = useState<string | null>(null);

  // New PIN input state after OTP validation
  const [resetPinInput, setResetPinInput] = useState<string>('');
  const [resetPinConfirm, setResetPinConfirm] = useState<string>('');
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetSuccess, setResetSuccess] = useState<string | null>(null);

  // Focus effect for keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (mode !== 'unlock') return; // ignore physical keyboard in menus to prevent conflicts

      if (/^[0-9]$/.test(e.key)) {
        handleDigitPress(e.key);
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Escape') {
        setPin('');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [pin, mode]);

  const handleDigitPress = (digit: string) => {
    if (errorMsg) setErrorMsg(null);
    if (pin.length < 4) {
      const nextPin = pin + digit;
      setPin(nextPin);
      
      // Auto submit when 4 digits are reached
      if (nextPin.length === 4) {
        setTimeout(() => {
          if (nextPin === storedPin) {
            onUnlock();
          } else {
            setIsShaking(true);
            setErrorMsg('Invalid PIN. Please try again.');
            setPin('');
            setTimeout(() => setIsShaking(false), 500);
          }
        }, 180);
      }
    }
  };

  const handleBackspace = () => {
    setPin(prev => prev.slice(0, -1));
  };

  const handleClear = () => {
    setPin('');
    setErrorMsg(null);
  };

  // Dispatch OTP via API endpoint
  const sendRecoveryOtp = async () => {
    setIsSendingOtp(true);
    setOtpErrorMsg(null);
    const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(randomCode);

    try {
      const res = await fetch("/api/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ recipient: userEmail.trim(), otpCode: randomCode }),
      });

      if (!res.ok) {
        throw new Error(`Server status: ${res.status}`);
      }

      const data = await res.json();
      if (data.success) {
        setIsRealEmailSent(!!data.isRealEmail);
      } else {
        setOtpErrorMsg(data.error || 'Failed to dispatch verification code.');
        setIsRealEmailSent(false);
      }
    } catch (error: any) {
      setIsRealEmailSent(false);
    } finally {
      setIsSendingOtp(false);
    }
  };

  // Trigger setup OTP flow
  const handleInitiateForgotPin = async () => {
    setMode('forgot');
    setOtpCodeInput('');
    setOtpErrorMsg(null);
    await sendRecoveryOtp();
  };

  // Verify entered OTP code
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setOtpErrorMsg(null);
    if (!otpCodeInput) {
      setOtpErrorMsg('Please enter the 6-digit confirmation key.');
      return;
    }
    if (otpCodeInput === generatedOtp) {
      setMode('set_new_pin');
      setResetPinInput('');
      setResetPinConfirm('');
      setResetError(null);
    } else {
      setOtpErrorMsg('Invalid 6-digit verification code. Please try again.');
    }
  };

  // Complete PIN reset and save
  const handleResetPinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    setResetSuccess(null);

    if (!/^\d{4}$/.test(resetPinInput)) {
      setResetError('New PIN must be exactly 4 digits.');
      return;
    }
    if (resetPinInput !== resetPinConfirm) {
      setResetError('PIN and Confirmation code do not match.');
      return;
    }

    localStorage.setItem('ld_security_pin', resetPinInput);
    setStoredPin(resetPinInput);
    setResetSuccess('Security PIN reset successfully!');
    setResetPinInput('');
    setResetPinConfirm('');

    setTimeout(() => {
      setMode('unlock');
      setPin('');
      setResetSuccess(null);
    }, 1500);
  };

  // Normal change PIN code
  const handleUpdatePin = (e: React.FormEvent) => {
    e.preventDefault();
    setChangeError(null);
    setChangeSuccess(null);

    if (oldPinInput !== storedPin) {
      setChangeError('Current PIN is incorrect.');
      return;
    }
    if (!/^\d{4}$/.test(newPinInput)) {
      setChangeError('New PIN must be exactly 4 digits.');
      return;
    }
    if (newPinInput !== newPinConfirm) {
      setChangeError('New PIN and Confirmation do not match.');
      return;
    }

    localStorage.setItem('ld_security_pin', newPinInput);
    setStoredPin(newPinInput);
    setChangeSuccess('Security PIN updated successfully!');
    setOldPinInput('');
    setNewPinInput('');
    setNewPinConfirm('');
    
    setTimeout(() => {
      setMode('unlock');
      setPin('');
      setChangeSuccess(null);
    }, 1500);
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-3xl border border-gray-150 p-6 sm:p-8 shadow-sm text-center relative overflow-hidden select-none">
      
      <AnimatePresence mode="wait">
        {mode === 'unlock' && (
          <motion.div
            key="unlock-pin"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-6"
          >
            {/* Lock Icon HUD Header */}
            <div className="flex flex-col items-center justify-center space-y-2">
              <div className="h-12 w-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 relative border border-slate-200">
                <Lock className="h-5 w-5 animate-pulse text-indigo-600" />
                <span className="absolute -top-1 -right-1 bg-red-500 rounded-full h-2.5 w-2.5 border border-white" />
              </div>
              <div>
                <span className="font-mono text-[9px] tracking-widest text-indigo-650 font-black uppercase">
                  Simulated Firewall Gate
                </span>
                <h3 className="text-base font-extrabold text-gray-950 font-display">
                  Unlock {sectionName}
                </h3>
                <p className="text-xs text-gray-400 mt-1 max-w-xs mx-auto leading-relaxed">
                  Enter your 4-digit security code to reveal sensitive ledger balances and settle secure transaction funds.
                </p>
              </div>
            </div>

            {/* Masked Dots Indicator */}
            <motion.div 
              animate={isShaking ? { x: [-10, 10, -8, 8, -5, 5, 0] } : {}}
              transition={{ duration: 0.4 }}
              className="flex justify-center gap-4.5 py-4"
            >
              {[0, 1, 2, 3].map((idx) => {
                const isFilled = pin.length > idx;
                return (
                  <motion.div
                    key={idx}
                    animate={{ 
                      scale: isFilled ? [1, 1.15, 1] : 1,
                    }}
                    transition={isFilled ? { duration: 0.2, ease: "easeOut" } : { type: 'spring', stiffness: 350, damping: 15 }}
                    className={`h-4.5 w-4.5 rounded-full border-2 transition-all duration-150 ${
                      isFilled 
                        ? 'bg-indigo-600 border-indigo-600 shadow-xs' 
                        : 'bg-slate-50 border-gray-300'
                    }`}
                  />
                );
              })}
            </motion.div>

            {/* Simulated Keypad */}
            <div className="grid grid-cols-3 gap-3 max-w-[280px] mx-auto pt-2">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                <motion.button
                  key={digit}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleDigitPress(digit)}
                  className="h-12 w-18 sm:h-14 sm:w-20 mx-auto rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-150 text-slate-800 font-extrabold text-lg flex items-center justify-center cursor-pointer transition shadow-2xs font-display animate-fade-in"
                >
                  {digit}
                </motion.button>
              ))}
              
              {/* Reset/Clear Button */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleClear}
                className="h-12 w-18 sm:h-14 sm:w-20 mx-auto rounded-xl bg-zinc-50 hover:bg-zinc-100 text-zinc-500 font-bold text-xs uppercase flex items-center justify-center cursor-pointer border border-zinc-150"
              >
                Clear
              </motion.button>

              {/* Zero Button */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleDigitPress('0')}
                className="h-12 w-18 sm:h-14 sm:w-20 mx-auto rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-150 text-slate-800 font-extrabold text-lg flex items-center justify-center cursor-pointer font-display"
              >
                0
              </motion.button>

              {/* Backspace Button */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleBackspace}
                className="h-12 w-18 sm:h-14 sm:w-20 mx-auto rounded-xl bg-zinc-50 hover:bg-zinc-100 text-zinc-500 flex items-center justify-center cursor-pointer border border-zinc-150"
                aria-label="Delete last digit"
              >
                <Delete className="h-5 w-5" />
              </motion.button>
            </div>

            {/* Error Message Hud Banner */}
            <div className="h-6 flex items-center justify-center">
              {errorMsg ? (
                <span className="text-red-600 text-xs font-bold font-mono block animate-bounce">
                  ⚠️ {errorMsg}
                </span>
              ) : (
                <span className="text-slate-400 text-[10px] font-mono block select-text">
                  Default PIN is <strong className="text-indigo-600 font-bold">1234</strong>
                </span>
              )}
            </div>

            {/* Multi-Trigger Links (Change vs Forgot PIN) */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between px-2 text-[11px] font-bold">
              <button
                type="button"
                onClick={() => {
                  setMode('change_pin');
                  setChangeError(null);
                  setChangeSuccess(null);
                }}
                className="inline-flex items-center gap-1.5 text-slate-600 hover:text-slate-850 cursor-pointer transition hover:underline"
              >
                <KeyRound className="h-3.5 w-3.5" />
                Change PIN
              </button>
              
              <button
                type="button"
                onClick={handleInitiateForgotPin}
                className="inline-flex items-center gap-1.5 text-indigo-600 hover:text-indigo-750 cursor-pointer transition hover:underline font-extrabold"
              >
                <Mail className="h-3.5 w-3.5 animate-bounce" />
                Forgot PIN? Reset with OTP
              </button>
            </div>
          </motion.div>
        )}

        {mode === 'forgot' && (
          <motion.div
            key="forgot-pin"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-5 text-left"
          >
            {/* Header */}
            <div className="text-center pb-2 border-b border-gray-100 flex items-center justify-between">
              <span className="text-xs font-black text-slate-950 font-display flex items-center gap-1.5">
                <RefreshCw className="h-3.5 w-3.5 text-indigo-600 animate-spin-slow" /> PIN Passcode Recovery
              </span>
              <button 
                type="button" 
                onClick={() => setMode('unlock')}
                className="p-1 rounded-full hover:bg-slate-100 text-gray-400 hover:text-gray-700 cursor-pointer border border-transparent hover:border-slate-150"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {isSendingOtp ? (
              <div className="py-12 flex flex-col items-center justify-center space-y-3">
                <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                <p className="text-xs text-gray-500 font-mono">Requesting secure confirmation key...</p>
              </div>
            ) : (
              <div className="space-y-4">
                
                {/* Image-Compliant Success Email Dispatcher Layout */}
                {isRealEmailSent ? (
                  /* Clean email sent confirmation alert in white layout */
                  <div className="p-4 bg-emerald-50 border border-emerald-250 rounded-2xl text-left animate-fade-in shadow-2xs">
                    <p className="text-xs text-emerald-800 leading-relaxed font-sans font-medium">
                      A secure 6-digit confirmation key has been sent to your email address: <strong className="text-emerald-950 font-semibold font-mono break-all">{userEmail}</strong>. Please check your Inbox and Spam/Junk folders.
                    </p>
                  </div>
                ) : (
                  /* Simulated view if no SMTP or offline */
                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl text-[11px] font-sans space-y-3.5 text-left relative overflow-hidden shadow-inner animate-fade-in">
                    <div className="flex items-center justify-between border-b border-slate-850 pb-2 text-[10px] uppercase font-mono text-slate-400">
                      <span className="flex items-center gap-1.5 font-bold">
                        <span className="h-1.5 w-1.5 rounded-full bg-yellow-500 animate-pulse" />
                        📬 SIMULATED INCOMING EMAIL INBOX
                      </span>
                      <span className="font-semibold text-slate-500">1 SECOND AGO</span>
                    </div>

                    <div className="space-y-1 text-slate-400 text-[10px]">
                      <div><span className="text-slate-550 font-mono">From:</span> security@ldearn.com.ng</div>
                      <div><span className="text-slate-550 font-mono">To:</span> <strong className="text-slate-300 font-semibold">{userEmail}</strong></div>
                      <div className="text-xs font-bold text-slate-200 mt-1">Subject: Secure Authorization PIN Recovery Code</div>
                    </div>

                    <div className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-3 space-y-2 mt-2 font-sans relative">
                      <p className="text-slate-350 text-[10.5px] leading-relaxed">
                        We received a secure credentials lookup check from your device. Please use the high-availability security passcode below to update your security PIN safely:
                      </p>
                      
                      <div className="text-center py-2 bg-slate-950 rounded border border-slate-800/60 my-2.5 flex items-center justify-center gap-2.5">
                        <strong className="text-teal-400 font-mono text-lg tracking-widest pl-1 select-all">{generatedOtp}</strong>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(generatedOtp);
                          }}
                          className="text-[9px] bg-slate-800 hover:bg-slate-750 font-bold px-2.5 py-1 text-slate-300 rounded font-mono border border-slate-700 transition"
                        >
                          COPY CODE
                        </button>
                      </div>
                      
                      <p className="text-[9.5px] text-slate-500 font-mono">
                        Ref Code: LD-PIN-RECOVERY-OTP // SECURE CLIENT LEDGER
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-850 text-[9px] text-slate-500 leading-normal italic">
                      💡 Want to receive physical emails? Go to AI Studio Secrets and set up your standard <code className="text-slate-400 font-mono">SMTP_USER</code> and <code className="text-slate-400 font-mono">SMTP_PASS</code> environment parameters.
                    </div>
                  </div>
                )}

                {/* Form to enter OTP and proceed */}
                <form onSubmit={handleVerifyOtp} className="space-y-4 pt-1">
                  <div>
                    <label className="block text-[10px] font-mono text-gray-500 uppercase tracking-widest mb-1.5 font-bold">
                      Enter 6-Digit Verification Code
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                        <Key className="h-4 w-4" />
                      </span>
                      <input
                        type="text"
                        maxLength={6}
                        required
                        pattern="\d*"
                        value={otpCodeInput}
                        onChange={(e) => setOtpCodeInput(e.target.value.replace(/\D/g, ''))}
                        placeholder="e.g. 123456"
                        className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-250 rounded-xl text-center text-sm font-mono text-slate-800 placeholder-slate-350 focus:outline-none focus:border-indigo-500 focus:bg-white transition tracking-widest font-extrabold"
                      />
                    </div>
                  </div>

                  {otpErrorMsg && (
                    <div className="p-2.5 bg-red-50 text-red-700 text-xs font-bold rounded-xl border border-red-100">
                      ⚠️ {otpErrorMsg}
                    </div>
                  )}

                  {/* Buttons */}
                  <div className="flex gap-2.5 pt-1">
                    <button
                      type="button"
                      onClick={sendRecoveryOtp}
                      className="flex-1 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 text-xs font-mono font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <RefreshCw className="h-3 w-3" /> Resend Code
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-2 rounded-xl bg-indigo-650 hover:bg-indigo-600 text-white text-xs font-bold transition shadow-sm flex items-center justify-center gap-1 cursor-pointer"
                    >
                      Verify OTP <ArrowRight className="h-3 w-3" />
                    </button>
                  </div>
                </form>

              </div>
            )}
          </motion.div>
        )}

        {mode === 'set_new_pin' && (
          <motion.div
            key="set-new-pin"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-5 text-left animate-fade-in"
          >
            <div className="text-center pb-2 border-b border-gray-100">
              <span className="text-xs font-black text-slate-950 font-display flex items-center gap-1.5 justify-center">
                <Sparkles className="h-3.5 w-3.5 text-emerald-500 animate-pulse" /> Reset Security PIN
              </span>
              <p className="text-[10px] text-gray-400 mt-1">OTP verified successfully! Please define your new 4-digit PIN.</p>
            </div>

            <form onSubmit={handleResetPinSubmit} className="space-y-4">
              {/* New PIN code */}
              <div>
                <label className="block text-[10px] font-mono text-gray-500 uppercase tracking-wider mb-1">
                  Enter New 4-Digit PIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  required
                  pattern="\d*"
                  value={resetPinInput}
                  onChange={(e) => setResetPinInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g. 9876"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono text-gray-800 placeholder-slate-300 focus:outline-none focus:border-indigo-500 focus:bg-white transition"
                />
              </div>

              {/* Confirm PIN code */}
              <div>
                <label className="block text-[10px] font-mono text-gray-500 uppercase tracking-wider mb-1">
                  Confirm New 4-Digit PIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  required
                  pattern="\d*"
                  value={resetPinConfirm}
                  onChange={(e) => setResetPinConfirm(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g. 9876"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono text-gray-800 placeholder-slate-300 focus:outline-none focus:border-indigo-500 focus:bg-white transition"
                />
              </div>

              {/* Status information */}
              {resetError && (
                <div className="p-2.5 bg-red-50 text-red-700 text-xs font-bold rounded-xl border border-red-100 text-center">
                  ⚠️ {resetError}
                </div>
              )}
              {resetSuccess && (
                <div className="p-2.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-150 flex items-center justify-center gap-1.5 text-center">
                  <Check className="h-4 w-4 text-emerald-600 animate-bounce" />
                  <span>{resetSuccess}</span>
                </div>
              )}

              {/* Actions */}
              <button
                type="submit"
                disabled={!!resetSuccess}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 disabled:opacity-50 text-white text-xs font-bold transition shadow-md cursor-pointer select-none"
              >
                Reset PIN & Unlock
              </button>
            </form>
          </motion.div>
        )}

        {mode === 'change_pin' && (
          <motion.div
            key="change-pin"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-5 text-left"
          >
            <div className="text-center pb-2 border-b border-gray-100 flex items-center justify-between">
              <span className="text-xs font-black text-slate-950 font-display flex items-center gap-1.5">
                <RefreshCw className="h-3.5 w-3.5 text-indigo-600 animate-spin-slow" /> Config Security PIN
              </span>
              <button 
                type="button" 
                onClick={() => setMode('unlock')}
                className="p-1 rounded-full hover:bg-slate-100 text-gray-400 hover:text-gray-700 cursor-pointer border border-transparent hover:border-slate-150"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleUpdatePin} className="space-y-4 pt-1">
              {/* Old PIN Input */}
              <div>
                <label className="block text-[10px] font-mono text-gray-500 uppercase tracking-wider mb-1">
                  Current PIN Code
                </label>
                <input
                  type="password"
                  maxLength={4}
                  required
                  pattern="\d*"
                  value={oldPinInput}
                  onChange={(e) => setOldPinInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g. 1234"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono text-gray-800 placeholder-slate-300 focus:outline-none focus:border-indigo-500 focus:bg-white transition"
                />
              </div>

              {/* New PIN Input */}
              <div>
                <label className="block text-[10px] font-mono text-gray-500 uppercase tracking-wider mb-1">
                  New 4-Digit PIN Code
                </label>
                <input
                  type="password"
                  maxLength={4}
                  required
                  pattern="\d*"
                  value={newPinInput}
                  onChange={(e) => setNewPinInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter 4 digits"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono text-gray-800 placeholder-slate-300 focus:outline-none focus:border-indigo-500 focus:bg-white transition"
                />
              </div>

              {/* Confirm New PIN */}
              <div>
                <label className="block text-[10px] font-mono text-gray-500 uppercase tracking-wider mb-1">
                  Confirm New PIN Code
                </label>
                <input
                  type="password"
                  maxLength={4}
                  required
                  pattern="\d*"
                  value={newPinConfirm}
                  onChange={(e) => setNewPinConfirm(e.target.value.replace(/\D/g, ''))}
                  placeholder="Re-enter 4 digits"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono text-gray-800 placeholder-slate-300 focus:outline-none focus:border-indigo-500 focus:bg-white transition"
                />
              </div>

              {/* Status messaging banner */}
              {changeError && (
                <div className="p-2.5 bg-red-50 text-red-700 text-xs font-bold rounded-xl border border-red-100 flex items-center gap-1.5">
                  <span>⚠️ {changeError}</span>
                </div>
              )}
              {changeSuccess && (
                <div className="p-2.5 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-150 flex items-center gap-1.5">
                  <Check className="h-4 w-4 text-emerald-600 animate-bounce" />
                  <span>{changeSuccess}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => setMode('unlock')}
                  className="flex-1 py-2 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100 text-gray-600 text-xs font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                >
                  Save PIN
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
