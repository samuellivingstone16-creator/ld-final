/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BusinessCampaign, SocialTask } from '../types';
import { formatNaira } from '../utils';
import { syncTokens } from '../lib/cloudSync';
import { useAdminSettings } from '../App';
import { 
  Briefcase, 
  Megaphone, 
  Plus, 
  Play, 
  Pause, 
  Trash2, 
  ExternalLink,
  Sparkles,
  TrendingUp,
  Info,
  DollarSign,
  Users,
  CheckCircle2,
  AlertCircle,
  Key,
  Copy,
  Check,
  Edit2,
  Save,
  Clock,
  Smartphone,
  BellRing
} from 'lucide-react';

import AdminWithdrawals, { GlobalWithdrawal } from './AdminWithdrawals';

interface MyBusinessProps {
  availableWithdrawal: number;
  onDeductBalance: (amount: number, details: string) => boolean;
  onAddHistoryLog: (title: string, amount: number, details: string) => void;
  triggerToast: (msg: string) => void;
  tasks?: SocialTask[];
  onUpdateTasks?: (allTasks: SocialTask[]) => void;
  onWithdrawalProcessed?: (wdId: string, nextStatus: 'Successful' | 'Failed', remarks: string) => void;
  isAdmin?: boolean;
  onApproveTask?: (taskId: string) => void;
  onRejectTask?: (taskId: string, reason: string) => void;
  withdrawals?: GlobalWithdrawal[];
}

const INITIAL_CAMPAIGNS: BusinessCampaign[] = [];

export default function MyBusiness({
  availableWithdrawal,
  onDeductBalance,
  onAddHistoryLog,
  triggerToast,
  tasks = [],
  onUpdateTasks,
  onWithdrawalProcessed,
  isAdmin = false,
  onApproveTask,
  onRejectTask,
  withdrawals = []
}: MyBusinessProps) {
  // Campaigns list state with local storage persistence
  const [campaigns, setCampaigns] = useState<BusinessCampaign[]>(() => {
    const saved = localStorage.getItem('naira_business_campaigns');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback to initial
      }
    }
    return INITIAL_CAMPAIGNS;
  });

  // Modal controller for Add Business Form
  const [showAddForm, setShowAddForm] = useState(false);

  // Single-use token management state
  const [tokenPlan, setTokenPlan] = useState<'Solo' | 'Prem' | 'Vip'>('Solo');
  const [createdTokens, setCreatedTokens] = useState<{ token: string; status: 'Unused' | 'Used'; plan: string }[]>(() => {
    const unusedStr = localStorage.getItem('ld_unused_tokens');
    const usedStr = localStorage.getItem('ld_used_tokens');
    let unusedList: string[] = [];
    let usedList: string[] = [];
    try {
      const SECURE_FALLBACK_TOKENS = [
        'LD-SOLO-WN4X-8BP2-YT9C',
        'LD-SOLO-7MQG-5V6K-RD4L',
        'LD-PREM-4KZ3-8X9B-PJ2W',
        'LD-PREM-9HQF-2TLK-7XMS',
        'LD-VIP-3XWY-9VPL-5NZ6',
        'LD-VIP-8RFT-4KCD-3WQZ',
        'LD-AUTH-9Y8K-4XMD-7WQP'
      ];
      unusedList = unusedStr ? JSON.parse(unusedStr) : SECURE_FALLBACK_TOKENS;
      usedList = usedStr ? JSON.parse(usedStr) : [];
      
      // Auto-save defaults if not yet defined
      if (!unusedStr) {
        localStorage.setItem('ld_unused_tokens', JSON.stringify(SECURE_FALLBACK_TOKENS));
      }
    } catch (e) {}

    const combined: { token: string; status: 'Unused' | 'Used'; plan: string }[] = [];
    unusedList.forEach(t => {
      const isPrem = t.toUpperCase().includes('PREM');
      const isVip = t.toUpperCase().includes('VIP');
      combined.push({ token: t, status: 'Unused', plan: isPrem ? '🥈 Premium' : isVip ? '👑 VIP' : '🥉 Solo' });
    });
    usedList.forEach(t => {
      const isPrem = t.toUpperCase().includes('PREM');
      const isVip = t.toUpperCase().includes('VIP');
      combined.push({ token: t, status: 'Used', plan: isPrem ? '🥈 Premium' : isVip ? '👑 VIP' : '🥉 Solo' });
    });

    return combined;
  });

  // Daily Task management form state
  const [taskPlatform, setTaskPlatform] = useState<'Twitter' | 'YouTube' | 'Instagram' | 'Facebook' | 'Telegram' | 'TikTok' | 'Survey' | 'Website'>('YouTube');
  const [taskCategory, setTaskCategory] = useState<'Social Share' | 'Video Watching' | 'Subscription' | 'User Survey' | 'App Integrity'>('Video Watching');
  const [taskTitle, setTaskTitle] = useState('');
  const [taskReward, setTaskReward] = useState(350);
  const [taskActionUrl, setTaskActionUrl] = useState('');
  const [taskInstruction, setTaskInstruction] = useState('');
  const [taskDifficulty, setTaskDifficulty] = useState<'Easy' | 'Medium' | 'Intermediate'>('Easy');
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [editingTaskIndex, setEditingTaskIndex] = useState<number | null>(null);
  const [confirmDeleteTaskIndex, setConfirmDeleteTaskIndex] = useState<number | null>(null);
  const [confirmDeleteCampaignId, setConfirmDeleteCampaignId] = useState<string | null>(null);

  const [lastDailyTaskDate, setLastDailyTaskDate] = useState(() => {
    return localStorage.getItem('ld_last_daily_task_date') || '';
  });

  // Admin-Only Registered Vendors section state driven by central AdminSettings Context
  const { 
    vendors, 
    saveVendors, 
    officialChannelLink,
    saveOfficialChannelLink,
    officialWhatsappLink,
    saveOfficialWhatsappLink,
    lastSyncedTime, 
    setLastSyncedTime, 
    justSynced, 
    setJustSynced 
  } = useAdminSettings();

  useEffect(() => {
    // Sync tokens between local storage and server to match shared state across devices without erasing local custom changes
    const syncTokensWithServer = async () => {
      try {
        const localUnusedStr = localStorage.getItem('ld_unused_tokens');
        const localUsedStr = localStorage.getItem('ld_used_tokens');
        let localUnused: string[] = [];
        let localUsed: string[] = [];
        try {
          if (localUnusedStr) localUnused = JSON.parse(localUnusedStr);
        } catch (e) {}
        try {
          if (localUsedStr) localUsed = JSON.parse(localUsedStr);
        } catch (e) {}
        
        const localItems: { token: string; status: 'Unused' | 'Used' }[] = [];
        localUnused.forEach(t => {
          if (t && typeof t === 'string') localItems.push({ token: t.trim().toUpperCase(), status: 'Unused' });
        });
        localUsed.forEach(t => {
          if (t && typeof t === 'string') localItems.push({ token: t.trim().toUpperCase(), status: 'Used' });
        });

        const tokensList = await syncTokens(localItems);
        if (tokensList) {
          const mapped = tokensList.map((item: any) => {
            const isPrem = item.token.toUpperCase().includes('PREM');
            const isVip = item.token.toUpperCase().includes('VIP');
            return {
              token: item.token,
              status: item.status,
              plan: isPrem ? '🥈 Premium' : isVip ? '👑 VIP' : '🥉 Solo'
            };
          });
          setCreatedTokens(mapped);
          
          const unused = tokensList.filter((item: any) => item.status === 'Unused').map((item: any) => item.token);
          const used = tokensList.filter((item: any) => item.status === 'Used').map((item: any) => item.token);
          localStorage.setItem('ld_unused_tokens', JSON.stringify(unused));
          localStorage.setItem('ld_used_tokens', JSON.stringify(used));
        }
      } catch (err) {
        console.error("Error syncing tokens with server:", err);
      }
    };
    syncTokensWithServer();
  }, []);
  const [newVendorLabel, setNewVendorLabel] = useState('');
  const [newVendorPhone, setNewVendorPhone] = useState('');
  const [newVendorDisplay, setNewVendorDisplay] = useState('');

  const handleManualRefreshVendors = () => {
    triggerToast('🔄 Successfully Synchronized: Reloaded latest WhatsApp vendor agents!');
  };

  const handleAddVendor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVendorLabel.trim() || !newVendorPhone.trim()) {
      triggerToast('⚠️ Please write down at least the vendor name and phone number.');
      return;
    }
    const cleanPhone = newVendorPhone.replace(/\D/g, ''); // leave only digits
    const cleanDisplay = newVendorDisplay.trim() || newVendorPhone.trim();

    const updated = [...vendors, {
      label: newVendorLabel.trim(),
      phone: cleanPhone,
      display: cleanDisplay
    }];

    saveVendors(updated);

    setNewVendorLabel('');
    setNewVendorPhone('');
    setNewVendorDisplay('');
    triggerToast(`✅ Successfully Synchronized: Registered and saved vendor agent "${newVendorLabel}"`);
  };

  const handleRemoveVendor = (indexToRemove: number) => {
    const updated = vendors.filter((_, idx) => idx !== indexToRemove);
    saveVendors(updated);
    triggerToast('❌ Successfully Synchronized: Vendor Agent successfully removed from registers.');
  };

  const handleUpdateVendorField = (index: number, key: string, value: string) => {
    const updated = vendors.map((item, idx) => {
      if (idx === index) {
        return { ...item, [key]: value };
      }
      return item;
    });
    saveVendors(updated);
  };

  const handleSaveAllVendors = () => {
    saveVendors(vendors);
    triggerToast('💾 Successfully Synchronized: Persisted all updated WhatsApp vendors globally!');
  };

  const [tempChannelLink, setTempChannelLink] = useState(officialChannelLink);
  const [tempWhatsappLink, setTempWhatsappLink] = useState(officialWhatsappLink);

  useEffect(() => {
    setTempChannelLink(officialChannelLink);
  }, [officialChannelLink]);

  useEffect(() => {
    setTempWhatsappLink(officialWhatsappLink);
  }, [officialWhatsappLink]);

  const handleUpdateChannelLink = () => {
    if (!tempChannelLink.trim().startsWith('http://') && !tempChannelLink.trim().startsWith('https://')) {
      triggerToast('⚠️ Please enter a valid URL starting with http:// or https://');
      return;
    }
    saveOfficialChannelLink(tempChannelLink.trim());
    triggerToast('✅ Official Community Telegram Link successfully updated!');
  };

  const handleUpdateWhatsappLink = () => {
    if (!tempWhatsappLink.trim().startsWith('http://') && !tempWhatsappLink.trim().startsWith('https://')) {
      triggerToast('⚠️ Please enter a valid URL starting with http:// or https://');
      return;
    }
    saveOfficialWhatsappLink(tempWhatsappLink.trim());
    triggerToast('✅ Official WhatsApp Community Link successfully updated!');
  };

  const applyTaskTemplate = (type: 'video' | 'post' | 'follow') => {
    if (type === 'video') {
      setTaskPlatform('YouTube');
      setTaskCategory('Video Watching');
      setTaskTitle('Watch and Subscribe: Emerging Africa Tech Giants Roundtable');
      setTaskReward(400);
      setTaskActionUrl('https://youtube.com/c/african_founders');
      setTaskInstruction('Click to open the sponsor YouTube video. Watch for at least 1 minute, subscribe to the channel, and like the video. Submit your precise YouTube channel name prefix or handle for fast automated approval postback.');
      setTaskDifficulty('Easy');
    } else if (type === 'post') {
      setTaskPlatform('Twitter');
      setTaskCategory('Social Share');
      setTaskTitle('Like and Repost Verified Payout Success Thread');
      setTaskReward(350);
      setTaskActionUrl('https://twitter.com/naira_earn');
      setTaskInstruction('Open the linked X (Twitter) post, smash heart, and repost the tweet. Enter your @twitter handle to authorize credit.');
      setTaskDifficulty('Easy');
    } else if (type === 'follow') {
      setTaskPlatform('Instagram');
      setTaskCategory('Subscription');
      setTaskTitle('Follow Official NaraEarn Regional Sponsor');
      setTaskReward(300);
      setTaskActionUrl('https://instagram.com/naira_earn_global');
      setTaskInstruction('Follow our official sponsor Instagram profile. Enter your exact Instagram account handle for postback verification registries.');
      setTaskDifficulty('Easy');
    }
    triggerToast(`Applied preloaded preset template: ${type.toUpperCase()}`);
  };

  const handlePublishDailyTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim() || !taskActionUrl.trim() || !taskInstruction.trim()) {
      triggerToast('Please fill out all task details.');
      return;
    }

    if (!taskActionUrl.startsWith('http://') && !taskActionUrl.startsWith('https://')) {
      triggerToast('Incorrect Link! The task action URL must start with http:// or https://');
      return;
    }

    const todayString = new Date().toISOString().split('T')[0];

    const newTask: SocialTask = {
      id: `task-admin-${Date.now()}`,
      platform: taskPlatform,
      title: taskTitle.trim(),
      reward: Number(taskReward) || 350,
      actionUrl: taskActionUrl.trim(),
      instruction: taskInstruction.trim(),
      status: 'Available',
      category: taskCategory,
      difficulty: taskDifficulty,
      createdAt: new Date().toISOString()
    };

    if (tasks && onUpdateTasks) {
      // Prepend to current tasks
      const updated = [newTask, ...tasks.filter(t => t.id !== newTask.id)];
      onUpdateTasks(updated);
      localStorage.setItem('naira_tasks', JSON.stringify(updated));
    }

    localStorage.setItem('ld_last_daily_task_date', todayString);
    setLastDailyTaskDate(todayString);
    setShowTaskForm(false);
    triggerToast('🚀 New Daily Task successfully appended as active today!');
    
    // reset form fields
    setTaskTitle('');
    setTaskActionUrl('');
    setTaskInstruction('');
  };

  const handleUpdateActiveTaskInline = (index: number, updatedFields: Partial<SocialTask>) => {
    if (tasks && onUpdateTasks) {
      const updated = tasks.map((t, idx) => idx === index ? { ...t, ...updatedFields, status: 'Available' as const } : t);
      onUpdateTasks(updated);
      localStorage.setItem('naira_tasks', JSON.stringify(updated));
      triggerToast('✏️ Active Task updated successfully and reset to "Available" status!');
    }
  };

  const handleDeleteTaskInline = (index: number) => {
    if (tasks && onUpdateTasks) {
      const updated = tasks.filter((_, idx) => idx !== index);
      onUpdateTasks(updated);
      localStorage.setItem('naira_tasks', JSON.stringify(updated));
      triggerToast('🗑️ Daily Task removed from active database list.');
    }
  };

  const handleGenerateOneTimeToken = async () => {
    // Generate secure, high-entropy token blocks to prevent guessing (trillions of combinations)
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Typo-resistant alphabet
    const genSegment = (len: number) => {
      let segment = '';
      for (let i = 0; i < len; i++) {
        segment += alphabet[Math.floor(Math.random() * alphabet.length)];
      }
      return segment;
    };

    const prefix = tokenPlan.toUpperCase();
    // Hard-to-guess format: LD-PREM-XXXX-XXXX-XXXX
    const newToken = `LD-${prefix}-${genSegment(4)}-${genSegment(4)}-${genSegment(4)}`;

    const unusedStr = localStorage.getItem('ld_unused_tokens');
    let unusedList: string[] = [];
    try {
      unusedList = unusedStr ? JSON.parse(unusedStr) : [];
    } catch(e) {}

    unusedList.push(newToken);
    localStorage.setItem('ld_unused_tokens', JSON.stringify(unusedList));

    setCreatedTokens(prev => [
      { token: newToken, status: 'Unused', plan: tokenPlan === 'Prem' ? '🥈 Premium' : tokenPlan === 'Vip' ? '👑 VIP' : '🥉 Solo' },
      ...prev
    ]);

    // Track on server
    try {
      const localUnusedStr = localStorage.getItem('ld_unused_tokens');
      const localUsedStr = localStorage.getItem('ld_used_tokens');
      let localUnused: string[] = [];
      let localUsed: string[] = [];
      try {
        if (localUnusedStr) localUnused = JSON.parse(localUnusedStr);
      } catch (e) {}
      try {
        if (localUsedStr) localUsed = JSON.parse(localUsedStr);
      } catch (e) {}
      
      const localItems: { token: string; status: 'Unused' | 'Used' }[] = [];
      localUnused.forEach(t => {
        if (t && typeof t === 'string') localItems.push({ token: t.trim().toUpperCase(), status: 'Unused' });
      });
      localUsed.forEach(t => {
        if (t && typeof t === 'string') localItems.push({ token: t.trim().toUpperCase(), status: 'Used' });
      });
      await syncTokens(localItems);
    } catch (e) {
      console.error("Failed to register code with server:", e);
    }

    triggerToast(`Created Secure One-Time Token: ${newToken}`);
  };

  const handleRevokeToken = async (tokenToDelete: string) => {
    setCreatedTokens(prev => prev.filter(item => item.token !== tokenToDelete));

    const unusedStr = localStorage.getItem('ld_unused_tokens');
    let unusedList: string[] = [];
    try {
      unusedList = unusedStr ? JSON.parse(unusedStr) : [];
    } catch(e) {}
    const filteredUnused = unusedList.filter(t => t !== tokenToDelete);
    localStorage.setItem('ld_unused_tokens', JSON.stringify(filteredUnused));

    const usedStr = localStorage.getItem('ld_used_tokens');
    let usedList: string[] = [];
    try {
      usedList = usedStr ? JSON.parse(usedStr) : [];
    } catch(e) {}
    const filteredUsed = usedList.filter(t => t !== tokenToDelete);
    localStorage.setItem('ld_used_tokens', JSON.stringify(filteredUsed));

    // Delete on server
    try {
      const localItems: { token: string; status: 'Unused' | 'Used' }[] = [];
      filteredUnused.forEach(t => {
        if (t && typeof t === 'string') localItems.push({ token: t.trim().toUpperCase(), status: 'Unused' });
      });
      filteredUsed.forEach(t => {
        if (t && typeof t === 'string') localItems.push({ token: t.trim().toUpperCase(), status: 'Used' });
      });
      await syncTokens(localItems);
    } catch (e) {
      console.error("Failed to revoke token with server:", e);
    }

    triggerToast(`Token ${tokenToDelete} has been revoked successfully.`);
  };

  // Form State
  const [businessName, setBusinessName] = useState('');
  const [category, setCategory] = useState<'WhatsApp' | 'YouTube' | 'Instagram' | 'Facebook' | 'Telegram' | 'TikTok' | 'Website' | 'Other'>('WhatsApp');
  const [actionUrl, setActionUrl] = useState('');
  const [targetAction, setTargetAction] = useState('Join WhatsApp Group Community');
  const [rewardPerTask, setRewardPerTask] = useState<number>(30);
  const [totalTasksRequired, setTotalTasksRequired] = useState<number>(100);
  const [instructions, setInstructions] = useState('');
  const [isDemoCampaign, setIsDemoCampaign] = useState(false); // Let people test adding for free!

  // Form Validation and Error Handling
  const [formError, setFormError] = useState('');

  // Auto set recommended action placeholder depending on platform category
  useEffect(() => {
    switch (category) {
      case 'WhatsApp':
        setTargetAction('Join WhatsApp Group Community');
        if (rewardPerTask === 30 || rewardPerTask === 50) setRewardPerTask(30);
        break;
      case 'YouTube':
        setTargetAction('Subscribe to YouTube Channel');
        setRewardPerTask(75);
        break;
      case 'Instagram':
        setTargetAction('Follow Shop & Like Latest Post');
        setRewardPerTask(50);
        break;
      case 'Telegram':
        setTargetAction('Join Telegram Broadcast Channel');
        setRewardPerTask(30);
        break;
      case 'Website':
        setTargetAction('Click Link & Browse for 45 Seconds');
        setRewardPerTask(40);
        break;
      default:
        setTargetAction('Complete specific business task');
        setRewardPerTask(50);
    }
  }, [category]);

  // Persist campaigns
  useEffect(() => {
    localStorage.setItem('naira_business_campaigns', JSON.stringify(campaigns));
  }, [campaigns]);

  const calculatedCost = rewardPerTask * totalTasksRequired;

  // Submit Business Task Form
  const handleCreateCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    // Sanitization
    if (!businessName.trim()) {
      setFormError('Please enter a descriptive Business or Project Name.');
      return;
    }
    if (!actionUrl.trim().startsWith('http://') && !actionUrl.trim().startsWith('https://')) {
      setFormError('Please enter a valid promotion URL starting with http:// or https://');
      return;
    }
    if (!targetAction.trim()) {
      setFormError('Specify the precise target action readers need to take.');
      return;
    }
    if (rewardPerTask < 10) {
      setFormError('Minimum reward per task must be at least ₦10.');
      return;
    }
    if (totalTasksRequired < 10) {
      setFormError('Minimum targets count must be at least 10 participants.');
      return;
    }

    // Cost Deduction Checks
    if (!isDemoCampaign) {
      if (availableWithdrawal < calculatedCost) {
        window.dispatchEvent(new CustomEvent('balance-shake'));
        setFormError(`Insufficient funds in wallet tracker. This active campaign requires ${formatNaira(calculatedCost)}, but your current balance is ${formatNaira(availableWithdrawal)}. Apply "Promotional Voucher" if you have one available.`);
        return;
      }
      
      // Deduct balance from parent state
      const success = onDeductBalance(calculatedCost, `Payment for Campaign Promotion: ${businessName}`);
      if (!success) {
        window.dispatchEvent(new CustomEvent('balance-shake'));
        setFormError('Failed to process wallet transaction. Please check your available balance.');
        return;
      }
      
      // Save logs
      onAddHistoryLog(
        `Promoted: ${businessName}`,
        calculatedCost,
        `Launched ${totalTasksRequired} Tasks sponsored at ${formatNaira(rewardPerTask)} each.`
      );
    }

    // Success generation
    const newCamp: BusinessCampaign = {
      id: `BC-${Math.floor(1000 + Math.random() * 9000)}`,
      businessName: businessName.trim(),
      category,
      actionUrl: actionUrl.trim(),
      targetAction: targetAction.trim(),
      rewardPerTask,
      totalTasksRequired,
      completedTasksCount: 0,
      totalBudget: calculatedCost,
      instructions: instructions.trim() || 'Submit clear screenshot proof after completing the task.',
      status: 'Active',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
    };

    setCampaigns(prev => [newCamp, ...prev]);
    triggerToast(`Congratulations! "${businessName}" promotion is now live in our microtasks registry!`);
    
    // Reset Form
    setBusinessName('');
    setActionUrl('');
    setInstructions('');
    setShowAddForm(false);
  };

  // Change individual status
  const handleToggleStatus = (id: string, currentStatus: string) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id === id) {
        const nextStatus = currentStatus === 'Active' ? 'Paused' : 'Active';
        triggerToast(`Campaign status updated to ${nextStatus}!`);
        return { ...c, status: nextStatus };
      }
      return c;
    }));
  };

  // Remove campaign entirely
  const handleDeleteCampaign = (id: string, name: string) => {
    setCampaigns(prev => prev.filter(c => c.id !== id));
    triggerToast(`Campaign "${name}" has been deleted successfully.`);
  };

  if (!isAdmin) {
    return (
      <div className="space-y-8 animate-fade-in font-sans">
        
        {/* 2. Top Header Intro section */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white rounded-3xl border border-gray-200 p-6 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100 shrink-0">
              <Briefcase className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight text-gray-950 font-display flex items-center gap-2">
                Business Promotion Hub
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] bg-green-100 text-green-800 font-mono uppercase tracking-wide">
                  Advertiser Mode
                </span>
              </h2>
              <p className="text-xs text-gray-500 leading-snug">
                Boost your personal business, WhatsApp groups, social followers or website traffic today by recruiting real community members.
              </p>
            </div>
          </div>

          <div className="px-4 py-2.5 bg-amber-50 border border-amber-200 rounded-xl text-left max-w-sm">
            <span className="text-[10px] font-bold text-amber-800 flex items-center gap-1 uppercase tracking-wider font-mono">
              ⚠️ Input Restricted
            </span>
            <p className="text-[10.5px] text-amber-700 font-sans leading-relaxed mt-0.5 font-medium">
              Only verified Administrators are allowed to input or launch new business campaigns.
            </p>
          </div>
        </div>

        {/* 3. Grid Statistics Section */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-sm">
            <span className="text-[10px] font-bold text-gray-400 font-mono uppercase tracking-widest block font-sans">ACTIVE RUNNING CAMPAIGNS</span>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-3xl font-black font-display text-gray-950">
                {campaigns.filter(c => c.status === 'Active').length}
              </span>
              <span className="text-xs text-green-600 font-mono font-bold">• Dispatching</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-sm">
            <span className="text-[10px] font-bold text-gray-400 font-mono uppercase tracking-widest block font-sans">TOTAL CLICKS & ENGAGEMENTS</span>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-3xl font-black font-display text-gray-950">
                {campaigns.reduce((sum, c) => sum + c.completedTasksCount, 0)}
              </span>
              <span className="text-xs text-gray-500 font-mono">Real-time unique checks</span>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-sm">
            <span className="text-[10px] font-bold text-gray-400 font-mono uppercase tracking-widest block font-sans">AVAILABLE PROMOTION BUDGET</span>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-3xl font-black font-display text-green-700">
                {formatNaira(availableWithdrawal)}
              </span>
              <span className="text-xs text-gray-500 font-sans">Using wallet credits</span>
            </div>
          </div>
        </div>

        {/* Main Campaign Submissions List */}
        <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-gray-100 pb-4">
            <div className="flex items-center gap-2">
              <Megaphone className="h-4.5 w-4.5 text-gray-500" />
              <h3 className="font-bold text-sm uppercase tracking-wide text-gray-900 font-display">Your Campaign Submissions</h3>
            </div>
            <span className="text-[10px] font-mono text-gray-400 font-bold">LATEST FIRST</span>
          </div>

          {campaigns.length === 0 ? (
            <div className="py-12 text-center max-w-sm mx-auto space-y-3">
              <div className="h-12 w-12 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 mx-auto">
                <Megaphone className="h-6 w-6" />
              </div>
              <h4 className="font-bold text-sm text-gray-800">No Business Campaigns Submitted Yet</h4>
              <p className="text-xs text-gray-500 leading-relaxed">
                Launch your first WhatsApp channel promotion or business page views campaign to kickstart fast interactions.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {campaigns.map((camp) => {
                const compPercent = Math.min(100, Math.round((camp.completedTasksCount / camp.totalTasksRequired) * 100));
                return (
                  <div key={camp.id} className="py-5 flex flex-col md:flex-row md:items-center justify-between gap-4 first:pt-0 last:pb-0">
                    <div className="space-y-2 text-left">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[9px] bg-slate-100 border border-gray-200 font-mono text-gray-600 uppercase">
                          {camp.category}
                        </span>
                        <h4 className="font-black text-sm text-gray-900 font-display">{camp.businessName}</h4>
                      </div>
                      <p className="text-xs text-gray-500 leading-relaxed font-sans">
                        Target action: <strong className="text-gray-950 font-semibold">{camp.targetAction}</strong> — paying <strong className="font-mono text-green-700 font-bold">{formatNaira(camp.rewardPerTask)}</strong> per approved completion.
                      </p>
                      <div className="space-y-1 my-1.5">
                        <div className="flex justify-between items-center text-[10.5px] font-mono">
                          <span className="text-gray-500">Reach:</span>
                          <strong>{camp.completedTasksCount} / {camp.totalTasksRequired} ({compPercent}%)</strong>
                        </div>
                        <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-green-600 rounded-full transition-all duration-300"
                            style={{ width: `${compPercent}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      
      {/* 2. Top Header Intro section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white rounded-3xl border border-gray-200 p-6 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100 shrink-0">
            <Briefcase className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold tracking-tight text-gray-950 font-display flex items-center gap-2">
              Business Promotion Hub
              <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] bg-green-100 text-green-800 font-mono uppercase tracking-wide">
                Advertiser Mode
              </span>
            </h2>
            <p className="text-xs text-gray-500 leading-snug">
              Boost your personal business, WhatsApp groups, social followers or website traffic today by recruiting real community members.
            </p>
          </div>
        </div>

        <div>
          {isAdmin ? (
            <button
              onClick={() => {
                setFormError('');
                setShowAddForm(true);
              }}
              className="flex items-center gap-1.5 px-5 py-3 bg-gradient-to-r from-green-700 to-green-650 hover:from-green-600 hover:to-green-550 text-white rounded-2xl text-xs font-black uppercase tracking-wider shadow-md hover:shadow-lg transition active:scale-[0.98]"
            >
              <Plus className="h-4.5 w-4.5 stroke-[3]" />
              <span>Promote Your Business</span>
            </button>
          ) : (
            <div className="px-4 py-2.5 bg-amber-50 border border-amber-200 rounded-xl text-left max-w-sm">
              <span className="text-[10px] font-bold text-amber-800 flex items-center gap-1 uppercase tracking-wider font-mono">
                ⚠️ Input Restricted
              </span>
              <p className="text-[10.5px] text-amber-700 font-sans leading-relaxed mt-0.5 font-medium">
                Only verified Administrators are allowed to input or launch new business campaigns.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* 3. Grid Statistics Section */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-sm">
          <span className="text-[10px] font-bold text-gray-400 font-mono uppercase tracking-widest block">ACTIVE RUNNING CAMPAIGNS</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-black font-display text-gray-950">
              {campaigns.filter(c => c.status === 'Active').length}
            </span>
            <span className="text-xs text-green-600 font-mono font-bold">• Dispatching</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-sm">
          <span className="text-[10px] font-bold text-gray-400 font-mono uppercase tracking-widest block">TOTAL CLICKS & ENGAGEMENTS</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-black font-display text-gray-950">
              {campaigns.reduce((sum, c) => sum + c.completedTasksCount, 0)}
            </span>
            <span className="text-xs text-gray-500 font-mono">Real-time unique checks</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-gray-200 shadow-sm">
          <span className="text-[10px] font-bold text-gray-400 font-mono uppercase tracking-widest block">AVAILABLE PROMOTION BUDGET</span>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-3xl font-black font-display text-green-700">
              {formatNaira(availableWithdrawal)}
            </span>
            <span className="text-xs text-gray-500 font-sans">Using wallet credits</span>
          </div>
        </div>
      </div>

      {/* Main Campaign Submissions List */}
      <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-gray-100 pb-4">
          <div className="flex items-center gap-2">
            <Megaphone className="h-4.5 w-4.5 text-gray-550" />
            <h3 className="font-bold text-sm uppercase tracking-wide text-gray-900 font-display">Your Campaign Submissions</h3>
          </div>
          <span className="text-[10px] font-mono text-gray-400 font-bold">LATEST FIRST</span>
        </div>

        {campaigns.length === 0 ? (
          <div className="py-12 text-center max-w-sm mx-auto space-y-3">
            <div className="h-12 w-12 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 mx-auto">
              <Megaphone className="h-6 w-6" />
            </div>
            <h4 className="font-bold text-sm text-gray-800">No Business Campaigns Submitted Yet</h4>
            <p className="text-xs text-gray-500 leading-relaxed">
              Launch your first WhatsApp channel promotion or business page views campaign to kickstart fast interactions. Click "Promote Your Business" above!
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {campaigns.map((camp) => {
              const compPercent = Math.min(100, Math.round((camp.completedTasksCount / camp.totalTasksRequired) * 100));
              return (
                <div key={camp.id} className="py-5 first:pt-0 last:pb-0 flex flex-col md:flex-row md:items-center justify-between gap-5">
                  <div className="space-y-2.5 flex-1 max-w-xl">
                    <div className="flex items-center flex-wrap gap-2">
                      <span className="text-xs font-bold text-gray-950 font-display">{camp.businessName}</span>
                      <span className={`px-2 py-0.5 rounded text-[9.5px] font-bold font-mono uppercase ${
                        camp.category === 'WhatsApp' ? 'bg-emerald-50 text-emerald-700' :
                        camp.category === 'YouTube' ? 'bg-red-50 text-red-600' :
                        camp.category === 'Instagram' ? 'bg-fuchsia-50 text-fuchsia-700' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {camp.category}
                      </span>
                      <span className="text-[10px] text-gray-400 font-mono">| {camp.createdAt}</span>
                    </div>

                    <p className="text-xs text-gray-650 leading-relaxed font-sans">
                      Target action: <strong className="text-gray-900 font-semibold">{camp.targetAction}</strong> — paying <strong className="font-mono text-green-750 font-bold">{formatNaira(camp.rewardPerTask)}</strong> per approved completion.
                    </p>

                    {/* Progress details */}
                    <div className="space-y-1 my-1.5">
                      <div className="flex justify-between items-center text-[10.5px] font-mono">
                        <span className="text-gray-450 text-gray-500 font-medium">Campaign Conversion reach:</span>
                        <strong className="text-gray-800">{camp.completedTasksCount} / {camp.totalTasksRequired} ({compPercent}%)</strong>
                      </div>
                      <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-green-600 rounded-full transition-all duration-300"
                          style={{ width: `${compPercent}%` }}
                        />
                      </div>
                    </div>

                    {/* URL */}
                    <div className="flex items-center gap-1 text-[11px] font-mono text-gray-400">
                      <span>URL Path:</span>
                      <a 
                        href={camp.actionUrl} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="text-green-600 hover:underline flex items-center gap-0.5 font-sans font-medium"
                      >
                        {camp.actionUrl} 
                        <ExternalLink className="h-2.5 w-2.5" />
                      </a>
                    </div>
                  </div>

                  {/* Actions & Status controller */}
                  <div className="flex items-center gap-3 self-start md:self-center shrink-0">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold font-mono uppercase tracking-wide ${
                      camp.status === 'Active' ? 'bg-green-100 text-green-800' :
                      camp.status === 'Paused' ? 'bg-amber-100 text-amber-800' :
                      'bg-slate-100 text-slate-700'
                    }`}>
                      {camp.status}
                    </span>

                    {/* Play/Pause Button */}
                    <button
                      type="button"
                      onClick={() => handleToggleStatus(camp.id, camp.status)}
                      disabled={camp.status === 'Completed'}
                      title={camp.status === 'Active' ? 'Pause Campaign' : 'Resume Campaign'}
                      className={`p-2 rounded-lg border border-gray-200 transition bg-white text-gray-550 shadow-xs cursor-pointer ${
                        camp.status === 'Completed' ? 'opacity-40 cursor-not-allowed' : 'hover:bg-slate-50 hover:text-gray-900'
                      }`}
                    >
                      {camp.status === 'Active' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 text-emerald-600" />}
                    </button>

                    {/* Trash Button */}
                    {confirmDeleteCampaignId === camp.id ? (
                      <div className="flex items-center gap-1.5 animate-scale-in">
                        <button
                          type="button"
                          onClick={() => {
                            handleDeleteCampaign(camp.id, camp.businessName);
                            setConfirmDeleteCampaignId(null);
                          }}
                          className="px-2.5 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-[9px] font-black uppercase font-mono tracking-wider transition cursor-pointer"
                        >
                          Confirm
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteCampaignId(null)}
                          className="px-2.5 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 border border-gray-200 rounded-lg text-[9px] font-black uppercase font-mono tracking-wider transition cursor-pointer"
                        >
                          No
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteCampaignId(camp.id)}
                        className="p-2 rounded-lg border border-gray-200 hover:bg-red-50 hover:border-red-150 text-gray-450 hover:text-red-600 transition bg-white shadow-xs cursor-pointer"
                        title="Delete Campaign"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* User Cashout Verification Desk (Withdrawals Dashboard) */}
      <AdminWithdrawals 
        triggerToast={triggerToast}
        onWithdrawalProcessed={onWithdrawalProcessed}
        tasks={tasks}
        onApproveTask={onApproveTask}
        onRejectTask={onRejectTask}
        withdrawals={withdrawals}
      />

      {/* 4. Verified Vendor: Single-Use Activation Token Generator Dashboard */}
      <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 bg-green-50 rounded-xl border border-green-100 flex items-center justify-center text-green-700">
              <Key className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm uppercase tracking-wide text-gray-900 font-display flex items-center gap-2">
                One-Time Token Control Panel
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[9px] bg-amber-100 text-amber-800 font-mono font-black uppercase tracking-wide">
                  Admin Only
                </span>
              </h3>
              <p className="text-[11px] text-gray-500 font-sans leading-none mt-1">
                Generate high-security single-use activation codes. Copy and dispatch codes directly via WhatsApp.
              </p>
            </div>
          </div>
          
          {/* Quick Creator buttons */}
          <div className="flex items-center gap-1.5 self-start sm:self-center">
            <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-200">
              {(['Solo', 'Prem', 'Vip'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setTokenPlan(p)}
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-bold font-mono uppercase transition cursor-pointer ${
                    tokenPlan === p 
                      ? 'bg-white text-gray-900 shadow-xs' 
                      : 'text-gray-500 hover:text-gray-850'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={handleGenerateOneTimeToken}
              className="px-3.5 py-2.5 bg-gray-950 hover:bg-gray-850 text-white font-bold text-[10px] uppercase tracking-wider rounded-xl transition shadow active:scale-[0.98] flex items-center gap-1 cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Create Token</span>
            </button>
          </div>
        </div>

        {/* List of active tokens */}
        <div className="space-y-4">
          <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest block text-left">
            Generated Token Codes ({createdTokens.length} active logs)
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {createdTokens.map((item, index) => (
              <div 
                key={`${item.token}-${index}`} 
                className={`p-3.5 rounded-2xl border transition flex flex-col justify-between gap-3 ${
                  item.status === 'Used' 
                    ? 'bg-gray-50/50 border-gray-100 opacity-60' 
                    : 'bg-gradient-to-b from-white to-gray-50/40 border-gray-200/80 hover:border-green-350 shadow-3xs'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1 text-left">
                    <span className="text-[9.5px] font-mono text-gray-400 font-bold block uppercase tracking-wide">
                      Tier: {item.plan}
                    </span>
                    <span className="text-xs font-mono font-black text-gray-900 select-all block break-all">
                      {item.token}
                    </span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[8.5px] font-mono font-bold uppercase tracking-wider ${
                    item.status === 'Used' 
                      ? 'bg-red-50 text-red-600' 
                      : 'bg-green-50 text-green-700 animate-pulse'
                  }`}>
                    {item.status}
                  </span>
                </div>

                <div className="flex items-center justify-between border-t border-gray-100 pt-3">
                  <button
                    type="button"
                    onClick={() => {
                      if (item.status === 'Used') return;
                      navigator.clipboard.writeText(item.token);
                      triggerToast(`Copied activation code: ${item.token}`);
                    }}
                    disabled={item.status === 'Used'}
                    className={`flex items-center gap-1 text-[10px] font-bold font-mono uppercase tracking-wider transition cursor-pointer ${
                      item.status === 'Used' 
                        ? 'text-gray-300' 
                        : 'text-green-700 hover:text-green-600'
                    }`}
                  >
                    <Copy className="h-3 w-3" />
                    <span>Copy Code</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleRevokeToken(item.token)}
                    className="text-gray-450 hover:text-red-600 text-[10px] font-bold font-mono uppercase tracking-wider transition cursor-pointer"
                    title="Revoke and cancel"
                  >
                    Revoke
                  </button>
                </div>
              </div>
            ))}
          </div>

          {createdTokens.length === 0 && (
            <div className="p-8 text-center bg-gray-50 rounded-2xl border border-dashed border-gray-200 text-gray-405 text-xs font-medium max-w-md mx-auto">
              No custom activation tokens generated. Choose a tier above and click "Create Token" to boot one.
            </div>
          )}
        </div>
      </div>

      {/* 5. Admin-Only Daily Tasks Manager (One Task Per Day Flow) */}
      <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 bg-amber-50 rounded-xl border border-amber-100 flex items-center justify-center text-amber-700">
              <Sparkles className="h-5 w-5 text-amber-600 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-sm uppercase tracking-wide text-gray-900 font-display flex items-center gap-2">
                Daily Tasks Control Room
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[9px] bg-amber-100 text-amber-800 font-mono font-black uppercase tracking-wide">
                  Admin Console
                </span>
              </h3>
              <p className="text-[11px] text-gray-500 font-sans leading-none mt-1">
                Upload sponsored posts, video watching links, or follow handles. Users can complete ONE primary task per day.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setShowTaskForm(!showTaskForm);
              setEditingTaskIndex(null);
            }}
            className="px-3.5 py-2.5 bg-green-600 hover:bg-green-700 text-white font-bold text-[10px] uppercase tracking-wider rounded-xl transition shadow active:scale-[0.98] flex items-center gap-1 cursor-pointer self-start sm:self-center"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>{showTaskForm ? 'Hide Creator' : 'Add New Daily Task'}</span>
          </button>
        </div>

        {/* Rapid Deployment Presets */}
        <div className="bg-gray-100/70 p-4 rounded-2xl border border-gray-300 space-y-2 text-left">
          <span className="text-[9.5px] font-mono font-bold text-gray-400 uppercase tracking-widest block text-left">
            ⚡ 1-Click Fast Deployment Presets:
          </span>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => {
                setShowTaskForm(true);
                applyTaskTemplate('video');
              }}
              className="px-3 py-2 bg-white hover:bg-red-50 border border-gray-200 hover:border-red-200 rounded-xl text-xs font-mono text-gray-700 hover:text-red-700 font-black transition flex items-center gap-1.5 cursor-pointer"
            >
              🎥 Preload YouTube Video Task
            </button>
            <button
              type="button"
              onClick={() => {
                setShowTaskForm(true);
                applyTaskTemplate('post');
              }}
              className="px-3 py-2 bg-white hover:bg-sky-50 border border-gray-200 hover:border-sky-200 rounded-xl text-xs font-mono text-gray-700 hover:text-sky-700 font-black transition flex items-center gap-1.5 cursor-pointer"
            >
              💬 Preload Twitter/X Share Task
            </button>
            <button
              type="button"
              onClick={() => {
                setShowTaskForm(true);
                applyTaskTemplate('follow');
              }}
              className="px-3 py-2 bg-white hover:bg-pink-50 border border-gray-200 hover:border-pink-200 rounded-xl text-xs font-mono text-gray-700 hover:text-pink-700 font-black transition flex items-center gap-1.5 cursor-pointer"
            >
              👥 Preload Instagram Follow Task
            </button>
          </div>
        </div>

        {/* Task Creator Form (Toggle) */}
        {showTaskForm && (
          <form onSubmit={handlePublishDailyTask} className="p-5 bg-amber-50/50 border border-amber-300 rounded-2xl border-2 space-y-4 shadow-sm text-left">
            <div className="flex items-center justify-between border-b border-gray-100 pb-2">
              <span className="text-xs font-black text-amber-800 uppercase font-mono tracking-wider">
                Create Daily sponsored Target:
              </span>
              <button
                type="button"
                onClick={() => setShowTaskForm(false)}
                className="text-[10px] text-gray-400 hover:text-gray-600 font-mono"
              >
                Hide
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                  1. Target Platform Channel
                </label>
                <select
                  value={taskPlatform}
                  onChange={(e) => setTaskPlatform(e.target.value as any)}
                  className="w-full text-xs font-sans p-3 bg-white border border-gray-200 rounded-xl focus:border-green-600 outline-none transition cursor-pointer"
                >
                  <option value="YouTube">YouTube</option>
                  <option value="Twitter">Twitter/X</option>
                  <option value="Instagram">Instagram</option>
                  <option value="Telegram">Telegram</option>
                  <option value="Facebook">Facebook</option>
                  <option value="TikTok">TikTok</option>
                  <option value="Website">Website Link</option>
                  <option value="Survey">User Survey</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                  2. Campaign Action Category
                </label>
                <select
                  value={taskCategory}
                  onChange={(e) => setTaskCategory(e.target.value as any)}
                  className="w-full text-xs font-sans p-3 bg-white border border-gray-200 rounded-xl focus:border-green-600 outline-none transition cursor-pointer"
                >
                  <option value="Video Watching">Video Watching</option>
                  <option value="Social Share">Social Share Code</option>
                  <option value="Subscription">Account Subscription/Follow</option>
                  <option value="User Survey">Dynamic User Survey</option>
                  <option value="App Integrity">App Integrity Audit</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                3. Task Headline (What users see first)
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Subscribe to African Founders Youtube Channel"
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                className="w-full text-xs font-sans p-3 bg-white border border-gray-200 rounded-xl focus:border-green-600 outline-none transition"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                  4. Pay reward rate per Task (₦)
                </label>
                <input
                  type="number"
                  required
                  min={50}
                  step={10}
                  value={taskReward}
                  onChange={(e) => setTaskReward(Math.max(10, parseInt(e.target.value) || 0))}
                  className="w-full text-xs font-mono p-3 bg-white border border-gray-200 rounded-xl focus:border-green-600 outline-none transition"
                />
                <span className="text-[9px] text-gray-400 font-sans block block-none">
                  User holds a premium plan multiplier on this payout value.
                </span>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                  5. Action target link (Video or follow post redirect)
                </label>
                <input
                  type="url"
                  required
                  placeholder="e.g. https://youtube.com/c/your-channel"
                  value={taskActionUrl}
                  onChange={(e) => setTaskActionUrl(e.target.value)}
                  className="w-full text-xs font-mono p-3 bg-white border border-gray-200 rounded-xl focus:border-green-600 outline-none transition"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                6. Performers requirements & proof Instructions
              </label>
              <textarea
                required
                rows={3}
                placeholder="Describe what the user must do and upload to pass automated verification..."
                value={taskInstruction}
                onChange={(e) => setTaskInstruction(e.target.value)}
                className="w-full text-xs font-sans p-3 bg-white border border-gray-200 rounded-xl focus:border-green-600 outline-none transition"
              />
            </div>

            <div className="pt-2 flex gap-3">
              <button
                type="button"
                onClick={() => {
                  setShowTaskForm(false);
                  setTaskTitle('');
                  setTaskActionUrl('');
                }}
                className="flex-1 py-3 bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-700 font-bold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer text-center"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-3 bg-green-600 hover:bg-green-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer text-center shadow-md leading-none"
              >
                Publish Live Task today
              </button>
            </div>
          </form>
        )}

        {/* Existing Tasks Logs / Custom Interactive Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest block text-left">
              Active Daily Tasks List ({tasks ? tasks.length : 0} registered)
            </span>
            <span className="text-[9px] font-mono text-gray-400">
              Only the top task (index 0) is displayed to users as today's current campaign.
            </span>
          </div>

          <div className="space-y-3.5">
            {tasks && tasks.map((item, index) => {
              const isActiveToday = index === 0;
              const isEditing = editingTaskIndex === index;

              return (
                <div 
                  key={item.id} 
                  className={`p-4 rounded-2xl border transition text-left space-y-3 ${
                    isActiveToday 
                      ? 'bg-amber-50/80 border-amber-400 border-2 shadow-xs ring-2 ring-amber-400/20' 
                      : 'bg-gray-50 border-gray-300'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="px-2 py-0.5 rounded text-[9px] bg-gray-950 text-white font-mono font-bold uppercase tracking-wider">
                          {item.platform}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[9px] bg-gray-150 border border-gray-200 text-gray-600 font-mono uppercase">
                          {item.category}
                        </span>
                        {isActiveToday && (
                          <span className="px-2 py-0.5 rounded text-[9px] bg-amber-500 text-white font-mono font-black uppercase tracking-widest animate-pulse flex items-center gap-0.5">
                            🔥 Active Task Today
                          </span>
                        )}
                      </div>
                      
                      {!isEditing ? (
                        <h4 className="text-sm font-black text-gray-950 font-display">
                          {item.title}
                        </h4>
                      ) : (
                        <div className="space-y-2 pt-2">
                          <label className="text-[9px] font-mono font-bold text-gray-400 uppercase block">Edit Title:</label>
                          <input 
                            type="text" 
                            defaultValue={item.title} 
                            id={`edit-title-${index}`}
                            className="w-full text-xs p-2 bg-white border border-gray-200 rounded-lg outline-none uppercase font-semibold text-gray-900"
                          />
                        </div>
                      )}
                    </div>

                    <div className="text-left sm:text-right">
                      <span className="block text-[8px] font-mono text-gray-400 uppercase tracking-widest">Base Payout Reward</span>
                      <strong className="text-sm font-mono text-green-700 font-bold block">
                        ₦{item.reward}
                      </strong>
                    </div>
                  </div>

                  {/* Inline editable block or static parameters */}
                  {isEditing ? (
                    <div className="space-y-2 pt-2 border-t border-gray-100">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="text-[9px] font-mono font-bold text-gray-400 uppercase block">Edit Action Redirect Link:</label>
                          <input 
                            type="url" 
                            defaultValue={item.actionUrl} 
                            id={`edit-url-${index}`}
                            className="w-full text-xs font-mono p-2 bg-white border border-gray-200 rounded-lg outline-none text-gray-950"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-mono font-bold text-gray-400 uppercase block">Edit Payreward Amount (₦):</label>
                          <input 
                            type="number" 
                            defaultValue={item.reward} 
                            id={`edit-reward-${index}`}
                            className="w-full text-xs font-mono p-2 bg-white border border-gray-200 rounded-lg outline-none text-gray-950"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-[9px] font-mono font-bold text-gray-400 uppercase block font-sans">Edit Instruction guidelines details:</label>
                        <textarea 
                          rows={2} 
                          defaultValue={item.instruction} 
                          id={`edit-instr-${index}`}
                          className="w-full text-xs p-2 bg-white border border-gray-200 rounded-lg outline-none text-gray-950"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="text-xs text-gray-600 bg-white p-3 rounded-xl border border-gray-100 font-sans space-y-1">
                      <p className="font-bold text-[9px] text-gray-400 uppercase font-mono tracking-wider">Instructions:</p>
                      <p className="font-medium text-gray-700 leading-normal">{item.instruction}</p>
                      <p className="text-[10px] font-mono text-green-600 mt-2 hover:underline truncate block">
                        🔗 Target Link: <a href={item.actionUrl} target="_blank" rel="noopener noreferrer" className="font-black underline">{item.actionUrl}</a>
                      </p>
                    </div>
                  )}

                  {/* Operational controls */}
                  <div className="flex items-center justify-between border-t border-gray-100 pt-3 flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      {isEditing ? (
                        <>
                          <button
                            type="button"
                            onClick={() => {
                              const editTitle = (document.getElementById(`edit-title-${index}`) as HTMLInputElement)?.value || '';
                              const editUrl = (document.getElementById(`edit-url-${index}`) as HTMLInputElement)?.value || '';
                              const editRewardStr = (document.getElementById(`edit-reward-${index}`) as HTMLInputElement)?.value || '';
                              const editInstr = (document.getElementById(`edit-instr-${index}`) as HTMLTextAreaElement)?.value || '';
                              
                              if (!editTitle || !editUrl || !editInstr) {
                                triggerToast('Please fill out all updated task details first.');
                                return;
                              }
                              
                              handleUpdateActiveTaskInline(index, {
                                title: editTitle,
                                actionUrl: editUrl,
                                reward: Number(editRewardStr) || 350,
                                instruction: editInstr
                              });
                              setEditingTaskIndex(null);
                            }}
                            className="px-2.5 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded-lg text-[10px] font-bold font-mono uppercase flex items-center gap-1 cursor-pointer"
                          >
                            <Save className="h-3 w-3" />
                            <span>Save Changes</span>
                          </button>
                          
                          <button
                            type="button"
                            onClick={() => setEditingTaskIndex(null)}
                            className="px-2.5 py-1.5 bg-gray-100 hover:bg-gray-150 text-gray-600 rounded-lg text-[10px] font-bold font-mono uppercase cursor-pointer"
                          >
                            Cancel
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            type="button"
                            onClick={() => setEditingTaskIndex(index)}
                            className="px-2.5 py-1.5 bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-750 hover:text-gray-950 rounded-lg text-[10px] font-bold font-mono uppercase flex items-center gap-1 cursor-pointer"
                          >
                            <Edit2 className="h-3 w-3" />
                            <span>Edit Task Details</span>
                          </button>

                          {!isActiveToday && (
                            <button
                              type="button"
                              onClick={() => {
                                if (tasks && onUpdateTasks) {
                                  // Click to set as Active Today: move to index 0
                                  const targetTask = tasks[index];
                                  const otherTasks = tasks.filter((_, idx) => idx !== index);
                                  const rearranged = [targetTask, ...otherTasks];
                                  onUpdateTasks(rearranged);
                                  localStorage.setItem('naira_tasks', JSON.stringify(rearranged));
                                  triggerToast(`⚡ Successfully activated: "${targetTask.title}" for Today!`);
                                }
                              }}
                              className="px-2.5 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 text-amber-600 font-extrabold rounded-lg text-[10px] font-mono uppercase cursor-pointer"
                              title="Promote this task to today's active primary slot"
                            >
                              ⚡ Set Active Today
                            </button>
                          )}
                        </>
                      )}
                    </div>

                    {confirmDeleteTaskIndex === index ? (
                      <div className="flex items-center gap-1.5 animate-scale-in">
                        <span className="text-[9px] font-mono font-bold text-red-600 uppercase">Confirm Delete?</span>
                        <button
                          type="button"
                          onClick={() => {
                            handleDeleteTaskInline(index);
                            setConfirmDeleteTaskIndex(null);
                          }}
                          className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white rounded-md text-[9px] font-black font-mono uppercase tracking-wider transition cursor-pointer"
                        >
                          Yes
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteTaskIndex(null)}
                          className="px-2 py-1 bg-gray-200 hover:bg-gray-300 text-gray-750 rounded-md text-[9px] font-black font-mono uppercase tracking-wider transition cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setConfirmDeleteTaskIndex(index);
                        }}
                        className="text-gray-450 hover:text-red-700 text-[10px] font-bold font-mono uppercase tracking-wider transition cursor-pointer"
                      >
                        Delete
                      </button>
                    )}
                  </div>
                </div>
              );
            })}

            {(!tasks || tasks.length === 0) && (
              <div className="p-8 text-center bg-gray-50 rounded-2xl border border-dashed border-gray-200 text-gray-450 text-xs font-medium max-w-md mx-auto">
                No sponsored Daily Tasks are configured. Click "Add New Daily Task" or choose a fast deployment preset above to program one now!
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 6. Admin Settings: Verified WhatsApp Vendors Manager Sub-section */}
      <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 bg-green-50 rounded-xl border border-green-100 flex items-center justify-center text-green-700">
              <Users className="h-5 w-5" />
            </div>
            <div className="text-left">
              <h3 className="font-bold text-sm uppercase tracking-wide text-gray-900 font-display flex items-center gap-2">
                Verified Vendor Settings
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[9px] bg-green-100 text-green-800 font-mono font-black uppercase tracking-wide">
                  Admin System
                </span>
              </h3>
              <p className="text-[11px] text-gray-500 font-sans leading-none mt-1">
                Configure verified WhatsApp vendor agents shown on the user registration and login pages.
              </p>
              {justSynced && (
                <div className="mt-2 flex items-center gap-1.5 inline-flex px-2 py-1 rounded-lg bg-green-500/10 border border-green-500/20 text-green-700 text-[10px] font-mono font-bold">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-ping" />
                  <span>Successfully Synchronized (Local UTC Registry: {lastSyncedTime})</span>
                </div>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={handleManualRefreshVendors}
            className="px-3.5 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold text-[10px] uppercase tracking-wider rounded-xl transition flex items-center gap-1.5 cursor-pointer self-start sm:self-center"
          >
            <span>🔄 Sync & Refresh Grid</span>
          </button>
        </div>

        {/* List of currently active vendor agents */}
        <div className="space-y-4">
          <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest block text-left">
            Active Verified Token Vendor Agents List ({vendors.length} active)
          </span>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {vendors.map((agent, index) => (
              <div 
                key={`${agent.phone}-${index}`}
                className="p-4 rounded-2xl border border-gray-200/80 bg-gradient-to-b from-white to-gray-50/55 flex flex-col justify-between gap-4 shadow-3xs"
              >
                <div className="space-y-2.5 text-left">
                  <div>
                    <label className="text-[8.5px] font-mono font-bold text-gray-400 uppercase tracking-wider block mb-1">
                      Agent Name / Label
                    </label>
                    <input
                      type="text"
                      value={agent.label}
                      onChange={(e) => handleUpdateVendorField(index, 'label', e.target.value)}
                      className="w-full text-xs font-semibold text-gray-900 p-2 bg-white border border-gray-200 rounded-lg focus:border-green-600 outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[8.5px] font-mono font-bold text-gray-400 uppercase tracking-wider block mb-1">
                      WhatsApp Phone Number (Internal)
                    </label>
                    <input
                      type="text"
                      value={agent.phone}
                      onChange={(e) => handleUpdateVendorField(index, 'phone', e.target.value.replace(/\D/g, ''))}
                      className="w-full text-xs font-mono text-gray-850 p-2 bg-white border border-gray-200 rounded-lg focus:border-green-600 outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[8.5px] font-mono font-bold text-gray-400 uppercase tracking-wider block mb-1">
                      Display Format (e.g. +234 80...)
                    </label>
                    <input
                      type="text"
                      value={agent.display}
                      onChange={(e) => handleUpdateVendorField(index, 'display', e.target.value)}
                      className="w-full text-xs font-mono text-gray-850 p-2 bg-white border border-gray-200 rounded-lg focus:border-green-600 outline-none"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-gray-100 pt-3">
                  <span className="text-[10px] font-mono text-slate-400">Agent {index + 1}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveVendor(index)}
                    className="text-gray-450 hover:text-red-650 text-[10px] font-bold font-mono uppercase tracking-wider transition cursor-pointer"
                  >
                    Remove Agent
                  </button>
                </div>
              </div>
            ))}
          </div>

          {vendors.length === 0 && (
            <div className="p-8 text-center bg-gray-50 rounded-2xl border border-dashed border-gray-200 text-gray-405 text-xs font-medium max-w-md mx-auto">
              No registered vendor agents. Create a new vendor distributor using the form below to show them on the login template.
            </div>
          )}

          {vendors.length > 0 && (
            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={handleSaveAllVendors}
                className="inline-flex items-center gap-1.5 bg-green-600 hover:bg-green-700 text-white font-mono font-bold text-[10px] uppercase tracking-wider px-4 py-2.5 rounded-xl transition cursor-pointer shadow-xs leading-none"
              >
                <Save className="h-3.5 w-3.5" />
                <span>Save All Vendor Updates</span>
              </button>
            </div>
          )}
        </div>

        {/* Add Vendor distributor Form */}
        <div className="border-t border-gray-100 pt-5 space-y-4">
          <h4 className="text-xs font-bold text-gray-900 font-sans uppercase tracking-wider flex items-center gap-2 text-left">
            <Plus className="h-4 w-4 text-green-600" />
            <span>Register & Add Vendor Agent</span>
          </h4>

          <form onSubmit={handleAddVendor} className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
            <div className="space-y-1">
              <label className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block font-sans">
                Agent Name / Label
              </label>
              <input
                type="text"
                placeholder="e.g. Master Vendor Agent 4"
                value={newVendorLabel}
                onChange={(e) => setNewVendorLabel(e.target.value)}
                className="w-full text-xs rounded-lg border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-green-500/10 text-gray-850 bg-white"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block">
                WhatsApp Phone Number
              </label>
              <input
                type="text"
                placeholder="digits, e.g. 2348063823716"
                value={newVendorPhone}
                onChange={(e) => setNewVendorPhone(e.target.value)}
                className="w-full text-xs font-mono rounded-lg border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-green-500/10 text-gray-850 bg-white"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-mono font-bold text-gray-400 uppercase tracking-widest block font-sans">
                Display Format
              </label>
              <input
                type="text"
                placeholder="e.g. +234 806 382 3716"
                value={newVendorDisplay}
                onChange={(e) => setNewVendorDisplay(e.target.value)}
                className="w-full text-xs rounded-lg border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-green-500/10 text-gray-850 bg-white"
              />
            </div>

            <div className="sm:col-span-3 flex justify-end">
              <button
                type="submit"
                className="w-full sm:w-auto px-5 py-2.5 bg-gray-950 hover:bg-gray-850 text-white font-bold text-[10px] uppercase tracking-wider rounded-xl transition cursor-pointer"
              >
                + Register Agent
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* 7. Admin Settings: Official Channel Connection */}
      <div className="bg-white rounded-3xl border border-gray-200 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 bg-amber-50 rounded-xl border border-amber-100 flex items-center justify-center text-amber-700">
              <BellRing className="h-5 w-5" />
            </div>
            <div className="text-left">
              <h3 className="font-bold text-sm uppercase tracking-wide text-gray-900 font-display flex items-center gap-2">
                Official Channel Connection
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[9px] bg-amber-100 text-amber-800 font-mono font-black uppercase tracking-wide">
                  Admin System
                </span>
              </h3>
              <p className="text-[11px] text-gray-500 font-sans leading-none mt-1">
                Configure the default social announcement broadcast or community channel links shown prominently on member dashboards, support pages, and invitation templates.
              </p>
            </div>
          </div>

          <div className="flex gap-2 self-start sm:self-center">
            <a 
              href={officialChannelLink}
              target="_blank"
              rel="noreferrer"
              className="bg-amber-50 text-amber-700 hover:bg-amber-100 text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1.5 rounded-xl flex items-center gap-1 transition animate-pulse"
            >
              <span>Telegram 🚀</span>
            </a>
            <a 
              href={officialWhatsappLink}
              target="_blank"
              rel="noreferrer"
              className="bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-[10px] font-mono font-bold uppercase tracking-wider px-2.5 py-1.5 rounded-xl flex items-center gap-1 transition"
            >
              <span>WhatsApp 💬</span>
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
          {/* Telegram Channel Option */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider font-sans">
              Telegram Announcement Link
            </label>
            <div className="flex gap-2">
              <input
                type="url"
                placeholder="e.g. https://t.me/+your_channel_invite"
                value={tempChannelLink}
                onChange={(e) => setTempChannelLink(e.target.value)}
                className="flex-1 text-sm rounded-xl border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-600 transition font-mono bg-white text-gray-900"
              />
              <button
                type="button"
                onClick={handleUpdateChannelLink}
                className="px-4 py-2 bg-gray-950 text-white hover:bg-gray-850 rounded-xl text-xs font-bold uppercase tracking-wider transition cursor-pointer shrink-0"
              >
                Update
              </button>
            </div>
            <p className="text-[10px] text-gray-400 font-mono">
              Current Telegram endpoint: <span className="text-amber-700 select-all font-semibold">{officialChannelLink}</span>
            </p>
          </div>

          {/* WhatsApp Community Option */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider font-sans">
              WhatsApp Community/Group Link
            </label>
            <div className="flex gap-2">
              <input
                type="url"
                placeholder="e.g. https://chat.whatsapp.com/your_invite_code"
                value={tempWhatsappLink}
                onChange={(e) => setTempWhatsappLink(e.target.value)}
                className="flex-1 text-sm rounded-xl border border-gray-200 p-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 transition font-mono bg-white text-gray-900"
              />
              <button
                type="button"
                onClick={handleUpdateWhatsappLink}
                className="px-4 py-2 bg-gray-950 text-white hover:bg-gray-850 rounded-xl text-xs font-bold uppercase tracking-wider transition cursor-pointer shrink-0"
              >
                Update
              </button>
            </div>
            <p className="text-[10px] text-gray-400 font-mono">
              Current WhatsApp endpoint: <span className="text-emerald-700 select-all font-semibold">{officialWhatsappLink}</span>
            </p>
          </div>
        </div>
      </div>

      {/* FORM MODAL FOR SUBMITTING BUSINESS CAMPAIGN */}
      {showAddForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white border border-gray-200 rounded-3xl shadow-2xl overflow-hidden my-8 animate-scale-in">
            
            {/* Header decoration */}
            <div className="bg-gray-950 px-6 py-4 flex items-center justify-between text-white">
              <div className="flex items-center gap-2">
                <Plus className="h-5 w-5 text-green-400" />
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider font-display">New Promotion Campaign</h3>
                  <p className="text-[10px] text-gray-400 font-mono">DRAFT BUSINESS REGISTRY</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="p-1 px-1.5 bg-gray-900 border border-gray-800 text-gray-450 hover:text-white rounded-lg transition cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Content Form */}
            <form onSubmit={handleCreateCampaign} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              
              {formError && (
                <div className="p-3.5 rounded-xl bg-red-50 border border-red-150 text-red-700 text-xs font-medium space-y-1">
                  <div className="flex items-center gap-1.5 font-bold font-mono">
                    <AlertCircle className="h-4 w-4 shrink-0" />
                    <span>VERIFICATION REJECTED:</span>
                  </div>
                  <p className="text-[11px] leading-relaxed select-none">{formError}</p>
                </div>
              )}

              {/* 1. Business Name */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                  1. Business or Campaign Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Luxe Wear Boutique Boutique"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  className="w-full text-xs font-sans p-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-green-600 focus:bg-white outline-none transition"
                />
              </div>

              {/* 2. Platform Category selection */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-450 text-gray-400 uppercase tracking-widest font-mono block">
                  2. Select Channels Category
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {(['WhatsApp', 'Instagram', 'Telegram', 'YouTube', 'Facebook', 'TikTok', 'Website', 'Other'] as const).map((plat) => {
                    const activeP = category === plat;
                    return (
                      <button
                        key={plat}
                        type="button"
                        onClick={() => setCategory(plat)}
                        className={`py-2 px-1 rounded-lg border text-center font-mono text-[9.5px] uppercase transition cursor-pointer ${
                          activeP 
                            ? 'bg-green-600 border-green-600 text-white font-bold' 
                            : 'bg-gray-50 border-gray-200 text-gray-500 hover:border-gray-300'
                        }`}
                      >
                        {plat}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 3. Action URL */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                  3. Target Business URL (Redirect Link)
                </label>
                <input
                  type="url"
                  required
                  placeholder={category === 'WhatsApp' ? "https://chat.whatsapp.com/..." : "https://instagram.com/..."}
                  value={actionUrl}
                  onChange={(e) => setActionUrl(e.target.value)}
                  className="w-full text-xs font-mono p-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-green-600 focus:bg-white outline-none transition"
                />
              </div>

              {/* 4. Target Action */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                  4. Exact User Action Required
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Join group & stay active for payouts"
                  value={targetAction}
                  onChange={(e) => setTargetAction(e.target.value)}
                  className="w-full text-xs font-sans p-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-green-600 focus:bg-white outline-none transition"
                />
              </div>

              {/* 5. Budget sliders / Pricing */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                    5. Pay-per-Task (₦)
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400 text-xs font-bold font-mono">₦</span>
                    <input
                      type="number"
                      required
                      min={10}
                      step={5}
                      value={rewardPerTask}
                      onChange={(e) => setRewardPerTask(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full text-xs font-mono p-3 pl-7 bg-gray-50 border border-gray-200 rounded-xl focus:border-green-600 focus:bg-white outline-none transition"
                    />
                  </div>
                  <span className="text-[9px] text-gray-400 font-mono">Min: ₦10 per action</span>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                    6. Target Participants
                  </label>
                  <input
                    type="number"
                    required
                    min={10}
                    step={10}
                    value={totalTasksRequired}
                    onChange={(e) => setTotalTasksRequired(Math.max(1, parseInt(e.target.value) || 0))}
                    className="w-full text-xs font-mono p-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-green-600 focus:bg-white outline-none transition"
                  />
                  <span className="text-[9px] text-gray-400 font-mono">Min: 10 people</span>
                </div>
              </div>

              {/* 6. Campaign Instructions */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-mono block">
                  7. Proof Instructions for Performers
                </label>
                <textarea
                  placeholder="e.g. Please join and upload screenshot showing your phone screen inside the group chat."
                  value={instructions}
                  rows={2}
                  onChange={(e) => setInstructions(e.target.value)}
                  className="w-full text-xs font-sans p-3 bg-gray-50 border border-gray-200 rounded-xl focus:border-green-600 focus:bg-white outline-none transition"
                />
              </div>

              {/* DEMO BYPASS BOX */}
              <div className="p-3 bg-neutral-50 border border-neutral-200 rounded-xl flex items-start gap-2.5">
                <input
                  type="checkbox"
                  id="demo-campaign-toggle"
                  checked={isDemoCampaign}
                  onChange={(e) => setIsDemoCampaign(e.target.checked)}
                  className="mt-1 cursor-pointer h-3.5 w-3.5 rounded border-gray-300 text-green-600 focus:ring-green-500"
                />
                <div className="text-left">
                  <label htmlFor="demo-campaign-toggle" className="text-[10px] font-black text-neutral-800 uppercase font-mono tracking-wider cursor-pointer block select-none">
                    Apply Promotional Voucher
                  </label>
                  <p className="text-[10px] text-neutral-500 leading-snug">
                    Running low on campaign wallet balance? Bypass standard Naira deductions and launch a fully functional media campaign instantly using your welcome promotion voucher.
                  </p>
                </div>
              </div>

              {/* Live Cost Calculation summary */}
              <div className="p-3 bg-gray-950 text-white rounded-xl flex items-center justify-between font-mono text-[10px] tracking-wide uppercase">
                <div className="flex items-center gap-1.5">
                  <DollarSign className="h-3.5 w-3.5 text-green-400" />
                  <span>Gross Campaign cost:</span>
                </div>
                <strong className={`text-xs ${isDemoCampaign ? 'line-through text-slate-450' : 'text-green-400 font-extrabold'}`}>
                  {formatNaira(calculatedCost)}
                </strong>
                {isDemoCampaign && (
                  <span className="text-[9.5px] text-emerald-400 font-black animate-pulse">₦0.00 (Demo Gift)</span>
                )}
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 py-3 bg-gray-50 hover:bg-gray-105 border border-gray-205 text-gray-700 font-bold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer text-center"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-green-600 hover:bg-green-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer text-center shadow-md active:scale-[0.98]"
                >
                  Publish Campaign
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
