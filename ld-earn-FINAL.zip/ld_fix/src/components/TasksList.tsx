/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { SocialTask, EarningActivity } from '../types';
import { formatNaira, PLANS, normalizePlan } from '../utils';
import { 
  CheckCircle, 
  ArrowUpRight, 
  Twitter, 
  Youtube, 
  Instagram, 
  Send, 
  Smartphone,
  Facebook,
  Sparkles,
  UploadCloud,
  Trash2,
  Loader2,
  Eye,
  X,
  ZoomIn,
  Clock,
  Timer,
  Flame,
  AlertTriangle
} from 'lucide-react';
import { motion } from 'motion/react';

interface TasksListProps {
  tasks: SocialTask[];
  onCompleteTask: (taskId: string, verificationProof: string, base64Image?: string) => Promise<void>;
  profileLevel: string;
  activities?: EarningActivity[];
}

// Highly optimized, zero-dependency canvas particle physics simulator
function LocalConfetti({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!active || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = canvas.offsetWidth || 600);
    let height = (canvas.height = canvas.offsetHeight || 350);

    const handleResize = () => {
      if (canvas) {
        width = canvas.width = canvas.offsetWidth || 600;
        height = canvas.height = canvas.offsetHeight || 350;
      }
    };
    window.addEventListener('resize', handleResize);

    const emojis = ['💰', '🎉', '⭐', '✨', '💸', '🇳🇬', '👍'];
    const colors = ['#f5af19', '#22c55e', '#3b82f6', '#ec4899', '#a855f7', '#f97316', '#10b981'];

    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      size: number;
      color: string;
      emoji: string | null;
      rotation: number;
      rotationSpeed: number;
      opacity: number;
      gravity: number;
      friction: number;
    }

    const particles: Particle[] = [];

    // Shoot 120 particles upwards from the button/bottom center
    for (let i = 0; i < 120; i++) {
      const isEmoji = Math.random() < 0.4;
      particles.push({
        x: width / 2,
        y: height - 50,
        vx: (Math.random() - 0.5) * 16,
        vy: -Math.random() * 14 - 10, // Shoot upwards with energy
        size: isEmoji ? Math.random() * 12 + 16 : Math.random() * 6 + 7,
        color: colors[Math.floor(Math.random() * colors.length)],
        emoji: isEmoji ? emojis[Math.floor(Math.random() * emojis.length)] : null,
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 12,
        opacity: 1,
        gravity: 0.38,
        friction: 0.985
      });
    }

    let animationFrameId: number;

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      let alive = 0;

      particles.forEach((p) => {
        if (p.opacity <= 0) return;
        alive++;

        p.vx *= p.friction;
        p.vy *= p.friction;
        p.vy += p.gravity;
        p.x += p.vx;
        p.y += p.vy;
        p.rotation += p.rotationSpeed;

        if (p.vy > -2) {
          p.opacity -= 0.009; // Fade out slowly as they reach apex
        }

        ctx.save();
        ctx.globalAlpha = Math.max(0, p.opacity);
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);

        if (p.emoji) {
          ctx.font = `${p.size}px Arial, Apple Color Emoji, Segoe UI Emoji`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(p.emoji, 0, 0);
        } else {
          // Colorful shapes
          ctx.fillStyle = p.color;
          ctx.beginPath();
          if (p.size % 2 === 0) {
            ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
          } else {
            ctx.arc(0, 0, p.size / 2, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        ctx.restore();
      });

      if (alive > 0) {
        animationFrameId = requestAnimationFrame(animate);
      }
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [active]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-50 rounded-3xl"
    />
  );
}

interface TimelineStep {
  label: string;
  sub: string;
  status: 'upcoming' | 'current' | 'completed' | 'failed';
  icon: any;
  colorClass: string;
}

export function VerificationTimeline({ 
  taskStatus, 
  submittedAt, 
  rejectionReason 
}: { 
  taskStatus: 'Available' | 'Verifying' | 'Completed';
  submittedAt?: string;
  rejectionReason?: string;
}) {
  let step1Status: 'upcoming' | 'completed' = 'upcoming';
  let step2Status: 'upcoming' | 'current' | 'completed' = 'upcoming';
  let step3Status: 'upcoming' | 'completed' | 'failed' = 'upcoming';
  
  if (rejectionReason) {
    step1Status = 'completed';
    step2Status = 'completed';
    step3Status = 'failed';
  } else if (taskStatus === 'Verifying') {
    step1Status = 'completed';
    step2Status = 'current';
    step3Status = 'upcoming';
  } else if (taskStatus === 'Completed') {
    step1Status = 'completed';
    step2Status = 'completed';
    step3Status = 'completed';
  }

  const steps: TimelineStep[] = [
    {
      label: 'Submitted',
      sub: submittedAt ? `At: ${submittedAt}` : 'Proof uploaded to system',
      status: step1Status,
      icon: CheckCircle,
      colorClass: 'text-emerald-600 bg-emerald-50 border-emerald-200'
    },
    {
      label: 'Under Review',
      sub: step2Status === 'current' 
        ? 'Awaiting validation' 
        : step2Status === 'completed' 
        ? 'Verified' 
        : 'Pending audit checks',
      status: step2Status,
      icon: Clock,
      colorClass: step2Status === 'current' 
        ? 'text-indigo-600 bg-indigo-50 border-indigo-200 animate-pulse'
        : step2Status === 'completed'
        ? 'text-emerald-600 bg-emerald-50 border-emerald-200'
        : 'text-slate-400 bg-slate-50 border-slate-200'
    },
    {
      label: rejectionReason ? 'Rejected' : 'Approved',
      sub: rejectionReason 
        ? rejectionReason 
        : step3Status === 'completed' 
        ? 'Naira credited successfully' 
        : 'Reward payout process',
      status: step3Status,
      icon: rejectionReason ? X : Sparkles,
      colorClass: step3Status === 'completed'
        ? 'text-emerald-600 bg-emerald-50 border-emerald-200'
        : step3Status === 'failed'
        ? 'text-red-600 bg-red-50 border-red-200'
        : 'text-slate-400 bg-slate-50 border-slate-200'
    }
  ];

  return (
    <div className="bg-slate-50/50 border border-slate-150 rounded-2xl p-4 sm:p-5 text-left select-none">
      <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-3.5">
        <h6 className="text-[9px] font-black font-mono text-slate-400 uppercase tracking-widest">
          Verification Stage Timeline
        </h6>
        <span className="text-[9px] bg-slate-200 text-slate-600 font-mono font-extrabold px-2 py-0.5 rounded-full uppercase">
          {taskStatus === 'Completed' ? 'CLEARED' : taskStatus === 'Verifying' ? 'Reviewing' : 'Declining'}
        </span>
      </div>
      
      {/* Horizontal / Vertical layout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4.5 relative">
        {steps.map((step, idx) => {
          const isFinished = step.status === 'completed';
          const isOngoing = step.status === 'current';
          const isFailed = step.status === 'failed';
          
          return (
            <div key={idx} className="flex md:flex-col items-start gap-2.5 relative z-10 text-left">
              {/* Connector line for large screens */}
              {idx < steps.length - 1 && (
                <div className="hidden md:block absolute top-[13px] left-[34px] right-0 h-[2px] bg-slate-200 -z-10">
                  <div 
                    className={`h-full transition-all duration-500 ${
                      isFinished ? 'bg-emerald-550 w-full' : 'bg-slate-200 w-0'
                    }`} 
                  />
                </div>
              )}

              {/* Icon Bubble */}
              <div className={`h-7 w-7 shrink-0 rounded-full flex items-center justify-center border transition-all duration-300 ${
                isFinished ? 'bg-green-500 border-green-600 text-white shadow-3xs' :
                isOngoing ? 'bg-indigo-50 border-indigo-400 text-indigo-600 ring-2 ring-indigo-100 animate-pulse' :
                isFailed ? 'bg-red-550 border-red-650 text-white ring-2 ring-red-100 shadow-3xs' :
                'bg-slate-100 border-slate-200 text-slate-400'
              }`}>
                {isFinished ? (
                  <CheckCircle className="h-4 w-4" />
                ) : isOngoing ? (
                  <Clock className="h-4 w-4 animate-spin" style={{ animationDuration: '4s' }} />
                ) : isFailed ? (
                  <X className="h-4 w-4" />
                ) : (
                  <step.icon className="h-4 w-4" />
                )}
              </div>

              {/* Text content */}
              <div className="space-y-0.5">
                <div className="flex items-center gap-1 flex-wrap">
                  <h6 className={`text-[10.5px] font-extrabold uppercase tracking-wider ${
                    isFinished ? 'text-green-800' :
                    isOngoing ? 'text-indigo-900 font-bold animate-pulse' :
                    isFailed ? 'text-red-700' : 'text-slate-400'
                  }`}>
                    {step.label}
                  </h6>
                </div>
                <p className={`text-[9.5px] leading-relaxed max-w-[190px] font-mono ${
                  isFinished ? 'text-green-605 text-green-700' :
                  isOngoing ? 'text-indigo-705 text-indigo-700' :
                  isFailed ? 'text-red-700 font-medium' : 'text-slate-400'
                }`}>
                  {step.sub}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function TasksList({ tasks, onCompleteTask, profileLevel, activities = [] }: TasksListProps) {
  // Find the first available task, or first verifying task, or fallback to the most recent task (first in tasks array)
  const primaryTask = tasks.find(t => t.status === 'Available') || 
                      tasks.find(t => t.status === 'Verifying') || 
                      tasks[0];

  const activePlan = normalizePlan(profileLevel);
  const currentRewardAmount = PLANS[activePlan].dailyTaskPaid;

  const isCompleted = primaryTask?.status === 'Completed';

  // Find most recent failed task activity if any
  const lastFailedActivity = activities.find(act => act.type === 'Task' && act.status === 'Failed');
  const rejectionReason = lastFailedActivity?.details?.replace('Rejected by Admin. Reason: ', '') || undefined;
  const rejectedTimestamp = lastFailedActivity?.timestamp;

  // State to trigger confetti explosion
  const [triggerConfetti, setTriggerConfetti] = useState(false);
  const prevCompletedRef = useRef(isCompleted);

  // Screenshot upload states
  const [hasOpenedLink, setHasOpenedLink] = useState(false);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [screenshotFileName, setScreenshotFileName] = useState<string>('');
  const [verificationHandle, setVerificationHandle] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionStatus, setSubmissionStatus] = useState('');
  const [submitError, setSubmitError] = useState('');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  // Daily Reset Countdown State (Midnight local time reset)
  const [timeLeft, setTimeLeft] = useState({ hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date();
      // Target is today's midnight (11:59:59 PM)
      const targetMidnight = new Date();
      targetMidnight.setHours(23, 59, 59, 999);
      
      const diff = targetMidnight.getTime() - now.getTime();
      if (diff <= 0) {
        return { hours: 0, minutes: 0, seconds: 0 };
      }
      
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const seconds = Math.floor((diff / 1000) % 60);
      
      return { hours, minutes, seconds };
    };

    // Calculate immediately
    setTimeLeft(calculateTimeLeft());

    const intervalId = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(intervalId);
  }, []);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // File loading and validation
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setSubmitError('Invalid file type! Please upload an image file as proof.');
        return;
      }
      setSubmitError('');
      setScreenshotFileName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setSubmitError('Invalid file type! Please upload an image file as proof.');
        return;
      }
      setSubmitError('');
      setScreenshotFileName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  const clearScreenshot = (e: React.MouseEvent) => {
    e.stopPropagation();
    setScreenshotPreview(null);
    setScreenshotFileName('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmitVerification = async () => {
    if (!screenshotPreview) {
      setSubmitError('Please upload a screenshot proof of the completed action.');
      return;
    }
    setSubmitError('');
    setIsSubmitting(true);
    
    // Multi-phase scanner delay effects for high platform fidelity
    setSubmissionStatus('Scanning Image Compliance...');
    await new Promise(resolve => setTimeout(resolve, 800));
    
    setSubmissionStatus('Verifying Account Handle...');
    await new Promise(resolve => setTimeout(resolve, 700));
    
    setSubmissionStatus('Executing ledger payout update...');
    await new Promise(resolve => setTimeout(resolve, 500));

    try {
      const proofStr = `Uploaded: ${screenshotFileName}` + (verificationHandle ? ` | Handle: ${verificationHandle}` : '');
      await onCompleteTask(primaryTask.id, proofStr, screenshotPreview || undefined);
    } catch (err: any) {
      setSubmitError(err.message || 'Verification system failed. Please retry.');
    } finally {
      setIsSubmitting(false);
      setSubmissionStatus('');
    }
  };

  useEffect(() => {
    if (isCompleted && !prevCompletedRef.current) {
      setTriggerConfetti(true);
      const timer = setTimeout(() => {
        setTriggerConfetti(false);
      }, 5000);
      return () => clearTimeout(timer);
    }
    prevCompletedRef.current = isCompleted;
  }, [isCompleted]);

  // Platform specific icon picker
  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'Twitter':
        return <Twitter className="h-6 w-6 text-sky-500 font-bold" />;
      case 'YouTube':
        return <Youtube className="h-6 w-6 text-red-600 font-bold" />;
      case 'Instagram':
        return <Instagram className="h-6 w-6 text-pink-600" />;
      case 'Telegram':
        return <Send className="h-6 w-6 text-sky-400" />;
      case 'Facebook':
        return <Facebook className="h-6 w-6 text-blue-600" />;
      default:
        return <Smartphone className="h-6 w-6 text-green-600" />;
    }
  };

  if (!primaryTask) {
    return (
      <div className="max-w-md mx-auto py-12 text-center space-y-4 select-none">
        <div className="h-16 w-16 bg-gray-50 border border-gray-100 rounded-full flex items-center justify-center text-gray-400 mx-auto">
          <CheckCircle className="h-8 w-8" />
        </div>
        <h3 className="text-xl font-bold text-gray-950 font-display">All Finished for Today!</h3>
        <p className="text-xs text-gray-500 max-w-xs mx-auto leading-relaxed">
          You've completed your active daily task campaign list. Check back tomorrow for high-paying sponsored requests!
        </p>
      </div>
    );
  }

  if (primaryTask.status === 'Expired') {
    return (
      <div className="max-w-md mx-auto py-12 text-center space-y-4 select-none animate-fade-in">
        <div className="h-16 w-16 bg-red-50 border border-red-100 rounded-full flex items-center justify-center text-red-500 mx-auto animate-bounce" style={{ animationDuration: '3s' }}>
          <AlertTriangle className="h-8 w-8" />
        </div>
        <h3 className="text-xl font-bold text-gray-950 font-display">⚠️ Daily Task Expired!</h3>
        <p className="text-xs text-gray-400 font-mono tracking-wider uppercase">Commission: ₦{primaryTask.reward.toLocaleString()}</p>
        <p className="text-sm font-semibold text-neutral-800">{primaryTask.title}</p>
        <p className="text-xs text-gray-500 max-w-xs mx-auto leading-relaxed">
          This daily campaign action has expired because it was not completed within the strict 24-hour urgency window.
        </p>
        <div className="p-3.5 bg-amber-50/70 border border-amber-100/80 rounded-2xl text-[11px] text-amber-800 text-left space-y-1 max-w-xs mx-auto">
          <span className="font-bold block">Why did this happen?</span>
          To maintain high sponsor conversion rates, all active social microtasks must be completed within 24 hours of release. Please check back when the administrator launches the next active portal task!
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in max-w-4xl mx-auto">
      
      {/* Intro Header */}
      <div className="text-center max-w-2xl mx-auto select-none">
        <span className="font-mono text-[9px] tracking-widest text-[#f5af19] bg-[#f5af19]/10 border border-[#f5af19]/25 px-3 py-1 rounded-full uppercase font-black inline-flex items-center gap-1">
          <Sparkles className="h-3 w-3 text-[#f5af19] animate-pulse" />
          ACTIVE DAILY TASK
        </span>
        <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-gray-950 font-display">
          Daily Social Revenue Portal
        </h2>
        <p className="mt-2 text-sm text-gray-500 font-sans leading-relaxed">
          Perform today's premium featured campaign action below, verify completion, and claim your verified cash reward instantly.
        </p>
      </div>

      <div className="max-w-2xl mx-auto relative">
        
        {/* Confetti element overlay */}
        {triggerConfetti && <LocalConfetti active={triggerConfetti} />}

        {/* Focused Single Task Visual Card */}
        <div className="bg-white rounded-3xl border border-gray-150 p-6 sm:p-8 shadow-sm flex flex-col justify-between relative overflow-hidden transition-all duration-300">
          
          {/* Top category background watermarks */}
          <div className="absolute right-[-20px] top-[-20px] opacity-[0.03] pointer-events-none">
            {getPlatformIcon(primaryTask.platform)}
          </div>

          <div className="space-y-6">
            {/* Header row */}
            <div className="flex items-center justify-between border-b border-gray-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-gray-50 rounded-2xl border border-gray-100">
                  {getPlatformIcon(primaryTask.platform)}
                </div>
                <div>
                  <span className="text-[10px] uppercase tracking-widest font-mono font-bold text-gray-400">
                    Platform Campaign
                  </span>
                  <h3 className="text-xs font-black text-gray-950 font-mono tracking-tight uppercase">
                    {primaryTask.platform} {primaryTask.category}
                  </h3>
                </div>
              </div>

              <div className="text-right">
                <span className="block text-[8px] font-mono text-gray-400 font-black uppercase tracking-wider mb-0.5">PAYOUT COMMISSION</span>
                <span className="font-mono text-base font-black text-green-700 bg-green-50 border border-green-100 px-3 py-1 rounded-xl">
                  +{formatNaira(currentRewardAmount)}
                </span>
              </div>
            </div>

            {/* Live Expiration Countdown Urgency Banner */}
            {!isCompleted && (
              <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 select-none">
                <div className="flex items-center gap-2.5 text-left">
                  <div className="p-2 bg-amber-500/10 rounded-xl text-amber-600 border border-amber-200/50">
                    <Flame className="h-5 w-5 text-amber-600 fill-amber-500 animate-bounce" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-amber-950 font-display uppercase tracking-wide">
                      EXPIRING SOON
                    </h4>
                    <p className="text-[10px] text-amber-700/95 font-medium leading-normal">
                      Submit today's task before midnight to claim payout
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 bg-amber-950 text-white px-3.5 py-1.5 rounded-xl border border-amber-800 shadow-3xs font-mono w-full sm:w-auto justify-center">
                  <Timer className="h-4 w-4 text-[#f5af19] animate-spin" style={{ animationDuration: '4s' }} />
                  <span className="text-xs font-bold tracking-widest text-[#f5af19]">
                    {String(timeLeft.hours).padStart(2, '0')}H : {String(timeLeft.minutes).padStart(2, '0')}M : {String(timeLeft.seconds).padStart(2, '0')}S
                  </span>
                </div>
              </div>
            )}

            {/* If there was a recent rejection and they are currently Available to submit again */}
            {primaryTask?.status === 'Available' && lastFailedActivity && (
              <div className="bg-red-50/40 border border-red-150 rounded-2xl p-4.5 space-y-4 text-left">
                <div className="flex items-start gap-2.5">
                  <div className="p-1.5 bg-red-100 rounded-lg text-red-650 border border-red-200 shrink-0">
                    <AlertTriangle className="h-4 w-4" />
                  </div>
                  <div className="space-y-1">
                    <h5 className="text-[11px] font-extrabold text-red-950 uppercase tracking-wider">
                      Previous Task Proof Declined
                    </h5>
                    <p className="text-[11px] text-red-700 leading-normal font-sans">
                      Your prior submission was reviewed and declined by the controller. Review the timeline below, correct the issue, and resubmit perfect screenshots to secure pay.
                    </p>
                  </div>
                </div>

                <VerificationTimeline 
                  taskStatus="Available" 
                  submittedAt={rejectedTimestamp} 
                  rejectionReason={rejectionReason || 'Uploaded screenshot or parameters were incomplete.'} 
                />
              </div>
            )}

            {/* Task main parameters */}
            <div className="space-y-3">
              <h4 className="text-xl font-extrabold text-gray-950 font-display leading-snug">
                {primaryTask.title}
              </h4>
              <div className="p-4.5 bg-gray-50 border border-gray-100 rounded-2xl text-xs text-gray-600 leading-relaxed font-sans space-y-2">
                <span className="font-bold text-gray-800 uppercase tracking-wide text-[10px] block">CRITICAL INSTRUCTIONS:</span>
                <p className="text-gray-600 font-medium">{primaryTask.instruction}</p>
              </div>
            </div>

            {/* If completed, show verification status or submit flow */}
            {primaryTask?.status === 'Completed' ? (
               <motion.div 
                 initial={{ scale: 0.85, opacity: 0 }}
                 animate={{ 
                   scale: [0.85, 1.08, 0.98, 1],
                   opacity: 1
                 }}
                 transition={{ 
                   duration: 0.6,
                   ease: [0.34, 1.56, 0.64, 1]
                 }}
                 className="bg-green-50/60 border border-green-150 rounded-2xl p-6 sm:p-8 text-center space-y-5 relative overflow-hidden"
               >
                 {/* Glowing aesthetic sparkles */}
                 <div className="absolute top-3 left-3 text-amber-500 animate-pulse opacity-80 pointer-events-none">
                   <Sparkles className="h-4 w-4" />
                 </div>
                 <div className="absolute bottom-3 right-3 text-amber-500 animate-pulse opacity-80 pointer-events-none">
                   <Sparkles className="h-4 w-4" />
                 </div>
 
                 <motion.div 
                   initial={{ scale: 0 }}
                   animate={{ scale: 1 }}
                   transition={{ delay: 0.15, type: 'spring', stiffness: 260, damping: 15 }}
                   className="h-14 w-14 bg-gradient-to-tr from-green-600 to-emerald-400 text-white rounded-full flex items-center justify-center mx-auto shadow-md border-2 border-white"
                 >
                   <CheckCircle className="h-7 w-7" />
                 </motion.div>
                 
                 <h5 className="text-base font-black text-green-950 font-display">Task Verification Successful!</h5>
                 <p className="text-xs text-green-700 max-w-sm mx-auto font-sans leading-relaxed">
                   LD automated audit checks have validated your subscription. Your ledger has been credited with <strong className="font-bold text-green-800">{formatNaira(currentRewardAmount)}</strong>.
                 </p>
 
                 <div className="pt-1 flex justify-center gap-1.5 pointer-events-none">
                   <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-green-100 text-green-800 uppercase border border-green-200">
                     Audit Verified
                   </span>
                   <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-green-100 text-green-800 uppercase border border-green-200">
                     Instantly Paid
                   </span>
                 </div>

                 <VerificationTimeline 
                   taskStatus="Completed" 
                   submittedAt={primaryTask.submittedAt || "Just now"} 
                 />
               </motion.div>
             ) : primaryTask?.status === 'Verifying' ? (
               <motion.div 
                 initial={{ scale: 0.85, opacity: 0 }}
                 animate={{ scale: 1, opacity: 1 }}
                 transition={{ duration: 0.4 }}
                 className="bg-indigo-50/60 border border-indigo-150 rounded-2xl p-6 sm:p-8 text-center space-y-5 relative overflow-hidden text-left"
               >
                 <div className="absolute top-3 left-3 text-indigo-500 animate-pulse opacity-80 pointer-events-none">
                   <Clock className="h-4 w-4 animate-spin" style={{ animationDuration: '6s' }} />
                 </div>
                 <div className="absolute bottom-3 right-3 text-indigo-500 animate-pulse opacity-80 pointer-events-none">
                   <Clock className="h-4 w-4" />
                 </div>
 
                 <div 
                   className="h-14 w-14 bg-gradient-to-tr from-indigo-500 to-indigo-400 text-white rounded-full flex items-center justify-center mx-auto shadow-md border-2 border-white animate-pulse"
                 >
                   <Clock className="h-7 w-7" />
                 </div>
                 
                 <h5 className="text-base font-black text-indigo-950 font-display text-center">Under Admin Review</h5>

                 {/* Animated Visual Progress Bar for Verifying Status */}
                 <div className="max-w-md mx-auto w-full space-y-2.5 my-4 p-4 bg-indigo-50/40 border border-indigo-200/55 rounded-2xl shadow-3xs select-none">
                   <div className="flex justify-between items-center text-[10.5px] font-mono text-indigo-800 font-black uppercase tracking-wide">
                     <span className="flex items-center gap-1.5">
                       <span className="h-2 w-2 rounded-full bg-indigo-600 animate-ping" />
                       <span>Verification Phase</span>
                     </span>
                     <span className="flex items-center gap-1 font-bold text-indigo-650">
                       <span className="animate-pulse">Analyzing Proof...</span>
                       <span className="bg-indigo-100 px-1.5 py-0.5 rounded-md">65%</span>
                     </span>
                   </div>
                   <div className="h-3 w-full bg-slate-200/60 rounded-full overflow-hidden border border-slate-300/40 relative">
                     {/* Animated Shimmer Progress Bar */}
                     <motion.div 
                       initial={{ width: "0%" }}
                       animate={{ width: "65%" }}
                       transition={{ duration: 1.8, ease: "easeOut" }}
                       className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600 rounded-full relative overflow-hidden"
                     >
                       {/* Continuous sliding highlight shimmer */}
                       <motion.div
                         animate={{ x: ["-100%", "200%"] }}
                         transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                         className="absolute inset-0 bg-gradient-to-r from-transparent via-white/35 to-transparent w-full h-full"
                       />
                     </motion.div>
                   </div>
                   <p className="text-[9.5px] text-indigo-500/90 font-mono text-center leading-relaxed">
                     AI compliance engine scanning files & match details for authenticity checks
                   </p>
                 </div>
                 <p className="text-xs text-indigo-700 max-w-sm mx-auto font-sans leading-relaxed text-center">
                   Your proof of completion (screenshot and social handle) has been securely dispatched to the platform administrator. 
                   Once reviewed and approved, your payout of <strong className="font-bold text-indigo-850">₦{currentRewardAmount.toLocaleString()}</strong> will be credited directly to your balance.
                 </p>
 
                 <div className="bg-white border border-indigo-100 p-4 rounded-2xl mx-auto max-w-md text-left text-xs font-mono text-indigo-900 space-y-1.5 shadow-3xs">
                   <div className="flex justify-between border-b border-slate-100 pb-1.5 mb-1.5">
                     <span className="text-indigo-400 uppercase font-bold text-[10px]">Verification Status:</span>
                     <span className="font-bold text-indigo-700 flex items-center gap-1 uppercase text-[10px]">
                       <span className="h-1.5 w-1.5 rounded-full bg-indigo-600 animate-pulse" />
                       Pending Approval
                     </span>
                   </div>
                   {primaryTask.proofOfWork && (
                     <div className="space-y-1">
                       <span className="text-indigo-400 block uppercase font-bold text-[10px]">Submitted Proof Info:</span>
                       <span className="text-indigo-800 break-words font-sans bg-slate-50 p-2 rounded-lg block border border-slate-100">{primaryTask.proofOfWork}</span>
                     </div>
                   )}
                   {primaryTask.verificationImage && (
                     <div className="pt-2">
                       <span className="text-indigo-400 block uppercase font-bold text-[10px] mb-1">Uploaded Screenshot:</span>
                       <div className="relative aspect-video max-h-[160px] rounded-lg overflow-hidden border border-indigo-100 bg-slate-900">
                         <img 
                           src={primaryTask.verificationImage} 
                           alt="Submitted proof to verify" 
                           referrerPolicy="no-referrer"
                           className="w-full h-full object-contain"
                         />
                       </div>
                     </div>
                   )}
                 </div>
 
                 <div className="pt-2 flex justify-center gap-1.5">
                   <span className="px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold bg-indigo-100 text-indigo-700 uppercase border border-indigo-200">
                     Proof Dispatched
                   </span>
                   <span className="px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold bg-amber-100 text-amber-700 uppercase border border-amber-200">
                     Awaiting Admin Approval
                   </span>
                 </div>

                 <VerificationTimeline 
                   taskStatus="Verifying" 
                   submittedAt={primaryTask.submittedAt || "Just now"} 
                 />
               </motion.div>
             ) : (
              /* If not completed, show functional multi-step screenshot verification flow */
              <div className="space-y-6 pt-2 font-sans text-left">
                {/* Step 1: Open Link Action */}
                <div className="space-y-2">
                  <span className="block text-[10px] font-mono font-bold uppercase text-gray-400 tracking-wider">
                    Step 1: Open and Complete Campaign
                  </span>
                  <motion.div
                    whileHover={{ scale: 1.012 }}
                    whileTap={{ scale: 0.988 }}
                    transition={{ type: "spring", stiffness: 400, damping: 20 }}
                  >
                    <a
                      href={primaryTask.actionUrl}
                      target="_blank"
                      rel="noreferrer"
                      onClick={() => {
                        setHasOpenedLink(true);
                      }}
                      className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-[#e65c00] hover:brightness-110 text-slate-950 text-xs font-black uppercase tracking-wider transition shadow-md hover:shadow-lg cursor-pointer text-center"
                    >
                      <span>Perform Task (Open External Link)</span>
                      <ArrowUpRight className="h-4 w-4" />
                    </a>
                  </motion.div>
                </div>

                {/* Step 2: Upload Evidence Screenshot (Supports drag-and-drop & browse) */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="block text-[10px] font-mono font-bold uppercase text-gray-400 tracking-wider">
                      Step 2: Upload Screenshot Evidence
                    </span>
                    {hasOpenedLink && (
                      <span className="text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-0.5 rounded-full font-bold animate-pulse uppercase tracking-wide">
                        ● Link Opened
                      </span>
                    )}
                  </div>

                  {!screenshotPreview ? (
                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      onClick={triggerFileSelect}
                      id="daily-task-dropzone"
                      className={`border-2 border-dashed rounded-3xl p-6.5 text-center cursor-pointer transition-all duration-150 flex flex-col items-center justify-center space-y-3 ${
                        isDragging 
                          ? 'border-amber-500 bg-amber-500/5' 
                          : 'border-amber-500/20 hover:border-amber-500/40 hover:bg-[#0c0c0e]'
                      }`}
                    >
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        accept="image/*"
                        className="hidden"
                      />
                      <div className="p-3.5 bg-amber-500/10 rounded-full text-amber-500">
                        <UploadCloud className="h-6 w-6 text-amber-500" />
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-black text-white">
                          Drag and drop screenshot here, or <span className="text-amber-400 font-extrabold hover:underline">browse files</span>
                        </p>
                        <p className="text-[10px] text-gray-400 font-mono">
                          Supports PNG, JPG, or JPEG up to 8MB
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="border border-amber-500/10 rounded-3xl p-4 bg-[#0c0c0e] relative animate-scale-in space-y-3.5 text-left">
                      {/* Compact Thumbnail-based File Input Status & Controls */}
                      <div className="flex items-center gap-3 bg-[#111113] p-3 rounded-2xl border border-amber-500/10 shadow-3xs">
                        {/* Interactive Preview Thumbnail with zoom-trigger overlay */}
                        <div 
                          onClick={() => setIsPreviewOpen(true)}
                          className="relative h-14 w-14 sm:h-16 sm:w-16 rounded-xl overflow-hidden border border-amber-500/20 bg-slate-900 cursor-zoom-in shrink-0 group shadow-2xs"
                          title="Click to zoom in"
                        >
                          <img 
                            src={screenshotPreview} 
                            alt="Uploaded screenshot thumbnail" 
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                          />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                            <ZoomIn className="h-3.5 w-3.5 text-white" />
                          </div>
                        </div>

                        {/* File Meta information */}
                        <div className="flex-1 min-w-0 space-y-0.5">
                          <span className="block text-[8px] font-black font-mono text-amber-400 uppercase tracking-wider">
                            Ready for analysis
                          </span>
                          <h6 className="text-[10.5px] font-extrabold text-white truncate font-mono">
                            {screenshotFileName || "screenshot_proof.png"}
                          </h6>
                          <div className="flex items-center gap-1.5 text-[9.5px] text-gray-400 font-mono">
                            <span className="inline-flex items-center px-1.5 py-0.2 rounded bg-amber-500/10 border border-amber-500/20 text-amber-400 font-bold text-[8.5px]">
                              IMAGE
                            </span>
                            <span>Proof Verified</span>
                          </div>
                        </div>

                        {/* Action controllers directly in the input container */}
                        <div className="flex flex-col gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={triggerFileSelect}
                            className="p-1 px-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-lg text-[9px] font-black font-mono uppercase tracking-wider transition cursor-pointer"
                          >
                            Replace
                          </button>
                          <button
                            type="button"
                            onClick={clearScreenshot}
                            className="p-1 px-2 text-red-400 hover:bg-red-500/10 border border-red-500/20 rounded-lg text-[9px] font-black font-mono uppercase tracking-wider transition cursor-pointer"
                          >
                            Remove
                          </button>
                        </div>
                      </div>

                      {/* Expandable detailed visual preview representation */}
                      <div 
                        onClick={() => setIsPreviewOpen(true)}
                        className="relative aspect-video max-h-[180px] rounded-2xl overflow-hidden border border-amber-500/10 shadow-3xs bg-[#111113] cursor-zoom-in group flex items-center justify-center"
                        title="Click to zoom screenshot proof"
                      >
                        <img 
                          src={screenshotPreview} 
                          alt="Screenshot Proof Of Completion" 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-contain bg-slate-950/2"
                        />
                        <div className="absolute bottom-2.5 right-2.5 bg-slate-950/80 backdrop-blur-md text-white text-[9px] px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 font-bold font-mono shadow-xs border border-white/10">
                          <ZoomIn className="h-3 w-3 text-[#f5af19]" />
                          <span>Click to Zoom / Scan Details</span>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-t border-amber-500/10 pt-2.5 text-[10px] text-gray-400 font-mono px-1">
                        <span className="flex items-center gap-1 text-amber-400 font-black uppercase">
                          <CheckCircle className="h-3.5 w-3.5" />
                          STABILITY MATCH VERIFIED
                        </span>
                        <span className="text-gray-500">{screenshotFileName || "screenshot.png"}</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Step 3: Optional Username Handle Verification */}
                <div className="space-y-2">
                  <span className="block text-[10px] font-mono font-bold uppercase text-gray-400 tracking-wider">
                    Step 3: Account Handle (Username confirmation)
                  </span>
                  <input
                    type="text"
                    id="verification-handle-input"
                    value={verificationHandle}
                    onChange={(e) => setVerificationHandle(e.target.value)}
                    placeholder="e.g. Your Twitter @username / Telegram Name"
                    className="w-full px-4 py-3 rounded-2xl border border-amber-500/10 bg-[#0b0b0c] text-xs text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition font-mono"
                  />
                </div>

                {submitError && (
                  <p className="text-[11px] font-bold text-red-400 bg-red-500/10 p-3 rounded-2xl border border-red-500/20 font-mono text-center">
                    ⚠️ {submitError}
                  </p>
                )}

                {/* Submission interactive Claim CTA */}
                <button
                  type="button"
                  disabled={isSubmitting || !screenshotPreview}
                  onClick={handleSubmitVerification}
                  id="task-submit-verification-btn"
                  className={`w-full py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-wider transition shadow-sm flex items-center justify-center gap-2 select-none cursor-pointer ${
                    !screenshotPreview
                      ? 'bg-[#0c0c0e] text-gray-600 cursor-not-allowed border border-amber-500/5'
                      : isSubmitting
                      ? 'bg-gradient-to-r from-amber-500 to-[#e65c00] text-slate-950 cursor-wait'
                      : 'bg-gradient-to-r from-amber-400 via-amber-500 to-[#e65c00] hover:brightness-110 text-slate-950 font-black hover:shadow-md'
                  }`}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>{submissionStatus || "Scanning Image Match Compliance..."}</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 text-slate-950 animate-pulse" />
                      <span>Verify Screenshot and Claim Reward</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Bottom meta stats */}
            <div className="border-t border-gray-100 pt-4 mt-6 flex items-center justify-between text-[10px] font-mono text-gray-400">
              <span className="uppercase">Difficulty: {primaryTask.difficulty}</span>
              <span className="uppercase">Est: ~1-2 Minutes</span>
            </div>

          </div>
        </div>
      </div>

      {/* Premium Zoom & Pre-Flight Verification Lightbox Modal */}
      {isPreviewOpen && screenshotPreview && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 sm:p-6 transition-all duration-300">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh] text-left animate-scale-in"
          >
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-150 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Eye className="h-5 w-5 text-indigo-600 animate-pulse" />
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-slate-900 font-display">
                    Evidence Review Lightbox
                  </h3>
                  <p className="text-[10px] text-slate-400 font-mono">
                    Pre-Flight Verification Comparison
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsPreviewOpen(false)}
                className="p-1.5 hover:bg-slate-200 text-slate-400 hover:text-slate-700 rounded-full transition cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scrollable Comparison Content */}
            <div className="p-6 overflow-y-auto space-y-6">
              
              {/* Screenshot View */}
              <div className="space-y-2">
                <span className="block text-[10px] font-mono font-bold uppercase text-indigo-600 tracking-wider">
                  Uploaded Screenshot Proof
                </span>
                <div className="relative border border-slate-150 rounded-2xl overflow-hidden bg-slate-900 aspect-auto flex items-center justify-center py-2 max-h-[300px]">
                  <img 
                    src={screenshotPreview} 
                    alt="Proof Preview" 
                    referrerPolicy="no-referrer"
                    className="max-h-[280px] object-contain w-auto mx-auto rounded-lg"
                  />
                  <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-xs text-white text-[9px] px-2.5 py-1 rounded-full font-mono font-bold">
                    HD Preview Enabled
                  </div>
                </div>
              </div>

              {/* Guidelines Comparison Side-By-Side */}
              <div className="bg-slate-50 border border-slate-150 rounded-2xl p-4.5 space-y-4">
                <div className="space-y-1">
                  <h4 className="text-xs font-black text-slate-800 uppercase tracking-wide">
                    Task Campaign Criteria Match:
                  </h4>
                  <p className="text-xs text-slate-600 italic">
                    "{primaryTask.instruction}"
                  </p>
                </div>

                <div className="border-t border-slate-200 pt-3 space-y-2.5">
                  <span className="block text-[9px] font-mono font-black text-slate-400 uppercase tracking-widest">
                    Manual Proof Checklist:
                  </span>
                  
                  <div className="space-y-2 text-xs font-sans text-slate-700">
                    <label className="flex items-start gap-2.5 cursor-pointer select-none">
                      <input 
                        type="checkbox" 
                        defaultChecked 
                        className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500/20" 
                      />
                      <span>My profile handle or subscription state is fully visible on screen</span>
                    </label>
                    <label className="flex items-start gap-2.5 cursor-pointer select-none">
                      <input 
                        type="checkbox" 
                        defaultChecked
                        className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500/20" 
                      />
                      <span>The image is high-quality, clear, and unblurred</span>
                    </label>
                    <label className="flex items-start gap-2.5 cursor-pointer select-none">
                      <input 
                        type="checkbox" 
                        defaultChecked
                        className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500/20" 
                      />
                      <span>I did not crop out important platform metrics</span>
                    </label>
                  </div>
                </div>
              </div>

            </div>

            {/* Modal Footer Controls */}
            <div className="p-4 bg-slate-50 border-t border-slate-150 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsPreviewOpen(false)}
                className="px-4 py-2.5 border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Dismiss Preview
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsPreviewOpen(false);
                }}
                className="px-5 py-2.5 bg-[#f5af19] hover:bg-[#e09a0f] text-gray-950 rounded-xl text-xs font-black uppercase tracking-wider transition shadow-xs cursor-pointer"
              >
                Looks Good, Ready!
              </button>
            </div>
          </motion.div>
        </div>
      )}

    </div>
  );
}
