/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Formats a numeric value into a standard Nigerian Naira currency representation.
 */
export function formatNaira(value: number, showDecimal = false): string {
  try {
    const formatted = new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: showDecimal ? 2 : 0,
      maximumFractionDigits: showDecimal ? 2 : 0,
    }).format(value);
    
    // Sometimes JS fails with NGN glyph positions, standardizing format as ₦XX,XXX if needed
    return formatted.replace('NGN', '₦').replace('NGN\u00A0', '₦');
  } catch (err) {
    // Basic fallback representation
    return `₦${value.toLocaleString(undefined, {
      minimumFractionDigits: showDecimal ? 2 : 0,
      maximumFractionDigits: showDecimal ? 2 : 0,
    })}`;
  }
}

/**
 * Generates a randomized transaction or action ID log
 */
export function generateRefID(prefix = 'TX'): string {
  const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `${prefix}-${result}`;
}

/**
 * Returns formatted local string timestamps
 */
export function getCurrentTimestamp(): string {
  const current = new Date();
  const year = current.getFullYear();
  const month = String(current.getMonth() + 1).padStart(2, '0');
  const day = String(current.getDate()).padStart(2, '0');
  const hours = String(current.getHours()).padStart(2, '0');
  const minutes = String(current.getMinutes()).padStart(2, '0');
  
  return `${year}-${month}-${day} ${hours}:${minutes}`;
}

export type PlanType = 'Solo' | 'Prem' | 'Vip';

export interface PlanConfig {
  id: PlanType;
  label: string;
  tokenFee: number;
  refPaid: number;
  dailyTaskPaid: number;
  minWithdrawalRef: number;
  minWithdrawalTask: number;
}

export const PLANS: Record<PlanType, PlanConfig> = {
  Solo: {
    id: 'Solo',
    label: 'Solo Plan',
    tokenFee: 5000,
    refPaid: 1500,
    dailyTaskPaid: 800,
    minWithdrawalRef: 9000,
    minWithdrawalTask: 20000,
  },
  Prem: {
    id: 'Prem',
    label: 'Premium Plan',
    tokenFee: 10000,
    refPaid: 3500,
    dailyTaskPaid: 1500,
    minWithdrawalRef: 21000,
    minWithdrawalTask: 40000,
  },
  Vip: {
    id: 'Vip',
    label: 'VIP Plan',
    tokenFee: 15000,
    refPaid: 4500,
    dailyTaskPaid: 2100,
    minWithdrawalRef: 27000,
    minWithdrawalTask: 60000,
  },
};

export function normalizePlan(level: string | null | undefined): PlanType {
  if (!level) return 'Solo';
  const lg = level.toLowerCase();
  if (lg.includes('vip')) return 'Vip';
  if (lg.includes('prem') || lg.includes('premium')) return 'Prem';
  return 'Solo';
}

/**
 * Returns whether global audio effects are enabled. Defaults to true.
 */
export function isSoundEnabled(): boolean {
  try {
    const val = localStorage.getItem('naira_sound_enabled');
    return val === null ? true : val === 'true';
  } catch (e) {
    return true;
  }
}

/**
 * Sets the global sound effects preference.
 */
export function setSoundEnabledPref(enabled: boolean): void {
  try {
    localStorage.setItem('naira_sound_enabled', enabled ? 'true' : 'false');
  } catch (e) {}
}

/**
 * Audio Synthesizer helper using Web Audio API for lightweight, retro audio cues.
 */
export function playSynthSound(type: 'coin' | 'err' | 'win' | 'level' | 'task_complete' | 'withdrawal'): void {
  if (!isSoundEnabled()) return;
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    if (type === 'coin') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.1); // A5
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, ctx.currentTime + 0.15);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } else if (type === 'err') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, ctx.currentTime); // A3
      osc.frequency.linearRampToValueAtTime(110, ctx.currentTime + 0.2); // A2
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, ctx.currentTime + 0.25);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } else if (type === 'win') {
      osc.type = 'sine';
      const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const time = ctx.currentTime + idx * 0.08;
        const subOsc = ctx.createOscillator();
        const subGain = ctx.createGain();
        subOsc.type = 'sine';
        subOsc.frequency.setValueAtTime(freq, time);
        subGain.gain.setValueAtTime(0.1, time);
        subGain.gain.linearRampToValueAtTime(0.01, time + 0.12);
        subOsc.connect(subGain);
        subGain.connect(ctx.destination);
        subOsc.start(time);
        subOsc.stop(time + 0.12);
      });
    } else if (type === 'level') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(329.63, ctx.currentTime); // E4
      osc.frequency.setValueAtTime(440, ctx.currentTime + 0.12); // A4
      osc.frequency.setValueAtTime(554.37, ctx.currentTime + 0.24); // C#5
      osc.frequency.exponentialRampToValueAtTime(659.25, ctx.currentTime + 0.36); // E5
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, ctx.currentTime + 0.5);
      osc.start();
      osc.stop(ctx.currentTime + 0.5);
    } else if (type === 'task_complete') {
      // Pleasant ascending notification tone
      osc.type = 'sine';
      const notes = [440, 554.37, 659.25, 880]; // A4, C#5, E5, A5
      notes.forEach((freq, idx) => {
        const time = ctx.currentTime + idx * 0.07;
        const subOsc = ctx.createOscillator();
        const subGain = ctx.createGain();
        subOsc.type = 'sine';
        subOsc.frequency.setValueAtTime(freq, time);
        subGain.gain.setValueAtTime(0.08, time);
        subGain.gain.linearRampToValueAtTime(0.01, time + 0.15);
        subOsc.connect(subGain);
        subGain.connect(ctx.destination);
        subOsc.start(time);
        subOsc.stop(time + 0.15);
      });
    } else if (type === 'withdrawal') {
      // Bright financial cash chime
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(783.99, ctx.currentTime); // G5 (sharp chime)
      osc.frequency.setValueAtTime(987.77, ctx.currentTime + 0.06); // B5
      osc.frequency.setValueAtTime(1174.66, ctx.currentTime + 0.12); // D6
      osc.frequency.exponentialRampToValueAtTime(1567.98, ctx.currentTime + 0.2); // G6 High sparkle
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.01, ctx.currentTime + 0.4);
      osc.start();
      osc.stop(ctx.currentTime + 0.4);
    }
  } catch (error) {
    // Fail silently in unsupported or blocked environments
  }
}

