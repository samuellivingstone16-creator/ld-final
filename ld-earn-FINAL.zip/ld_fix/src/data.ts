/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SocialTask, ReferralUser, EarningActivity, WithdrawalRecord } from './types';

// Supported Banks in Nigeria for Withdrawal Request Simulator
export const NIGERIAN_BANKS = [
  'Guaranty Trust Bank (GTBank)',
  'Access Bank PLC',
  'Zenith Bank',
  'Kuda Microfinance Bank',
  'OPay Digital Services',
  'PalmPay',
  'United Bank for Africa (UBA)',
  'First Bank of Nigeria',
  'Fidelity Bank',
  'Wema Bank (ALAT)',
  'Sterling Bank',
  'Ecobank Nigeria',
  'Union Bank of Nigeria'
];

export const INITIAL_TASKS: SocialTask[] = [];

export const INITIAL_REFERRALS: ReferralUser[] = [];

export const INITIAL_WITHDRAWALS: WithdrawalRecord[] = [];

export const INITIAL_ACTIVITIES: EarningActivity[] = [];
