// supabaseService.ts - Direct browser-to-Supabase connection for cross-device referral sync
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://dhjnpngqlihzlbhemzlx.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRoam5wbmdxbGloemxiaGVtemx4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQwMjQ0MTMsImV4cCI6MjA5OTYwMDQxM30.CrZQAW3LLPdBAzQX5JUQwVbZeFKQF5paDAhFs-Q3q5U';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

export const addReferral = async (
  referrerEmail: string,
  newUserEmail: string,
  newUserName: string,
  amount: number
) => {
  try {
    const { error } = await supabase.from('referrals').insert([{
      referrer_email: referrerEmail,
      new_user_email: newUserEmail,
      new_user_name: newUserName,
      amount,
      status: 'Active'
    }]);
    if (error) {
      console.warn('Supabase addReferral error:', error);
      return false;
    }
    console.log(`Referral saved to Supabase: ${referrerEmail} <- ${newUserEmail}`);
    return true;
  } catch (err) {
    console.warn('Supabase addReferral exception:', err);
    return false;
  }
};

export const getUserReferrals = async (email: string) => {
  try {
    const { data, error } = await supabase
      .from('referrals')
      .select('*')
      .eq('referrer_email', email)
      .order('created_at', { ascending: false });
    if (error) {
      console.warn('Supabase getUserReferrals error:', error);
      return [];
    }
    return data || [];
  } catch (err) {
    console.warn('Supabase getUserReferrals exception:', err);
    return [];
  }
};

export const getTotalReferralEarnings = async (email: string) => {
  const referrals = await getUserReferrals(email);
  return referrals.reduce((sum: number, r: any) => sum + (r.amount || 0), 0);
};

export default supabase;
