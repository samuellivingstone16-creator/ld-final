// Simplified sync utility - no external backend/Firebase dependency.
// Referral cross-device sync is handled separately via Supabase (see services/supabaseService.ts).
// These functions simply return the local data unchanged so the app works entirely offline/local
// without any failing network requests or console errors.

export async function syncAccounts(localAccounts: any[]): Promise<any[]> {
  // Always ensure the pioneer admin account is seeded if empty
  const defaultAdminEmail = "livingstone0806382@gmail.com";
  const hasAdmin = localAccounts.some((a: any) => a.email && a.email.toLowerCase() === defaultAdminEmail.toLowerCase());
  if (!hasAdmin) {
    localAccounts.push({
      email: defaultAdminEmail,
      password: "Stone44@",
      fullName: "Livingstone Admin",
      username: "livingstone",
      phoneNumber: "08063820000",
      profileLevel: "Vip",
      totalBalance: 125000,
      availableWithdrawal: 125000,
      referralEarnings: 0,
      referralBalance: 0,
      taskBalance: 125000,
      totalReferrals: 0,
      referralsList: [],
      activitiesList: [
        {
          id: "PION-BY-001",
          type: "Bonus",
          title: "First-Time Login Bonus",
          amount: 12500,
          isCredit: true,
          timestamp: "2026-06-30 16:59",
          details: "₦12,500 welcome bonus credited automatically upon your first-time login.",
          status: "Successful"
        }
      ],
      refSlug: "LD-SOLO-PIONEER",
      refCode: "PIONEER",
      profilePhoto: null,
      tasks: []
    });
  }
  return localAccounts;
}

export async function syncTokens(localTokens: { token: string; status: 'Unused' | 'Used' }[]): Promise<{ token: string; status: 'Unused' | 'Used' }[]> {
  return localTokens;
}

export async function syncTasks(localTasks: any[]): Promise<any[]> {
  return localTasks;
}
