/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SocialTask {
  id: string;
  platform: 'Twitter' | 'YouTube' | 'Instagram' | 'Facebook' | 'Telegram' | 'TikTok' | 'Survey' | 'Website';
  title: string;
  reward: number; // in Naira (₦)
  actionUrl: string;
  instruction: string;
  status: 'Available' | 'Verifying' | 'Completed' | 'Expired';
  category: 'Social Share' | 'Video Watching' | 'Subscription' | 'User Survey' | 'App Integrity';
  difficulty: 'Easy' | 'Medium' | 'Intermediate';
  proofOfWork?: string;
  verificationImage?: string;
  submittedAt?: string;
  userEmail?: string;
  createdAt?: string;
  originalTaskId?: string;
  profileLevel?: string;
}

export interface ReferralUser {
  id: string;
  fullName: string;
  email: string;
  joinedDate: string;
  commissionEarned: number; // in Naira (₦)
  status: 'Active' | 'Pending' | 'Flagged';
}

export interface WithdrawalRecord {
  id: string;
  amount: number; // in Naira (₦)
  bankName: string;
  accountNumber: string;
  accountName: string;
  status: 'Pending' | 'Successful' | 'Declined';
  timestamp: string;
}

export interface EarningActivity {
  id: string;
  type: 'Task' | 'Referral' | 'Withdrawal' | 'Bonus';
  title: string;
  amount: number; // in Naira (₦)
  isCredit: boolean;
  timestamp: string;
  details?: string;
  status: 'Successful' | 'Pending' | 'Failed';
  bankName?: string;
  accountNumber?: string;
  accountName?: string;
  category?: string;
}

export interface BusinessCampaign {
  id: string;
  businessName: string;
  category: 'WhatsApp' | 'YouTube' | 'Instagram' | 'Facebook' | 'Telegram' | 'TikTok' | 'Website' | 'Other';
  actionUrl: string;
  targetAction: string;
  rewardPerTask: number;
  totalTasksRequired: number;
  completedTasksCount: number;
  totalBudget: number;
  instructions: string;
  status: 'Draft' | 'Active' | 'Paused' | 'Completed';
  createdAt: string;
}

