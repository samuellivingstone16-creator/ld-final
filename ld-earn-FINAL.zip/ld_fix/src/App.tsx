/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { SocialTask, ReferralUser, EarningActivity } from './types';
import { INITIAL_TASKS, INITIAL_REFERRALS, INITIAL_ACTIVITIES } from './data';
import { syncAccounts, syncTasks as syncTasksCloud } from './lib/cloudSync';
import { generateRefID, getCurrentTimestamp, normalizePlan, PLANS, formatNaira, PlanType, playSynthSound } from './utils';
import ldLogo from './assets/images/ld_logo_1781514983884.jpg';

// Icons for the Sidebar Menu
import { 
  LayoutDashboard, 
  CheckSquare, 
  Users, 
  Wallet, 
  ArrowUpRight, 
  Receipt, 
  Bell, 
  LifeBuoy, 
  Settings, 
  LogOut, 
  Menu, 
  X, 
  Coins, 
  User, 
  Sparkles,
  CheckCircle,
  HelpCircle,
  Briefcase,
  Clock,
  AlertTriangle,
  Send,
  BellRing,
  ShieldCheck
} from 'lucide-react';

// Core component parts of the ecosystem
import Dashboard from './components/Dashboard';
import TasksList from './components/TasksList';
import ReferralSystem from './components/ReferralSystem';
import WalletLedger from './components/WalletLedger';
import WithdrawalForm from './components/WithdrawalForm';
import MyBusiness from './components/MyBusiness';
import AdminWithdrawals, { GlobalWithdrawal } from './components/AdminWithdrawals';
import PinProtectionOverlay from './components/PinProtectionOverlay';

// Newly requested feature components
import TransactionHistory from './components/TransactionHistory';
import NotificationsCenter from './components/NotificationsCenter';
import SupportCenter from './components/SupportCenter';
import ProfileSettings from './components/ProfileSettings';
import Footer from './components/Footer';
import Login from './components/Login';
import WithdrawalProofs from './components/WithdrawalProofs';

export interface Vendor {
  label: string;
  phone: string;
  display: string;
}

interface AdminSettingsContextType {
  vendors: Vendor[];
  saveVendors: (newVendors: Vendor[]) => void;
  lastSyncedTime: string;
  setLastSyncedTime: (val: string) => void;
  justSynced: boolean;
  setJustSynced: (val: boolean) => void;
  officialChannelLink: string;
  saveOfficialChannelLink: (url: string) => void;
  officialWhatsappLink: string;
  saveOfficialWhatsappLink: (url: string) => void;
}

export const AdminSettingsContext = React.createContext<AdminSettingsContextType | undefined>(undefined);

export function useAdminSettings() {
  const context = React.useContext(AdminSettingsContext);
  if (!context) {
    throw new Error('useAdminSettings must be used within an AdminSettingsProvider');
  }
  return context;
}

export function AdminSettingsProvider({ children }: { children: React.ReactNode }) {
  const DEFAULT_VENDORS = [
    { label: "Vendor Agent 1", phone: "2348063823716", display: "0806 382 3716" },
    { label: "Vendor Agent 2", phone: "2349041887695", display: "+234 904 188 7695" }
  ];

  const DEFAULT_CHANNEL_LINK = "https://t.me/+8aDqe4G00v8xOGI0";
  const DEFAULT_WHATSAPP_LINK = "https://whatsapp.com/channel/0029Vb8MwfN4CrfZB97sry1r";

  const [vendors, setVendors] = useState<Vendor[]>(() => {
    const saved = localStorage.getItem('ld_vendors');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const filtered = parsed.filter(v => v.phone !== '2349160368611');
          if (filtered.length !== parsed.length) {
            localStorage.setItem('ld_vendors', JSON.stringify(filtered));
            return filtered;
          }
          return parsed;
        }
      } catch (e) {}
    }
    return DEFAULT_VENDORS;
  });

  const [officialChannelLink, setOfficialChannelLink] = useState<string>(() => {
    const saved = localStorage.getItem('ld_official_channel_link');
    if (saved === "https://t.me/+ld_earn_official_broadcast") {
      localStorage.removeItem('ld_official_channel_link');
      return DEFAULT_CHANNEL_LINK;
    }
    return saved || DEFAULT_CHANNEL_LINK;
  });

  const [officialWhatsappLink, setOfficialWhatsappLink] = useState<string>(() => {
    const saved = localStorage.getItem('ld_official_whatsapp_link');
    if (saved === "https://chat.whatsapp.com/GzB9Zon0r4jInK9SpxP6gK") {
      localStorage.removeItem('ld_official_whatsapp_link');
      return DEFAULT_WHATSAPP_LINK;
    }
    return saved || DEFAULT_WHATSAPP_LINK;
  });

  const [lastSyncedTime, setLastSyncedTime] = useState<string>(() => {
    return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  });
  const [justSynced, setJustSynced] = useState<boolean>(true);

  useEffect(() => {
    const handleSync = () => {
      const saved = localStorage.getItem('ld_vendors');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            const filtered = parsed.filter(v => v.phone !== '2349160368611');
            setVendors(filtered);
            setLastSyncedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
            setJustSynced(true);
          }
        } catch (e) {}
      } else {
        setVendors(DEFAULT_VENDORS);
        setLastSyncedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
        setJustSynced(true);
      }

      const savedChannel = localStorage.getItem('ld_official_channel_link');
      if (savedChannel) {
        setOfficialChannelLink(savedChannel);
      }

      const savedWhatsapp = localStorage.getItem('ld_official_whatsapp_link');
      if (savedWhatsapp) {
        setOfficialWhatsappLink(savedWhatsapp);
      }
    };
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  const saveVendors = (newVendors: Vendor[]) => {
    const filtered = newVendors.filter(v => v.phone !== '2349160368611');
    setVendors(filtered);
    localStorage.setItem('ld_vendors', JSON.stringify(filtered));
    window.dispatchEvent(new Event('storage'));
    setLastSyncedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    setJustSynced(true);
  };

  const saveOfficialChannelLink = (url: string) => {
    setOfficialChannelLink(url);
    localStorage.setItem('ld_official_channel_link', url);
    window.dispatchEvent(new Event('storage'));
    setLastSyncedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    setJustSynced(true);
  };

  const saveOfficialWhatsappLink = (url: string) => {
    setOfficialWhatsappLink(url);
    localStorage.setItem('ld_official_whatsapp_link', url);
    window.dispatchEvent(new Event('storage'));
    setLastSyncedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    setJustSynced(true);
  };

  return (
    <AdminSettingsContext.Provider value={{ 
      vendors, 
      saveVendors, 
      lastSyncedTime, 
      setLastSyncedTime, 
      justSynced, 
      setJustSynced,
      officialChannelLink,
      saveOfficialChannelLink,
      officialWhatsappLink,
      saveOfficialWhatsappLink
    }}>
      {children}
    </AdminSettingsContext.Provider>
  );
}

export default function App() {
  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const ref = params.get('ref');
      if (ref) {
        // Clear active session to allow the new referred friend to register clean
        localStorage.removeItem('ld_affiliate_authenticated');
        localStorage.setItem('pending_referral_code', ref.toUpperCase().trim());
        return false;
      }
    }
    return localStorage.getItem('ld_affiliate_authenticated') === 'true';
  });

  // Track last user interaction timestamp for auto-logout
  const lastActivityTime = useRef<number>(Date.now());
  const hasFetchedTasks = useRef<boolean>(false);
  const [showLogoutWarning, setShowLogoutWarning] = useState<boolean>(false);
  const [warningCountdown, setWarningCountdown] = useState<number>(60);

  useEffect(() => {
    if (!isAuthenticated) return;

    // Reset activity timestamp on user interaction events
    const handleActivity = () => {
      lastActivityTime.current = Date.now();
    };

    const activityEvents = ['mousedown', 'mousemove', 'keydown', 'scroll', 'touchstart', 'click'];

    activityEvents.forEach(event => {
      window.addEventListener(event, handleActivity);
    });

    return () => {
      activityEvents.forEach(event => {
        window.removeEventListener(event, handleActivity);
      });
    };
  }, [isAuthenticated]);

  // Dark/Light/System Theme State
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>(() => {
    return (localStorage.getItem('ld_theme') as 'light' | 'dark' | 'system') || 'system';
  });

  useEffect(() => {
    const root = window.document.documentElement;
    
    const applyTheme = () => {
      if (theme === 'system') {
        const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        if (systemPrefersDark) {
          root.classList.add('dark');
        } else {
          root.classList.remove('dark');
        }
      } else if (theme === 'dark') {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    };

    applyTheme();
    localStorage.setItem('ld_theme', theme);

    if (theme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const listener = () => applyTheme();
      mediaQuery.addEventListener('change', listener);
      return () => mediaQuery.removeEventListener('change', listener);
    }
  }, [theme]);

  // Profile preferences fetched gracefully to show in Sidebar header
  const [profileName, setProfileName] = useState(() => localStorage.getItem('naira_profile_name') || 'John Doe');
  const [profileLevel, setProfileLevel] = useState(() => localStorage.getItem('naira_profile_level') || 'Solo');
  const [profilePhoto, setProfilePhoto] = useState<string | null>(() => localStorage.getItem('naira_profile_photo'));

  // Track if current user is admin to filter "My Business" Access
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    const email = localStorage.getItem('naira_profile_email') || '';
    const isEligible = email.toLowerCase() === 'livingstone0806382@gmail.com' || email.toLowerCase().includes('admin');
    if (!isEligible) return false;
    const saved = localStorage.getItem('ld_user_is_admin');
    if (saved !== null) return saved === 'true';
    return true; // default true for elite/admin profiles
  });

  const [officialChannelLink, setOfficialChannelLink] = useState(() => {
    const saved = localStorage.getItem('ld_official_channel_link');
    if (saved === "https://t.me/+ld_earn_official_broadcast") {
      localStorage.removeItem('ld_official_channel_link');
      return "https://t.me/+8aDqe4G00v8xOGI0";
    }
    return saved || "https://t.me/+8aDqe4G00v8xOGI0";
  });

  const [officialWhatsappLink, setOfficialWhatsappLink] = useState(() => {
    const saved = localStorage.getItem('ld_official_whatsapp_link');
    if (saved === "https://chat.whatsapp.com/GzB9Zon0r4jInK9SpxP6gK") {
      localStorage.removeItem('ld_official_whatsapp_link');
      return "https://whatsapp.com/channel/0029Vb8MwfN4CrfZB97sry1r";
    }
    return saved || "https://whatsapp.com/channel/0029Vb8MwfN4CrfZB97sry1r";
  });

  // Keep state synchronized on manual triggers and storage overrides
  useEffect(() => {
    const syncProfileState = () => {
      setProfileName(localStorage.getItem('naira_profile_name') || 'John Doe');
      setProfileLevel(localStorage.getItem('naira_profile_level') || 'Solo');
      setProfilePhoto(localStorage.getItem('naira_profile_photo'));
      
      const savedChannel = localStorage.getItem('ld_official_channel_link');
      if (savedChannel) {
        setOfficialChannelLink(savedChannel);
      }

      const savedWhatsapp = localStorage.getItem('ld_official_whatsapp_link');
      if (savedWhatsapp) {
        setOfficialWhatsappLink(savedWhatsapp);
      }
      
      const email = localStorage.getItem('naira_profile_email') || '';
      const isEligible = email.toLowerCase() === 'livingstone0806382@gmail.com' || email.toLowerCase().includes('admin');
      if (!isEligible) {
        setIsAdmin(false);
      } else {
        const saved = localStorage.getItem('ld_user_is_admin');
        if (saved !== null) {
          setIsAdmin(saved === 'true');
        } else {
          setIsAdmin(true);
        }
      }
    };

    window.addEventListener('storage', syncProfileState);
    return () => {
      window.removeEventListener('storage', syncProfileState);
    };
  }, []);

  // Navigation tabs conforming exactly to the requested sidebar layout
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'tasks' | 'referrals' | 'business' | 'wallet' | 'withdraw' | 'transactions' | 'withdrawal_proofs' | 'notifications' | 'support' | 'profile' | 'logout' | 'admin_withdrawals'
  >('dashboard');

  // Simulated double-wall Security PIN locks
  const [isWithdrawUnlocked, setIsWithdrawUnlocked] = useState(false);
  const [isBusinessUnlocked, setIsBusinessUnlocked] = useState(false);

  // Auto-lock secure sections instantly when navigating away to protect user's balance ledger
  useEffect(() => {
    if (activeTab !== 'withdraw') {
      setIsWithdrawUnlocked(false);
      setPresetWithdrawalAmount(null);
      setPresetCategory(null);
    }
    if (activeTab !== 'business') {
      setIsBusinessUnlocked(false);
    }
  }, [activeTab]);

  // Handle auto-fallback to dashboard if non-admin tries to view business, admin withdrawals or withdrawal proofs tab
  useEffect(() => {
    if ((activeTab === 'business' || activeTab === 'admin_withdrawals') && !isAdmin) {
      setActiveTab('dashboard');
    }
  }, [activeTab, isAdmin]);

  // Mobile drawer trigger
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  // Preset withdrawal states for 1-click quick-withdraw
  const [presetWithdrawalAmount, setPresetWithdrawalAmount] = useState<number | null>(null);
  const [presetCategory, setPresetCategory] = useState<'Referral' | 'Task' | null>(null);

  // App notification messages toast
  const [toastMessage, setToastMessage] = useState('');

  // Run a one-time reset of cached balance values to force the correct starting numbers to display immediately
  const forceResetOnce = () => {
    const RESET_KEY = 'naira_fresh_reset_v10';
    if (localStorage.getItem(RESET_KEY) !== 'true') {
      localStorage.removeItem('naira_total_balance');
      localStorage.removeItem('naira_available_withdrawal');
      localStorage.removeItem('naira_referral_earnings');
      localStorage.removeItem('naira_referral_balance');
      localStorage.removeItem('naira_task_balance');
      localStorage.removeItem('naira_total_referrals');
      localStorage.removeItem('naira_referrals_list');
      localStorage.removeItem('naira_activities_list');
      localStorage.removeItem('naira_tasks');
      localStorage.removeItem('naira_business_campaigns');
      localStorage.removeItem('naira_mock_sanitization_v14_done');
      localStorage.removeItem('naira_tasks_cleared_v4');

      const currentLevel = localStorage.getItem('naira_profile_level') || 'Solo';
      let bonusAmount = 3500;
      if (currentLevel === 'Prem') {
        bonusAmount = 8000;
      } else if (currentLevel === 'Vip') {
        bonusAmount = 12500;
      }

      localStorage.setItem('naira_total_balance', bonusAmount.toString());
      localStorage.setItem('naira_available_withdrawal', bonusAmount.toString());
      localStorage.setItem('naira_task_balance', bonusAmount.toString());
      localStorage.setItem('naira_referral_earnings', '0');
      localStorage.setItem('naira_referral_balance', '0');
      localStorage.setItem('naira_total_referrals', '0');

      const welcomeBonusActivity = {
        id: 'BY-' + Math.floor(1000 + Math.random() * 9000),
        type: 'Bonus',
        title: 'First-Time Login Bonus',
        amount: bonusAmount,
        isCredit: true,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
        details: `₦${bonusAmount.toLocaleString()} welcome bonus credited automatically upon your first-time login.`,
        status: 'Successful'
      };
      localStorage.setItem('naira_activities_list', JSON.stringify([welcomeBonusActivity]));
      localStorage.setItem('naira_referrals_list', JSON.stringify([]));

      localStorage.setItem('naira_mock_sanitization_v14_done', 'true');
      localStorage.setItem(RESET_KEY, 'true');
    }
  };
  forceResetOnce();

  const getInitialBalance = (type: 'total' | 'available' | 'ref_earnings' | 'ref_bal' | 'task_bal') => {
    return 0;
  };

  // Ledger state balances with extreme NaN defense
  const [totalBalance, setTotalBalance] = useState<number>(() => {
    const saved = localStorage.getItem('naira_total_balance');
    const val = saved !== null ? Number(saved) : 0;
    return isNaN(val) ? 0 : val;
  });

  const [availableWithdrawal, setAvailableWithdrawal] = useState<number>(() => {
    const saved = localStorage.getItem('naira_available_withdrawal');
    const val = saved !== null ? Number(saved) : 0;
    return isNaN(val) ? 0 : val;
  });

  const [referralEarnings, setReferralEarnings] = useState<number>(() => {
    const saved = localStorage.getItem('naira_referral_earnings');
    const val = saved !== null ? Number(saved) : 0;
    return isNaN(val) ? 0 : val;
  });

  const [referralBalance, setReferralBalance] = useState<number>(() => {
    const saved = localStorage.getItem('naira_referral_balance');
    const val = saved !== null ? Number(saved) : 0;
    return isNaN(val) ? 0 : val;
  });

  const [taskBalance, setTaskBalance] = useState<number>(() => {
    const saved = localStorage.getItem('naira_task_balance');
    const val = saved !== null ? Number(saved) : 0;
    return isNaN(val) ? 0 : val;
  });

  const [totalReferrals, setTotalReferrals] = useState<number>(() => {
    const saved = localStorage.getItem('naira_total_referrals');
    const val = saved !== null ? Number(saved) : 0; // Starts with 0 referrals
    return isNaN(val) ? 0 : val;
  });

  // Task lists
  const [tasks, setTasks] = useState<SocialTask[]>(() => {
    const saved = localStorage.getItem('naira_tasks');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_TASKS;
  });

  // Global withdrawals state (Admin aggregate)
  const [globalWithdrawals, setGlobalWithdrawals] = useState<GlobalWithdrawal[]>([]);

  // Referrals
  const [referrals, setReferrals] = useState<ReferralUser[]>(() => {
    const saved = localStorage.getItem('naira_referrals_list');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_REFERRALS;
  });

  // Audit Logs
  const [activities, setActivities] = useState<EarningActivity[]>(() => {
    const saved = localStorage.getItem('naira_activities_list');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Filter out dummy/demo/mock legacy withdrawal activities to satisfy "only real ones not demo"
          return parsed.filter(act => 
            act &&
            act.id !== 'ACT-003' && 
            !(act.type === 'Withdrawal' && act.title && !String(act.title).toLowerCase().includes('nibss'))
          );
        }
      } catch (e) {}
    }
    return INITIAL_ACTIVITIES;
  });

  // Unread notifications tracker
  const [unreadCount, setUnreadCount] = useState(1);

  // One-time startup soft cleanup of cached tasks, campaigns, and aggressive mock data sanitization
  useEffect(() => {
    // Soft clean tasks
    if (localStorage.getItem('naira_tasks_cleared_v4') !== 'true') {
      localStorage.removeItem('naira_tasks');
      localStorage.removeItem('naira_business_campaigns');
      localStorage.setItem('naira_tasks_cleared_v4', 'true');
      setTasks([]);
    }

    // Comprehensive mock balance, referral, and activity sanitization ("Remove the Mock")
    const hasSanitized = localStorage.getItem('naira_mock_sanitization_v14_done');
    if (!hasSanitized) {
      // 1. Clean stored activities: filter out presets & arcade drop catcher simulation logs
      let currentActivities: EarningActivity[] = [];
      const savedActivities = localStorage.getItem('naira_activities_list');
      if (savedActivities) {
        try {
          const parsed = JSON.parse(savedActivities);
          if (Array.isArray(parsed)) {
            currentActivities = parsed;
          }
        } catch (e) {}
      }

      const realActivities = currentActivities.filter(act => {
        if (!act) return false;
        const id = String(act.id || '');
        const title = String(act.title || '').toLowerCase();
        // Skip dummy/preset entries
        if (id === 'ACT-001' || id === 'ACT-002' || id === 'ACT-003') return false;
        // Skip any non-earning arcade simulation levels
        if (title.includes('loyalty bonus') || title.includes('drop catcher') || title.includes('naira drop') || title.includes('welcome capital reward') || title.includes('welcome bonus')) {
          return false;
        }
        return true;
      });

      // 2. Clean stored referrals list: filter out initial preset mock referral objects
      let currentReferrals: ReferralUser[] = [];
      const savedReferrals = localStorage.getItem('naira_referrals_list');
      if (savedReferrals) {
        try {
          const parsed = JSON.parse(savedReferrals);
          if (Array.isArray(parsed)) {
            currentReferrals = parsed;
          }
        } catch (e) {}
      }

      const realReferrals = currentReferrals.filter(ref => {
        if (!ref) return false;
        const name = String(ref.fullName || '').toLowerCase();
        const id = String(ref.id || '');
        // Filter out initial simulated presets
        if (id.startsWith('ref-') || name.includes('david okeke') || name.includes('chioma adebayo') || name.includes('babajide alabi') || name.includes('musa ibrahim') || name.includes('blessing udoh') || name.includes('emeka onyema') || name.includes('funmilayo ojo')) {
          return false;
        }
        return true;
      });

      // 3. Recalculate true real-time ledger states based exclusively on their genuine records!
      let realTaskBal = 0;
      let realRefBal = 0;
      let realRefEarnings = 0;

      // Add real user registration referral commissions
      realReferrals.forEach(ref => {
        const comm = Number(ref.commissionEarned || 500);
        if (!isNaN(comm)) {
          realRefBal += comm;
          realRefEarnings += comm;
        }
      });

      // Overlay task submission history logs
      realActivities.forEach(act => {
        if (act.status === 'Successful' || act.status === 'Pending') {
          const amt = Number(act.amount || 0);
          if (!isNaN(amt)) {
            if (act.type === 'Task') {
              if (act.isCredit) realTaskBal += amt;
              else realTaskBal -= amt;
            } else if (act.type === 'Referral') {
              if (act.isCredit) {
                realRefBal += amt;
                realRefEarnings += amt;
              } else realRefBal -= amt;
            } else if (act.type === 'Withdrawal') {
              if (act.details && act.details.toLowerCase().includes('task')) {
                realTaskBal -= amt;
              } else {
                realRefBal -= amt;
              }
            }
          }
        }
      });

      if (isNaN(realTaskBal) || realTaskBal < 0) realTaskBal = 0;
      if (isNaN(realRefBal) || realRefBal < 0) realRefBal = 0;
      if (isNaN(realRefEarnings) || realRefEarnings < 0) realRefEarnings = 0;
      const realTotal = realTaskBal + realRefBal;

      // Commit sanitized lists back to persistence storage
      localStorage.setItem('naira_activities_list', JSON.stringify(realActivities));
      localStorage.setItem('naira_referrals_list', JSON.stringify(realReferrals));
      localStorage.setItem('naira_total_referrals', realReferrals.length.toString());
      localStorage.setItem('naira_total_balance', realTotal.toString());
      localStorage.setItem('naira_available_withdrawal', realTotal.toString());
      localStorage.setItem('naira_referral_balance', realRefBal.toString());
      localStorage.setItem('naira_referral_earnings', realRefEarnings.toString());
      localStorage.setItem('naira_task_balance', realTaskBal.toString());

      // Permanently register the cleanup as complete
      localStorage.setItem('naira_mock_sanitization_v14_done', 'true');

      // Update current React model hooks
      setActivities(realActivities);
      setReferrals(realReferrals);
      setTotalReferrals(realReferrals.length);
      setTotalBalance(realTotal);
      setAvailableWithdrawal(realTotal);
      setReferralBalance(realRefBal);
      setReferralEarnings(realRefEarnings);
      setTaskBalance(realTaskBal);
    }
  }, []);

  // Continually sync profile details from local preferences if they update
  useEffect(() => {
    const interval = setInterval(() => {
      const savedName = localStorage.getItem('naira_profile_name') || 'John Doe';
      const savedLevel = localStorage.getItem('naira_profile_level') || 'Solo';
      const savedPhoto = localStorage.getItem('naira_profile_photo');
      if (savedName !== profileName) setProfileName(savedName);
      if (savedPhoto !== profilePhoto) setProfilePhoto(savedPhoto);
      if (savedLevel !== profileLevel) {
        setProfileLevel(savedLevel);
      }

      // Sync Admin privilege state
      const savedEmail = localStorage.getItem('naira_profile_email') || '';
      const isEligible = savedEmail.toLowerCase() === 'livingstone0806382@gmail.com' || savedEmail.toLowerCase().includes('admin');
      const currentIsAdmin = isEligible && (localStorage.getItem('ld_user_is_admin') !== 'false');

      if (currentIsAdmin !== isAdmin) {
        setIsAdmin(currentIsAdmin);
      }

      // Read live notification count
      const notifsJson = localStorage.getItem('naira_notifications');
      if (notifsJson) {
        try {
          const list = JSON.parse(notifsJson);
          const unread = list.filter((n: any) => !n.read).length;
          setUnreadCount(unread);
        } catch (e) {}
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [profileName, profileLevel, isAdmin, profilePhoto]);

  // Persist states automatically to local preferences
  useEffect(() => {
    localStorage.setItem('ld_affiliate_authenticated', isAuthenticated.toString());
  }, [isAuthenticated]);

  // Synchronize current state back to accounts database
  useEffect(() => {
    const currentEmail = localStorage.getItem('naira_profile_email');
    if (!currentEmail || !isAuthenticated) return;

    let accounts: any[] = [];
    try {
      const accountsStr = localStorage.getItem('ld_accounts_database') || '[]';
      accounts = JSON.parse(accountsStr);
      let index = accounts.findIndex((a: any) => a.email.toLowerCase() === currentEmail.toLowerCase());
      
      if (index === -1) {
        // Create user account if missing locally
        accounts.push({
          email: currentEmail,
          fullName: profileName,
          profileLevel: profileLevel,
          profilePhoto: profilePhoto,
          totalBalance: totalBalance,
          availableWithdrawal: availableWithdrawal,
          referralEarnings: referralEarnings,
          referralBalance: referralBalance,
          taskBalance: taskBalance,
          totalReferrals: totalReferrals,
          referralsList: referrals,
          activitiesList: activities,
          tasks: tasks,
          password: localStorage.getItem('naira_profile_password') || '123456',
          refSlug: localStorage.getItem('ld_user_ref_slug') || '',
          refCode: localStorage.getItem('ld_user_ref_code') || '',
        });
        index = accounts.length - 1;
      } else {
        const acc = accounts[index];
        acc.fullName = profileName;
        acc.profileLevel = profileLevel;
        acc.profilePhoto = profilePhoto;
        acc.totalBalance = totalBalance;
        acc.availableWithdrawal = availableWithdrawal;
        acc.referralEarnings = referralEarnings;
        acc.referralBalance = referralBalance;
        acc.taskBalance = taskBalance;
        acc.totalReferrals = totalReferrals;
        acc.referralsList = referrals;
        acc.activitiesList = activities;
        acc.tasks = tasks;
        
        // Also sync password and other details in case they changed in profiles/settings
        acc.password = localStorage.getItem('naira_profile_password') || acc.password;
        acc.refSlug = localStorage.getItem('ld_user_ref_slug') || acc.refSlug;
        acc.refCode = localStorage.getItem('ld_user_ref_code') || acc.refCode;
      }
      localStorage.setItem('ld_accounts_database', JSON.stringify(accounts));
    } catch (e) {
      console.error('Error synchronizing account details:', e);
    }

    // Push synchronization to the server asynchronously
    const syncWithServer = async () => {
      try {
        const updatedAccounts = await syncAccounts(accounts);
        if (Array.isArray(updatedAccounts)) {
          localStorage.setItem('ld_accounts_database', JSON.stringify(updatedAccounts));
          
          // Check for any remote referral additions or balance updates from other devices
          const serverOwnAcc = updatedAccounts.find((a: any) => a.email.toLowerCase() === currentEmail.toLowerCase());
          if (serverOwnAcc) {
            // Robust check and updates of client side state with server state
            if (serverOwnAcc.totalBalance !== totalBalance) {
              setTotalBalance(serverOwnAcc.totalBalance || 0);
            }
            if (serverOwnAcc.availableWithdrawal !== availableWithdrawal) {
              setAvailableWithdrawal(serverOwnAcc.availableWithdrawal || 0);
            }
            if (serverOwnAcc.referralEarnings !== referralEarnings) {
              setReferralEarnings(serverOwnAcc.referralEarnings || 0);
            }
            if (serverOwnAcc.referralBalance !== referralBalance) {
              setReferralBalance(serverOwnAcc.referralBalance || 0);
            }
            if (serverOwnAcc.taskBalance !== taskBalance) {
              setTaskBalance(serverOwnAcc.taskBalance || 0);
            }
            if (serverOwnAcc.totalReferrals !== totalReferrals) {
              setTotalReferrals(serverOwnAcc.totalReferrals || 0);
            }
            if (JSON.stringify(serverOwnAcc.referralsList || []) !== JSON.stringify(referrals)) {
              setReferrals(serverOwnAcc.referralsList || []);
            }
            if (JSON.stringify(serverOwnAcc.activitiesList || []) !== JSON.stringify(activities)) {
              setActivities(serverOwnAcc.activitiesList || []);
            }
            if (serverOwnAcc.tasks && Array.isArray(serverOwnAcc.tasks)) {
              const serverTasksStr = JSON.stringify(serverOwnAcc.tasks);
              const localTasksStr = JSON.stringify(tasks);
              if (serverTasksStr !== localTasksStr) {
                setTasks(serverOwnAcc.tasks);
              }
            }
          }
        }
      } catch (err) {
        console.warn('Post-sync connection on standby:', err);
      }
    };

    syncWithServer();
  }, [
    isAuthenticated,
    profileName,
    profileLevel,
    profilePhoto,
    totalBalance,
    availableWithdrawal,
    referralEarnings,
    referralBalance,
    taskBalance,
    totalReferrals,
    referrals,
    activities,
    tasks
  ]);

  // Periodic background account synchronization to receive real-time referrals from other devices
  useEffect(() => {
    const currentEmail = localStorage.getItem('naira_profile_email');
    if (!currentEmail || !isAuthenticated) return;

    const interval = setInterval(async () => {
      try {
        const localStr = localStorage.getItem('ld_accounts_database') || '[]';
        const localAccounts = JSON.parse(localStr);
        
        const updatedAccounts = await syncAccounts(localAccounts);
        if (Array.isArray(updatedAccounts)) {
          localStorage.setItem('ld_accounts_database', JSON.stringify(updatedAccounts));
          const serverOwnAcc = updatedAccounts.find((a: any) => a.email.toLowerCase() === currentEmail.toLowerCase());
          if (serverOwnAcc) {
            // Robust check and updates of client side state with server state
            if (serverOwnAcc.totalBalance !== totalBalance) {
              setTotalBalance(serverOwnAcc.totalBalance || 0);
            }
            if (serverOwnAcc.availableWithdrawal !== availableWithdrawal) {
              setAvailableWithdrawal(serverOwnAcc.availableWithdrawal || 0);
            }
            if (serverOwnAcc.referralEarnings !== referralEarnings) {
              setReferralEarnings(serverOwnAcc.referralEarnings || 0);
            }
            if (serverOwnAcc.referralBalance !== referralBalance) {
              setReferralBalance(serverOwnAcc.referralBalance || 0);
            }
            if (serverOwnAcc.taskBalance !== taskBalance) {
              setTaskBalance(serverOwnAcc.taskBalance || 0);
            }
            if (serverOwnAcc.totalReferrals !== totalReferrals) {
              setTotalReferrals(serverOwnAcc.totalReferrals || 0);
            }
            if (JSON.stringify(serverOwnAcc.referralsList || []) !== JSON.stringify(referrals)) {
              setReferrals(serverOwnAcc.referralsList || []);
            }
            if (JSON.stringify(serverOwnAcc.activitiesList || []) !== JSON.stringify(activities)) {
              setActivities(serverOwnAcc.activitiesList || []);
            }
            if (serverOwnAcc.tasks && Array.isArray(serverOwnAcc.tasks)) {
              const serverTasksStr = JSON.stringify(serverOwnAcc.tasks);
              const localTasksStr = JSON.stringify(tasks);
              if (serverTasksStr !== localTasksStr) {
                setTasks(serverOwnAcc.tasks);
              }
            }
          }
        }
      } catch (err) {
        console.warn('Periodic sync paused (network stand-by):', err);
      }
    }, 8000);

    return () => clearInterval(interval);
  }, [isAuthenticated, referrals.length]);

  useEffect(() => {
    localStorage.setItem('naira_total_balance', totalBalance.toString());
  }, [totalBalance]);

  useEffect(() => {
    localStorage.setItem('naira_available_withdrawal', availableWithdrawal.toString());
  }, [availableWithdrawal]);

  useEffect(() => {
    localStorage.setItem('naira_referral_earnings', referralEarnings.toString());
  }, [referralEarnings]);

  useEffect(() => {
    localStorage.setItem('naira_referral_balance', referralBalance.toString());
  }, [referralBalance]);

  useEffect(() => {
    localStorage.setItem('naira_task_balance', taskBalance.toString());
  }, [taskBalance]);

  useEffect(() => {
    localStorage.setItem('naira_total_referrals', totalReferrals.toString());
  }, [totalReferrals]);

  useEffect(() => {
    localStorage.setItem('naira_tasks', JSON.stringify(tasks));
    if (isAuthenticated && isAdmin) {
      if (!hasFetchedTasks.current) {
        console.log('Skipping master tasks sync because server tasks haven\'t been loaded yet.');
        return;
      }
      // Filter out any user submission items to keep the master list clean on the server
      const masterOnly = tasks.filter(t => !t.id.includes('@') && !t.id.includes('_'));
      syncTasksCloud(masterOnly).catch(err => console.warn('Sync master tasks failed:', err));
    }
  }, [tasks, isAdmin, isAuthenticated]);

  // Periodic background tasks synchronization for multi-device/multi-user consistency
  useEffect(() => {
    if (!isAuthenticated) return;

    const syncTasks = async () => {
      try {
        // 1. Fetch master tasks from server or cloud
        let serverTasks: SocialTask[] = [];
        try {
          const tasksRes = await fetch('/api/tasks');
          if (tasksRes.ok) {
            const tasksData = await tasksRes.json();
            if (tasksData.success && Array.isArray(tasksData.tasks)) {
              serverTasks = tasksData.tasks;
              hasFetchedTasks.current = true;
            }
          } else {
            throw new Error('Fallback to cloud');
          }
        } catch (err) {
          serverTasks = await syncTasksCloud([]);
          hasFetchedTasks.current = true;
        }

        if (isAdmin) {
          // Admin syncs accounts to aggregate and display all user task proof submissions
          let allAccounts: any[] = [];
          try {
            const accountsRes = await fetch('/api/accounts');
            if (accountsRes.ok) {
              const accountsData = await accountsRes.json();
              if (accountsData.success && Array.isArray(accountsData.accounts)) {
                allAccounts = accountsData.accounts;
              }
            } else {
              throw new Error('Fallback to cloud');
            }
          } catch (err) {
            allAccounts = await syncAccounts([]);
          }

          if (allAccounts && allAccounts.length > 0) {
            const userSubmissions: SocialTask[] = [];
            const userWithdrawals: GlobalWithdrawal[] = [];

            allAccounts.forEach((acc: any) => {
              if (acc.tasks && Array.isArray(acc.tasks)) {
                acc.tasks.forEach((ut: any) => {
                  if (ut.status === 'Verifying' || ut.status === 'Completed') {
                    userSubmissions.push({
                      ...ut,
                      id: `${ut.id}_${acc.email}`, // Unique ID for Admin's local list
                      originalTaskId: ut.id,
                      userEmail: acc.email,
                      profileLevel: acc.profileLevel || 'Solo'
                    });
                  }
                });
              }

              // Extract withdrawal activities
              if (acc.activitiesList && Array.isArray(acc.activitiesList)) {
                acc.activitiesList.forEach((act: any) => {
                  if (act.type === 'Withdrawal') {
                    let bankName = act.bankName || '';
                    if (!bankName && act.title && act.title.includes(':')) {
                      bankName = act.title.split(':').slice(1).join(':').trim();
                    }
                    let accountNumber = act.accountNumber || '';
                    let accountName = act.accountName || '';
                    if (!accountNumber && act.details) {
                      const matchAcc = act.details.match(/A\/C:\s*(\d+)/);
                      if (matchAcc) accountNumber = matchAcc[1];
                      const matchName = act.details.match(/\(([^)]+)\)/);
                      if (matchName) accountName = matchName[1];
                    }

                    userWithdrawals.push({
                      id: act.id,
                      email: acc.email,
                      fullName: acc.fullName || 'User',
                      amount: act.amount,
                      bankName: bankName || 'Standard Bank',
                      accountNumber: accountNumber || '0000000000',
                      accountName: accountName || (acc.fullName ? acc.fullName.toUpperCase() : 'USER'),
                      category: act.category || 'Task',
                      status: act.status || 'Pending',
                      timestamp: act.timestamp || getCurrentTimestamp(),
                      details: act.details
                    });
                  }
                });
              }
            });

            setTasks(prevTasks => {
              // Extract current master tasks (non-user submissions) from serverTasks
              const activeMaster = serverTasks.filter(st => !userSubmissions.some(us => us.originalTaskId === st.id && us.userEmail === st.userEmail));
              
              // We must also keep any newly created local tasks that haven't made it to serverTasks yet!
              const localNewTasks = prevTasks.filter(lt => 
                !lt.id.includes('@') && 
                !lt.id.includes('_') && 
                !serverTasks.some(st => st.id === lt.id)
              );

              return [...localNewTasks, ...activeMaster, ...userSubmissions];
            });

            setGlobalWithdrawals(userWithdrawals);
          } else {
            if (serverTasks.length > 0) {
              setTasks(prev => {
                // Keep any local user submissions that aren't on the server
                const userSubs = prev.filter(t => t.id.includes('_') || t.id.includes('@'));
                // Keep any newly created local tasks that haven't made it to serverTasks yet
                const localNewTasks = prev.filter(lt => 
                  !lt.id.includes('@') && 
                  !lt.id.includes('_') && 
                  !serverTasks.some(st => st.id === lt.id)
                );
                return [...localNewTasks, ...serverTasks, ...userSubs];
              });
            }
          }
        } else {
          // Normal user merges server tasks with their own local completion states
          setTasks(prevTasks => {
            const merged = serverTasks.map(st => {
              const localMatch = prevTasks.find(lt => lt.id === st.id);
              if (localMatch) {
                return {
                  ...st,
                  status: localMatch.status,
                  proofOfWork: localMatch.proofOfWork,
                  verificationImage: localMatch.verificationImage,
                  submittedAt: localMatch.submittedAt,
                  userEmail: localMatch.userEmail
                };
              }
              return st;
            });
            return merged;
          });
        }
      } catch (err) {
        console.warn('Tasks sync on standby:', err);
      }
    };

    // Run once on load/auth
    syncTasks();

    const interval = setInterval(syncTasks, 5000);
    return () => clearInterval(interval);
  }, [isAuthenticated, isAdmin]);

  // Automatic 24-hour daily expiration check for microtasks
  useEffect(() => {
    const checkExpiry = () => {
      setTasks(prevTasks => {
        let hasChanges = false;
        const now = Date.now();
        const twentyFourHours = 24 * 60 * 60 * 1000;

        const updated = prevTasks.map(task => {
          if (task.status !== 'Available') return task;

          let createdAtMs = now;
          if (task.createdAt) {
            const parsed = Date.parse(task.createdAt);
            if (!isNaN(parsed)) createdAtMs = parsed;
          } else if (task.id && task.id.startsWith('task-admin-')) {
            const tsStr = task.id.replace('task-admin-', '').split('_')[0];
            const parsedTs = parseInt(tsStr, 10);
            if (!isNaN(parsedTs)) createdAtMs = parsedTs;
          } else {
            // Treat as created now if absolutely no date exists
            task.createdAt = new Date().toISOString();
            createdAtMs = now;
          }

          if (now - createdAtMs > twentyFourHours) {
            hasChanges = true;
            return {
              ...task,
              status: 'Expired' as const
            };
          }
          return task;
        });

        if (hasChanges) {
          localStorage.setItem('naira_tasks', JSON.stringify(updated));
          return updated;
        }
        return prevTasks;
      });
    };

    // Run check immediately and then every 10 seconds
    checkExpiry();
    const expiryInterval = setInterval(checkExpiry, 10000);
    return () => clearInterval(expiryInterval);
  }, []);

  useEffect(() => {
    localStorage.setItem('naira_referrals_list', JSON.stringify(referrals));
  }, [referrals]);

  useEffect(() => {
    localStorage.setItem('naira_activities_list', JSON.stringify(activities));
  }, [activities]);

  // Handle auto-approval transitions for realistic micro-activity feedback loops
  useEffect(() => {
    const pendingWithdrawal = activities.find(a => a.type === 'Withdrawal' && a.status === 'Pending');
    
    if (pendingWithdrawal) {
      const timer = setTimeout(() => {
        setActivities(prevAct => 
          prevAct.map(act => 
            act.id === pendingWithdrawal.id 
              ? { ...act, status: 'Successful', details: `${act.details} (Approved & Wired via NIBSS Rails)` } 
              : act
          )
        );
        triggerToast('NIBSS Clearing Success: Payout settled into your commercial bank account!');
      }, 7000); // Transitions to 'Successful' after 7 seconds
      return () => clearTimeout(timer);
    }
  }, [activities]);

  // Toast notifier helper
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 4500);
  };

  // Inactivity timeout monitoring: logs out the user after 15 minutes (900 seconds) of no user activity, showing a 60 second warning modal at 14 minutes (840 seconds)
  useEffect(() => {
    if (!isAuthenticated) {
      setShowLogoutWarning(false);
      return;
    }

    const checkInterval = setInterval(() => {
      const elapsedSeconds = Math.floor((Date.now() - lastActivityTime.current) / 1000);

      if (elapsedSeconds >= 900) {
        setIsAuthenticated(false);
        setActiveTab('dashboard');
        setShowLogoutWarning(false);
        triggerToast('Logged out automatically due to 15 minutes of inactivity.');
      } else if (elapsedSeconds >= 840) {
        setShowLogoutWarning(true);
        setWarningCountdown(900 - elapsedSeconds);
      } else {
        setShowLogoutWarning(false);
      }
    }, 1000);

    return () => clearInterval(checkInterval);
  }, [isAuthenticated]);

  // Fetch the active priority highlight task for the dashboard overview page
  const getHighlightTask = (): SocialTask | null => {
    const match = tasks.find(t => t.status === 'Available');
    return match || null;
  };

  // Action: Complete a task and transition to Verifying (Pending Admin Approval)
  const handleCompleteTask = async (taskId: string, proof: string, base64Image?: string): Promise<void> => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const activePlan = normalizePlan(profileLevel);
    const taskRewardAmount = PLANS[activePlan].dailyTaskPaid;

    // Mark task state as Verifying (Awaiting Admin Approval)
    setTasks(prevTasks => 
      prevTasks.map(t => t.id === taskId ? { 
        ...t, 
        status: 'Verifying', 
        proofOfWork: proof, 
        verificationImage: base64Image,
        submittedAt: getCurrentTimestamp(),
        userEmail: localStorage.getItem('naira_profile_email') || 'livingstone0806382@gmail.com'
      } : t)
    );

    // Append to transactions registry logs as a PENDING task activity
    const newActivity: EarningActivity = {
      id: generateRefID('TK'),
      type: 'Task',
      title: `Submitted Task Proof: ${task.title}`,
      amount: taskRewardAmount,
      isCredit: true,
      timestamp: getCurrentTimestamp(),
      details: `Proof of Work: "${proof}". Pending administrator verification review.`,
      status: 'Pending'
    };

    setActivities(prev => [...prev, newActivity]);
    playSynthSound('task_complete');
    triggerToast(`Task Submitted! Pending Administrator verification approval.`);
  };

  const addSystemNotification = (title: string, message: string, category: 'system' | 'task' | 'finance' | 'referral') => {
    try {
      const saved = localStorage.getItem('naira_notifications');
      let list = [];
      if (saved) {
        try { list = JSON.parse(saved); } catch (e) {}
      }
      const newNotif = {
        id: `notif-${Math.random().toString(36).substring(2, 6)}-${Date.now()}`,
        title,
        message,
        time: 'Just now',
        read: false,
        category
      };
      const updated = [newNotif, ...list];
      localStorage.setItem('naira_notifications', JSON.stringify(updated));
      window.dispatchEvent(new Event('storage'));
      window.dispatchEvent(new Event('naira_notifications_sync'));
    } catch (e) {
      console.error("Failed to add notification:", e);
    }
  };

  // Admin Action: Approve a submitted task proof (multi-user safe)
  const handleApproveTask = async (taskId: string) => {
    // Check if it is a user submission
    if (taskId.includes('_') && taskId.includes('@')) {
      const parts = taskId.split('_');
      const originalTaskId = parts[0];
      const userEmail = parts[1];

      try {
        let accounts: any[] = [];
        try {
          const res = await fetch('/api/accounts');
          if (res.ok) {
            const data = await res.json();
            if (data.success && Array.isArray(data.accounts)) {
              accounts = data.accounts;
            }
          } else {
            throw new Error('Fallback to cloud');
          }
        } catch (err) {
          accounts = await syncAccounts([]);
        }

        if (accounts && accounts.length > 0) {
          const userAcc = accounts.find((a: any) => a.email.toLowerCase() === userEmail.toLowerCase());
          if (userAcc) {
            if (!userAcc.tasks) userAcc.tasks = [];
            const userTask = userAcc.tasks.find((t: any) => t.id === originalTaskId);
            if (userTask) {
              userTask.status = 'Completed';
              
              const userLevel = normalizePlan(userAcc.profileLevel || 'Solo');
              const taskRewardAmount = PLANS[userLevel].dailyTaskPaid;

              userAcc.totalBalance = Number(((userAcc.totalBalance || 0) + taskRewardAmount).toFixed(2));
              userAcc.availableWithdrawal = Number(((userAcc.availableWithdrawal || 0) + taskRewardAmount).toFixed(2));
              userAcc.taskBalance = Number(((userAcc.taskBalance || 0) + taskRewardAmount).toFixed(2));

              if (!userAcc.activitiesList) userAcc.activitiesList = [];
              const pendingAct = userAcc.activitiesList.find((a: any) => a.type === 'Task' && a.status === 'Pending' && a.title.includes(userTask.title));
              if (pendingAct) {
                pendingAct.status = 'Successful';
                pendingAct.details = `${pendingAct.details} | Approved by Administrator.`;
              } else {
                userAcc.activitiesList.push({
                  id: generateRefID('TK'),
                  type: 'Task',
                  title: `Approved Task: ${userTask.title}`,
                  amount: taskRewardAmount,
                  isCredit: true,
                  timestamp: getCurrentTimestamp(),
                  details: `Proof of Work: "${userTask.proofOfWork || 'Verified'}" | Approved by Administrator.`,
                  status: 'Successful'
                });
              }

              const newNotif = {
                id: `notif-${Math.random().toString(36).substring(2, 6)}-${Date.now()}`,
                title: '🎉 Task Proof Approved!',
                message: `Congratulations! Your proof of submission for "${userTask.title}" has been reviewed and approved. +₦${taskRewardAmount.toLocaleString()} has been added to your available balance.`,
                time: 'Just now',
                read: false,
                category: 'task'
              };
              userAcc.notifications = [newNotif, ...(userAcc.notifications || [])];

              const updatedAccounts = await syncAccounts(accounts);
              if (Array.isArray(updatedAccounts)) {
                localStorage.setItem('ld_accounts_database', JSON.stringify(updatedAccounts));
              }

              setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: 'Completed' } : t));
              playSynthSound('task_complete');
              triggerToast(`User Task Approved! +₦${taskRewardAmount.toLocaleString()} credited to ${userEmail}.`);
              return;
            }
          }
        }
      } catch (e) {
        console.error("Failed to approve user task:", e);
      }
      return;
    }

    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const activePlan = normalizePlan(profileLevel);
    const taskRewardAmount = PLANS[activePlan].dailyTaskPaid;

    setTasks(prevTasks => 
      prevTasks.map(t => t.id === taskId ? { ...t, status: 'Completed' } : t)
    );

    setTotalBalance(prev => Number((prev + taskRewardAmount).toFixed(2)));
    setAvailableWithdrawal(prev => Number((prev + taskRewardAmount).toFixed(2)));
    setTaskBalance(prev => Number((prev + taskRewardAmount).toFixed(2)));

    setActivities(prevAct => {
      const updated = [...prevAct];
      const matchIdx = updated.findIndex(act => act.type === 'Task' && act.status === 'Pending');
      if (matchIdx !== -1) {
        updated[matchIdx] = {
          ...updated[matchIdx],
          status: 'Successful',
          details: `${updated[matchIdx].details} | Approved by Administrator.`
        };
      } else {
        updated.push({
          id: generateRefID('TK'),
          type: 'Task',
          title: `Approved Task: ${task.title}`,
          amount: taskRewardAmount,
          isCredit: true,
          timestamp: getCurrentTimestamp(),
          details: `Proof of Work: "${task.proofOfWork || 'Verified'}" | Approved by Administrator.`,
          status: 'Successful'
        });
      }
      return updated;
    });

    addSystemNotification(
      '🎉 Task Proof Approved!',
      `Congratulations! Your proof of submission for "${task.title}" has been reviewed and approved. +₦${taskRewardAmount.toLocaleString()} has been added to your available balance.`,
      'task'
    );

    playSynthSound('task_complete');
    triggerToast(`Task Proof Approved! +₦${taskRewardAmount.toLocaleString()} credited successfully.`);
  };

  // Admin Action: Reject a submitted task proof (multi-user safe)
  const handleRejectTask = async (taskId: string, reason: string) => {
    if (taskId.includes('_') && taskId.includes('@')) {
      const parts = taskId.split('_');
      const originalTaskId = parts[0];
      const userEmail = parts[1];

      try {
        let accounts: any[] = [];
        try {
          const res = await fetch('/api/accounts');
          if (res.ok) {
            const data = await res.json();
            if (data.success && Array.isArray(data.accounts)) {
              accounts = data.accounts;
            }
          } else {
            throw new Error('Fallback to cloud');
          }
        } catch (err) {
          accounts = await syncAccounts([]);
        }

        if (accounts && accounts.length > 0) {
          const userAcc = accounts.find((a: any) => a.email.toLowerCase() === userEmail.toLowerCase());
          if (userAcc) {
            if (!userAcc.tasks) userAcc.tasks = [];
            const userTask = userAcc.tasks.find((t: any) => t.id === originalTaskId);
            if (userTask) {
              userTask.status = 'Available';
              userTask.proofOfWork = undefined;
              userTask.verificationImage = undefined;
              userTask.submittedAt = undefined;

              if (userAcc.activitiesList) {
                const pendingAct = userAcc.activitiesList.find((a: any) => a.type === 'Task' && a.status === 'Pending' && a.title.includes(userTask.title));
                if (pendingAct) {
                  pendingAct.status = 'Failed';
                  pendingAct.details = `Rejected by Admin. Reason: ${reason || 'Incomplete action details.'}`;
                }
              }

              const newNotif = {
                id: `notif-${Math.random().toString(36).substring(2, 6)}-${Date.now()}`,
                title: '⚠️ Task Proof Declined',
                message: `Attention: Your proof of submission for "${userTask.title}" was declined by the administrator. Reason: "${reason}". Please review the instructions, make the correction, and resubmit.`,
                time: 'Just now',
                read: false,
                category: 'task'
              };
              userAcc.notifications = [newNotif, ...(userAcc.notifications || [])];

              const updatedAccounts = await syncAccounts(accounts);
              if (Array.isArray(updatedAccounts)) {
                localStorage.setItem('ld_accounts_database', JSON.stringify(updatedAccounts));
              }

              setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: 'Available' } : t));
              playSynthSound('err');
              triggerToast(`User Task Proof Rejected: ${reason || 'Incomplete action details'}`);
              return;
            }
          }
        }
      } catch (e) {
        console.error("Failed to reject user task:", e);
      }
      return;
    }

    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    setTasks(prevTasks => 
      prevTasks.map(t => t.id === taskId ? { 
        ...t, 
        status: 'Available', 
        proofOfWork: undefined, 
        verificationImage: undefined, 
        submittedAt: undefined 
      } : t)
    );

    setActivities(prevAct => {
      const updated = [...prevAct];
      const matchIdx = updated.findIndex(act => act.type === 'Task' && act.status === 'Pending');
      if (matchIdx !== -1) {
        updated[matchIdx] = {
          ...updated[matchIdx],
          status: 'Failed',
          details: `Rejected by Admin. Reason: ${reason || 'Incomplete action details.'}`
        };
      }
      return updated;
    });

    addSystemNotification(
      '⚠️ Task Proof Declined',
      `Attention: Your proof of submission for "${task.title}" was declined by the administrator. Reason: "${reason}". Please review the instructions, make the correction, and resubmit.`,
      'task'
    );

    playSynthSound('err');
    triggerToast(`Task Proof Rejected: ${reason || 'Incomplete action details'}`);
  };

  // Action: Invite a friend guest simulation
  const handleSimulateInvite = (fullName: string, email: string) => {
    const activePlan = normalizePlan(profileLevel);
    const inviteRewardAmount = PLANS[activePlan].refPaid;

    setTotalReferrals(prev => prev + 1);
    setReferralEarnings(prev => prev + inviteRewardAmount);

    setTotalBalance(prev => prev + inviteRewardAmount);
    setAvailableWithdrawal(prev => prev + inviteRewardAmount);
    setReferralBalance(prev => prev + inviteRewardAmount);

    const todayDate = new Date().toISOString().split('T')[0];

    const newFriend: ReferralUser = {
      id: `uref-${Math.random().toString(36).substring(2, 7)}`,
      fullName,
      email,
      joinedDate: todayDate,
      commissionEarned: inviteRewardAmount,
      status: 'Active'
    };

    const newActivity: EarningActivity = {
      id: generateRefID('RF'),
      type: 'Referral',
      title: `Referral Invited: ${fullName}`,
      amount: inviteRewardAmount,
      isCredit: true,
      timestamp: getCurrentTimestamp(),
      details: `Guest account setup verified under IP postbacks: ${email}`,
      status: 'Successful'
    };

    setReferrals(prev => [...prev, newFriend]);
    setActivities(prev => [...prev, newActivity]);
    triggerToast(`Referral Registered! +₦${inviteRewardAmount.toLocaleString()} added to available balances.`);
  };

  // Manual status audits and simulation updates for referrers
  const handleUpdateReferralStatus = (id: string, newStatus: 'Active' | 'Pending' | 'Flagged') => {
    setReferrals(prev => prev.map(ref => {
      if (ref.id === id) {
        const oldStatus = ref.status;
        const reward = ref.commissionEarned || PLANS[normalizePlan(profileLevel)].refPaid;
        
        if (newStatus === 'Active' && oldStatus !== 'Active') {
          setTotalBalance(b => Number((b + reward).toFixed(2)));
          setAvailableWithdrawal(b => Number((b + reward).toFixed(2)));
          setReferralBalance(b => Number((b + reward).toFixed(2)));
          
          const newActivity: EarningActivity = {
            id: generateRefID('RF'),
            type: 'Referral',
            title: `Referral Activated: ${ref.fullName}`,
            amount: reward,
            isCredit: true,
            timestamp: getCurrentTimestamp(),
            details: `Referral status manually authorized. Commission released.`,
            status: 'Successful'
          };
          setActivities(act => [...act, newActivity]);
          triggerToast(`Referral activated! +₦${reward} credited to available balances.`);
        } else if (oldStatus === 'Active' && newStatus !== 'Active') {
          setTotalBalance(b => Math.max(0, Number((b - reward).toFixed(2))));
          setAvailableWithdrawal(b => Math.max(0, Number((b - reward).toFixed(2))));
          setReferralBalance(b => Math.max(0, Number((b - reward).toFixed(2))));
          
          const newActivity: EarningActivity = {
            id: generateRefID('RF'),
            type: 'Referral',
            title: `Referral Flagged: ${ref.fullName}`,
            amount: reward,
            isCredit: false,
            timestamp: getCurrentTimestamp(),
            details: `Referral status flagged for auditing. Paid commission clawed back.`,
            status: 'Failed'
          };
          setActivities(act => [...act, newActivity]);
          triggerToast(`Referral deactivated! ₦${reward} commission clawed back.`);
        } else {
          triggerToast(`Referral status updated to ${newStatus}.`);
        }
        return { ...ref, status: newStatus };
      }
      return ref;
    }));
  };

  const handleDeleteReferral = (id: string) => {
    setReferrals(prev => {
      const match = prev.find(r => r.id === id);
      if (match) {
        const reward = match.commissionEarned || PLANS[normalizePlan(profileLevel)].refPaid;
        if (match.status === 'Active') {
          setTotalBalance(b => Math.max(0, Number((b - reward).toFixed(2))));
          setAvailableWithdrawal(b => Math.max(0, Number((b - reward).toFixed(2))));
          setReferralBalance(b => Math.max(0, Number((b - reward).toFixed(2))));
        }
        triggerToast(`Referral metadata for ${match.fullName} removed.`);
      }
      return prev.filter(r => r.id !== id);
    });
  };

  // Action: Platform loyalty bonus financing helper
  const handleAddEarningFunds = (
    amount: number, 
    title = 'Platform Loyalty Bonus Grant', 
    type: 'Task' | 'Referral' | 'Withdrawal' | 'Bonus' = 'Bonus', 
    details = 'Loyalty balance increment claimed via registered affiliate loyalty channels.'
  ) => {
    const isCredit = amount >= 0;
    const absAmount = Math.abs(amount);

    setTotalBalance(prev => Number((prev + amount).toFixed(2)));
    setAvailableWithdrawal(prev => Number((prev + amount).toFixed(2)));
    setTaskBalance(prev => {
      if (isCredit) {
        if (type === 'Task') {
          return Number((prev + amount).toFixed(2));
        }
        return Number((prev + amount / 2).toFixed(2));
      }
      if (prev >= absAmount) return Number((prev - absAmount).toFixed(2));
      return 0;
    });
    setReferralBalance(prev => {
      if (isCredit) {
        if (type === 'Task') {
          return prev;
        }
        return Number((prev + amount / 2).toFixed(2));
      }
      return prev;
    });

    const newActivity: EarningActivity = {
      id: generateRefID(type === 'Withdrawal' ? 'WD' : 'LY'),
      type,
      title,
      amount: absAmount,
      isCredit,
      timestamp: getCurrentTimestamp(),
      details,
      status: 'Successful'
    };

    setActivities(prev => [...prev, newActivity]);
  };

  // Action: Deduct balance for personal business campaign advertising
  const handleDeductBalance = (amount: number, details: string): boolean => {
    if (availableWithdrawal < amount) return false;
    
    // Deduct from taskBalance and total balances because tasks are funded by their own work balance or available withdrawals
    setTotalBalance(prev => Number((prev - amount).toFixed(2)));
    setAvailableWithdrawal(prev => Number((prev - amount).toFixed(2)));
    setTaskBalance(prev => {
      // Prioritize taskBalance deduction
      if (prev >= amount) return Number((prev - amount).toFixed(2));
      return 0; // fallback
    });
    return true;
  };

  const handleAddHistoryLog = (title: string, amount: number, details: string) => {
    const newACT: EarningActivity = {
      id: generateRefID('AD'),
      type: 'Withdrawal', // Debit/withdrawal category
      title,
      amount,
      isCredit: false,
      timestamp: getCurrentTimestamp(),
      details,
      status: 'Successful'
    };
    setActivities(prev => [...prev, newACT]);
  };

  // Action: Initiate bank wire cashout
  const handleInitiateWithdrawal = async (amount: number, bankName: string, accountNumber: string, accountName: string, category: 'Referral' | 'Task'): Promise<boolean> => {
    try {
      setTotalBalance(prev => Number((prev - amount).toFixed(2)));
      setAvailableWithdrawal(prev => Number((prev - amount).toFixed(2)));

      if (category === 'Referral') {
        setReferralBalance(prev => Number((prev - amount).toFixed(2)));
      } else {
        setTaskBalance(prev => Number((prev - amount).toFixed(2)));
      }

      const wdId = generateRefID('WD');
      const timeStampStr = getCurrentTimestamp();

      const newWDLog: EarningActivity = {
        id: wdId,
        type: 'Withdrawal',
        title: `NIBSS Cashout: ${bankName}`,
        amount,
        isCredit: false,
        timestamp: timeStampStr,
        details: `Disbursed to A/C: ${accountNumber} (${accountName}). Auditing transaction security...`,
        status: 'Pending',
        bankName,
        accountNumber,
        accountName,
        category
      };

      setActivities(prev => [...prev, newWDLog]);

      // Push to central global withdrawals repository so the Admin can see the request!
      try {
        const storedStr = localStorage.getItem('naira_global_withdrawals');
        const list = storedStr ? JSON.parse(storedStr) : [];
        const newGlobalWd = {
          id: wdId,
          email: localStorage.getItem('naira_profile_email') || 'livingstone0806382@gmail.com',
          fullName: localStorage.getItem('naira_profile_name') || 'Administrator',
          amount,
          bankName,
          accountNumber,
          accountName,
          category,
          status: 'Pending',
          timestamp: timeStampStr,
          details: newWDLog.details
        };
        localStorage.setItem('naira_global_withdrawals', JSON.stringify([newGlobalWd, ...list]));
        setGlobalWithdrawals(prev => [newGlobalWd, ...prev]);
      } catch (e) {
        // Quiet handled
      }

      playSynthSound('withdrawal');
      triggerToast(`NIBSS wire pipeline triggered for ₦${amount.toLocaleString()}`);
      return true;
    } catch (e) {
      return false;
    }
  };

  const handleWithdrawalProcessed = async (wdId: string, nextStatus: 'Successful' | 'Failed', remarks: string) => {
    try {
      // Fetch all accounts from the server to get the latest state
      let accounts: any[] = [];
      try {
        const res = await fetch('/api/accounts');
        if (res.ok) {
          const data = await res.json();
          if (data.success && Array.isArray(data.accounts)) {
            accounts = data.accounts;
          }
        } else {
          throw new Error('Fallback to cloud');
        }
      } catch (err) {
        accounts = await syncAccounts([]);
      }

      if (accounts && accounts.length > 0) {
        
        // Find the user who has this withdrawal ID in their activitiesList
        let foundUser = false;
        accounts.forEach((userAcc: any) => {
          if (!userAcc.activitiesList) userAcc.activitiesList = [];
          const actIndex = userAcc.activitiesList.findIndex((a: any) => a.id === wdId);
          if (actIndex !== -1) {
            foundUser = true;
            const act = userAcc.activitiesList[actIndex];
            act.status = nextStatus;
            act.details = remarks;

            // If the withdrawal was declined/failed, refund the money to the user's balance!
            if (nextStatus === 'Failed') {
              const refundAmount = act.amount || 0;
              userAcc.totalBalance = Number(((userAcc.totalBalance || 0) + refundAmount).toFixed(2));
              userAcc.availableWithdrawal = Number(((userAcc.availableWithdrawal || 0) + refundAmount).toFixed(2));
              
              if (act.category === 'Referral') {
                userAcc.referralBalance = Number(((userAcc.referralBalance || 0) + refundAmount).toFixed(2));
              } else {
                userAcc.taskBalance = Number(((userAcc.taskBalance || 0) + refundAmount).toFixed(2));
              }
            }

            // Add a notification for the user
            if (!userAcc.notifications) userAcc.notifications = [];
            userAcc.notifications.unshift({
              id: `notif-${Math.random().toString(36).substring(2, 6)}-${Date.now()}`,
              title: nextStatus === 'Successful' ? '💸 Cashout Disbursed!' : '❌ Cashout Declined',
              message: nextStatus === 'Successful' 
                ? `Your withdrawal request of ₦${act.amount.toLocaleString()} has been approved and paid out to your bank account.`
                : `Your withdrawal request of ₦${act.amount.toLocaleString()} was declined. Reason: ${remarks}`,
              time: 'Just now',
              read: false,
              category: 'finance'
            });
          }
        });

        if (foundUser) {
          // Sync updated accounts back to the server
          const updatedAccounts = await syncAccounts(accounts);
          if (Array.isArray(updatedAccounts)) {
            localStorage.setItem('ld_accounts_database', JSON.stringify(updatedAccounts));
          }

          // If updating active admin's own withdrawal, update client states
          const currentEmail = localStorage.getItem('naira_profile_email') || '';
          const serverOwnAcc = accounts.find((a: any) => a.email.toLowerCase() === currentEmail.toLowerCase());
          if (serverOwnAcc) {
            setTotalBalance(serverOwnAcc.totalBalance || 0);
            setAvailableWithdrawal(serverOwnAcc.availableWithdrawal || 0);
            setReferralBalance(serverOwnAcc.referralBalance || 0);
            setTaskBalance(serverOwnAcc.taskBalance || 0);
            setActivities(serverOwnAcc.activitiesList || []);
          }

          triggerToast(`Withdrawal ${wdId} successfully marked as ${nextStatus.toUpperCase()}!`);
        } else {
          // Fallback local update if not found in server accounts
          setActivities(prev => prev.map(act => {
            if (act.id === wdId) {
              return {
                ...act,
                status: nextStatus,
                details: remarks
              };
            }
            return act;
          }));

          if (nextStatus === 'Failed') {
            window.dispatchEvent(new CustomEvent('balance-shake'));
            const match = activities.find(a => a.id === wdId);
            if (match) {
              setTotalBalance(prev => Number((prev + match.amount).toFixed(2)));
              setAvailableWithdrawal(prev => Number((prev + match.amount).toFixed(2)));

              if (match.category === 'Referral') {
                setReferralBalance(prev => Number((prev + match.amount).toFixed(2)));
              } else {
                setTaskBalance(prev => Number((prev + match.amount).toFixed(2)));
              }
              triggerToast(`Declined payout of ₦${match.amount.toLocaleString()} refunded to your ledger wallet.`);
            }
          }
        }
      }
    } catch (err) {
      console.error('Failed to process withdrawal action:', err);
    }
  };

  const activeAvailableTasks = tasks.filter(t => t.status === 'Available').length;

  interface SidebarMenuItem {
    id: 'dashboard' | 'tasks' | 'referrals' | 'business' | 'wallet' | 'withdraw' | 'transactions' | 'withdrawal_proofs' | 'notifications' | 'support' | 'profile' | 'logout' | 'admin_withdrawals';
    label: string;
    icon: React.ComponentType<any>;
    badgeCount?: number;
    isBadgeRed?: boolean;
    isDanger?: boolean;
  }

  const menuItems: SidebarMenuItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'tasks', label: 'Daily Tasks', icon: CheckSquare, badgeCount: activeAvailableTasks },
    { id: 'referrals', label: 'Referrals', icon: Users, badgeCount: totalReferrals > 0 ? totalReferrals : undefined },
    ...(isAdmin ? [{ id: 'business', label: 'My Business', icon: Briefcase } as SidebarMenuItem] : []),
    ...(isAdmin ? [{ id: 'admin_withdrawals', label: 'Admin Payouts', icon: Coins } as SidebarMenuItem] : []),
    { id: 'wallet', label: 'Wallet', icon: Wallet },
    { id: 'withdraw', label: 'Withdraw Funds', icon: ArrowUpRight },
    { id: 'transactions', label: 'Transaction History', icon: Receipt },
    { id: 'withdrawal_proofs', label: 'Withdrawal Proofs', icon: ShieldCheck },
    { id: 'notifications', label: 'Notifications', icon: Bell, badgeCount: unreadCount > 0 ? unreadCount : undefined, isBadgeRed: true },
    { id: 'support', label: 'Support', icon: LifeBuoy },
    { id: 'profile', label: 'Profile Settings', icon: Settings },
    { id: 'logout', label: 'Logout', icon: LogOut, isDanger: true },
  ];

  if (!isAuthenticated) {
    return (
      <AdminSettingsProvider>
        <React.Fragment>
          {/* Toast Notifier HUD */}
          {toastMessage && (
            <div className="fixed bottom-5 right-5 z-50 bg-gray-950 text-white font-mono text-xs px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 border border-green-600 animate-slide-up" id="toast-alert-bar">
              <span className="h-2 w-2 rounded-full bg-green-500 animate-ping" />
              <span>{toastMessage}</span>
            </div>
          )}
          <Login 
            onLogin={(email) => {
              setIsAuthenticated(true);
              localStorage.setItem('naira_profile_email', email);
              
              // Load current localStorage values with fallback to credited values
              let taskBal = Number(localStorage.getItem('naira_task_balance') || '0');
              let totalBal = Number(localStorage.getItem('naira_total_balance') || '0');
              let availBal = Number(localStorage.getItem('naira_available_withdrawal') || '0');
              let refEarnings = Number(localStorage.getItem('naira_referral_earnings') || '0');
              let refBal = Number(localStorage.getItem('naira_referral_balance') || '0');
              let totRefs = Number(localStorage.getItem('naira_total_referrals') || '0');
              
              let refsList: ReferralUser[] = [];
              try {
                refsList = JSON.parse(localStorage.getItem('naira_referrals_list') || '[]');
              } catch (e) {}

              let list: EarningActivity[] = [];
              try {
                list = JSON.parse(localStorage.getItem('naira_activities_list') || '[]');
              } catch (e) {}

              // Also load profile info
              const savedName = localStorage.getItem('naira_profile_name') || 'John Doe';
              const savedLevel = localStorage.getItem('naira_profile_level') || 'Solo';
              const savedPhoto = localStorage.getItem('naira_profile_photo');

              setProfileName(savedName);
              setProfileLevel(savedLevel);
              setProfilePhoto(savedPhoto);

              setReferralEarnings(refEarnings);
              setReferralBalance(refBal);
              setTotalReferrals(totRefs);
              setReferrals(refsList);

              let savedTasks: SocialTask[] = [];
              try {
                savedTasks = JSON.parse(localStorage.getItem('naira_tasks') || '[]');
              } catch (e) {}
              setTasks(savedTasks);

              const hasBonus = list.some(act => act && act.type === 'Bonus');
              const alreadyCredited = localStorage.getItem(`ld_first_login_credited_${email}`) === 'true';

              if (!alreadyCredited && !hasBonus) {
                // Determine bonus based on user level
                const detectedPlan = (localStorage.getItem('naira_profile_level') || 'Solo') as PlanType;
                let bonusAmount = 3500;
                if (detectedPlan === 'Prem') {
                  bonusAmount = 8000;
                } else if (detectedPlan === 'Vip') {
                  bonusAmount = 12500;
                }

                taskBal += bonusAmount;
                totalBal += bonusAmount;
                availBal += bonusAmount;

                const welcomeBonusActivity: EarningActivity = {
                  id: generateRefID('BY'),
                  type: 'Bonus',
                  title: 'First-Time Login Bonus',
                  amount: bonusAmount,
                  isCredit: true,
                  timestamp: getCurrentTimestamp(),
                  details: `₦${bonusAmount.toLocaleString()} welcome bonus credited automatically upon your first-time login.`,
                  status: 'Successful'
                };

                list = [welcomeBonusActivity, ...list];

                localStorage.setItem('naira_task_balance', taskBal.toString());
                localStorage.setItem('naira_total_balance', totalBal.toString());
                localStorage.setItem('naira_available_withdrawal', availBal.toString());
                localStorage.setItem('naira_activities_list', JSON.stringify(list));
                localStorage.setItem(`ld_first_login_credited_${email}`, 'true');

                setTaskBalance(taskBal);
                setTotalBalance(totalBal);
                setAvailableWithdrawal(availBal);
                setActivities(list);

                triggerToast(`Welcome! ₦${bonusAmount.toLocaleString()} first-time login bonus has been credited to your Task Balance.`);
              } else {
                // Already has bonus or credited, ensure state is synchronized immediately
                setTaskBalance(taskBal);
                setTotalBalance(totalBal);
                setAvailableWithdrawal(availBal);
                setActivities(list);
                triggerToast('Authorized successfully! Welcome back to LD console.');
              }
            }}
            registeredEmail={localStorage.getItem('naira_profile_email') || ''}
          />
        </React.Fragment>
      </AdminSettingsProvider>
    );
  }

  return (
    <AdminSettingsProvider>
      <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row text-gray-900 font-sans antialiased selection:bg-amber-500 selection:text-slate-950">
      
      {/* 1. MOBILE RESPONSIVE NAVBAR HEADER */}
      <header className="lg:hidden w-full bg-white border-b border-gray-150 h-16 px-4 flex items-center justify-between sticky top-0 z-40 shadow-xs">
        <div className="flex items-center space-x-2">
          <div className="h-9 w-9 rounded-lg overflow-hidden flex items-center justify-center border border-gray-150 bg-slate-50">
            <img 
              src={ldLogo} 
              alt="LD Logo" 
              className="h-full w-full object-cover" 
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <span className="font-display font-black text-sm tracking-tight text-gray-950 uppercase">LD</span>
            <span className="block font-mono text-[8px] text-amber-500 font-bold uppercase tracking-widest leading-none">EARN</span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {/* Quick Stats on Mobile Header */}
          <div className="text-right text-[11px] font-mono leading-none">
            <span className="text-gray-400 block text-[9px] uppercase">Available</span>
            <strong className="text-amber-400 font-bold">₦{availableWithdrawal.toLocaleString()}</strong>
          </div>

          <button
            onClick={() => setIsMobileOpen(!isMobileOpen)}
            className="p-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 text-gray-700 transition cursor-pointer"
            aria-label="Toggle Navigation Drawer"
          >
            {isMobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </header>

      {/* 2. PERSISTENT SIDEBAR DESKTOP & SLIDEOUT MOBILE DRAWER */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-72 bg-gradient-to-b from-white to-slate-50/50 border-r border-gray-150 flex flex-col justify-between transition-transform duration-300 transform
        lg:translate-x-0 lg:static lg:h-screen lg:shrink-0
        ${isMobileOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full lg:shadow-none'}
      `}>
        
        <div>
          {/* Sidebar Header Logo Section */}
          <div className="h-20 border-b border-gray-100 px-6 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl overflow-hidden border border-gray-200 bg-white p-0.5 shadow-xs">
                <img 
                  src={ldLogo} 
                  alt="LD Logo" 
                  className="h-full w-full object-cover rounded-lg" 
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <h1 className="font-display font-black text-lg tracking-tight text-gray-950 uppercase leading-none">
                  LD
                </h1>
                <p className="font-mono text-[9px] text-amber-500 font-bold uppercase tracking-widest mt-1">
                  Secure Workspace
                </p>
              </div>
            </div>

            {/* Mobile Close Button inside drawer */}
            <button
              onClick={() => setIsMobileOpen(false)}
              className="lg:hidden p-1 rounded-lg border border-gray-100 hover:bg-gray-50 text-gray-400 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* User Profile Summary badge atop items */}
          <div className="p-4 mx-3 my-4 bg-gray-50 rounded-2xl border border-gray-150">
            <div className="flex items-center space-x-3">
              <div className="h-9 w-9 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-500 font-bold text-xs uppercase shadow-2xs overflow-hidden">
                {profilePhoto ? (
                  <img src={profilePhoto} alt="Profile" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  profileName.charAt(0)
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-black text-white truncate leading-snug">{profileName}</div>
                <div className="text-[9px] font-mono font-bold text-amber-500 uppercase tracking-widest leading-none mt-0.5">{profileLevel}</div>
              </div>
            </div>
            
            {/* Quick Ledger Snapshot */}
            <div className="mt-3 pt-3 border-t border-gray-150 flex items-center justify-between text-xs">
              <span className="text-gray-450 font-sans font-medium text-gray-500">Available:</span>
              <strong className="text-amber-450 font-extrabold font-mono">₦{availableWithdrawal.toLocaleString()}</strong>
            </div>
          </div>

          {/* Core Navigation Items Navigation Grid */}
          <nav className="px-3 space-y-1 overflow-y-auto max-h-[calc(100vh-270px)] scrollbar-thin">
            {menuItems.map((item) => {
              const isActive = activeTab === item.id;
              const IconComp = item.icon;

              return (
                <button
                  key={item.id}
                  id={`sidebar-item-${item.id}`}
                  onClick={() => {
                    if (item.id === 'logout') {
                      setIsAuthenticated(false);
                      setTasks([]);
                      setActiveTab('dashboard');
                      triggerToast('Session terminated securely! Lock screen activated.');
                    } else {
                      setActiveTab(item.id);
                    }
                    setIsMobileOpen(false);
                  }}
                  className={`
                    w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-xs font-bold transition-all duration-150 group cursor-pointer
                    ${isActive 
                      ? 'bg-gradient-to-r from-amber-500 to-[#e65c00] text-slate-950 font-black shadow-md shadow-amber-500/10' 
                      : item.isDanger 
                      ? 'text-red-500 hover:bg-red-50' 
                      : 'text-gray-650 hover:bg-gray-100 hover:text-gray-900'
                    }
                  `}
                >
                  <div className="flex items-center space-x-3">
                    <IconComp className={`h-4.5 w-4.5 transition-colors ${
                      isActive 
                        ? 'text-slate-950' 
                        : item.isDanger 
                        ? 'text-red-400 group-hover:text-red-600' 
                        : 'text-gray-400 group-hover:text-gray-950'
                    }`} />
                    <span className="font-sans font-semibold tracking-wide">{item.label}</span>
                  </div>

                  {/* Badge controllers */}
                  {item.badgeCount !== undefined && (
                    <span className={`inline-flex items-center justify-center px-2 py-0.5 rounded-full text-[9px] font-mono font-extrabold tracking-wider ${
                      isActive 
                        ? 'bg-amber-600/30 text-amber-300' 
                        : item.isBadgeRed 
                        ? 'bg-red-100 text-red-700 animate-pulse'
                        : 'bg-amber-500/10 text-amber-500'
                    }`}>
                      {item.badgeCount}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Official Telegram & WhatsApp Sidebar Promotion Widget */}
        <div className="mx-3 my-2 p-3.5 bg-gradient-to-br from-amber-500/10 to-amber-600/5 rounded-2xl border border-amber-500/10 shadow-xs">
          <div className="flex items-start gap-2.5">
            <div className="h-7 w-7 rounded-lg bg-amber-500/20 text-amber-500 flex items-center justify-center shrink-0 border border-amber-500/30">
              <Send className="h-4 w-4 rotate-[15deg] translate-x-[-1px]" />
            </div>
            <div>
              <h4 className="text-[11px] font-bold text-gray-900 dark:text-gray-950 uppercase tracking-wide leading-tight">Official Community</h4>
              <p className="text-[9.5px] text-gray-400 leading-normal mt-0.5">Join to get real-time task alerts, tips, & withdrawal notifications.</p>
            </div>
          </div>
          <div className="mt-3 space-y-1.5">
            <a 
              href={officialWhatsappLink}
              target="_blank"
              rel="noreferrer"
              className="block w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-black uppercase tracking-wider text-center rounded-lg transition duration-150 cursor-pointer"
            >
              Join WhatsApp Group
            </a>
            <a 
              href={officialChannelLink}
              target="_blank"
              rel="noreferrer"
              className="block w-full py-2 bg-slate-950 hover:bg-slate-900 text-white hover:text-amber-400 text-[10px] font-black uppercase tracking-wider text-center rounded-lg transition duration-150 cursor-pointer"
            >
              Join Telegram Channel
            </a>
          </div>
        </div>

        {/* Sidebar Footer parameters */}
        <div className="p-4 border-t border-gray-100 select-none">
          <div className="flex items-center space-x-2 text-[10px] font-mono text-gray-400">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-bold">SYSTEM ONLINE</span>
          </div>
          <p className="text-[10px] text-gray-400 mt-1 font-sans">
            LD Earn Console. Integrity Checked.
          </p>
        </div>

      </aside>

      {/* Backdrop for mobile slideout drawer */}
      {isMobileOpen && (
        <div 
          onClick={() => setIsMobileOpen(false)}
          className="lg:hidden fixed inset-0 bg-black/30 backdrop-blur-3xs z-40"
        />
      )}

      {/* 3. DYNAMIC MAIN STAGE CONTENT VIEW AREA */}
      <div className="flex-1 flex flex-col justify-between min-h-screen">
        
        <div>
          {/* Toast Notification Alert */}
          {toastMessage && (
            <div className="mx-6 mt-6 p-4 rounded-xl bg-gray-900 text-white text-xs font-bold font-mono tracking-wide flex items-center justify-between shadow-lg animate-fade-in z-50">
              <div className="flex items-center space-x-2 text-emerald-400">
                <Sparkles className="h-4 w-4 text-emerald-400" />
                <span>{toastMessage}</span>
              </div>
              <button onClick={() => setToastMessage('')} className="text-[10px] text-gray-400 hover:text-white uppercase transition tracking-wider">Dismiss</button>
            </div>
          )}

          <main className="px-4 sm:px-6 lg:px-8 py-8">
            
            {/* VIEW 1: OVERVIEW DASHBOARD */}
            {activeTab === 'dashboard' && (
              <Dashboard 
                referralBalance={referralBalance}
                taskBalance={taskBalance}
                totalBalance={totalBalance}
                availableWithdrawal={availableWithdrawal}
                todaysTasksCount={activeAvailableTasks}
                referralEarnings={referralEarnings}
                totalReferrals={totalReferrals}
                activities={activities}
                highlightTask={getHighlightTask()}
                profileLevel={profileLevel}
                onNavigate={(tab) => {
                  if (tab === 'tasks' || tab === 'referrals' || tab === 'wallet' || tab === 'withdraw') {
                    setActiveTab(tab);
                  }
                }}
                onQuickCompleteTask={() => {
                  setActiveTab('tasks');
                }}
                onQuickWithdraw={(amount, category) => {
                  setPresetWithdrawalAmount(amount);
                  setPresetCategory(category);
                  setActiveTab('withdraw');
                  triggerToast(`Quick Cashout Prepared: Specified 50% of available funds (₦${amount.toLocaleString()}) from ${category} Balance!`);
                }}
                officialChannelLink={officialChannelLink}
                officialWhatsappLink={officialWhatsappLink}
              />
            )}

            {/* VIEW 2: DAILY MICROTASKS TARGET GRID */}
            {activeTab === 'tasks' && (
              <TasksList 
                tasks={tasks}
                onCompleteTask={handleCompleteTask}
                profileLevel={profileLevel}
              />
            )}

            {/* VIEW 3: REFERRALS COMMISSION CENTRE */}
            {activeTab === 'referrals' && (
              <ReferralSystem 
                referralsList={referrals}
                totalReferrals={totalReferrals}
                totalReferralEarnings={referralEarnings}
                onSimulateInvite={handleSimulateInvite}
                onUpdateReferralStatus={handleUpdateReferralStatus}
                onDeleteReferral={handleDeleteReferral}
                profileLevel={profileLevel}
              />
            )}

            {/* VIEW 3.5: PERSONAL BUSINESS PROMOTIONS MANAGER */}
            {activeTab === 'business' && (
              !isBusinessUnlocked ? (
                <PinProtectionOverlay 
                  sectionName="My Business Portal" 
                  onUnlock={() => { 
                    setIsBusinessUnlocked(true); 
                    triggerToast('My Business portal authorized successfully!'); 
                  }} 
                />
              ) : (
                <MyBusiness 
                  availableWithdrawal={availableWithdrawal}
                  onDeductBalance={handleDeductBalance}
                  onAddHistoryLog={handleAddHistoryLog}
                  triggerToast={triggerToast}
                  tasks={tasks}
                  onUpdateTasks={setTasks}
                  onWithdrawalProcessed={handleWithdrawalProcessed}
                  isAdmin={isAdmin}
                  onApproveTask={handleApproveTask}
                  onRejectTask={handleRejectTask}
                  withdrawals={globalWithdrawals}
                />
              )
            )}

            {/* VIEW 3.6: CENTRAL ADMIN PAYOUT VERIFICATION LEDGER */}
            {activeTab === 'admin_withdrawals' && (
              <AdminWithdrawals 
                triggerToast={triggerToast}
                onWithdrawalProcessed={handleWithdrawalProcessed}
                tasks={tasks}
                onApproveTask={handleApproveTask}
                onRejectTask={handleRejectTask}
                withdrawals={globalWithdrawals}
              />
            )}

            {/* VIEW 4: SECURE WALLET BALANCES LEDGER */}
            {activeTab === 'wallet' && (
              <WalletLedger 
                totalBalance={totalBalance}
                availableWithdrawal={availableWithdrawal}
                activitiesList={activities}
                onAddEarningFunds={handleAddEarningFunds}
              />
            )}

            {/* VIEW 5: PAYOUT BANK TRANSFER FORM */}
            {activeTab === 'withdraw' && (
              !isWithdrawUnlocked ? (
                <PinProtectionOverlay 
                  sectionName="Withdraw Funds Screen" 
                  onUnlock={() => { 
                    setIsWithdrawUnlocked(true); 
                    triggerToast('Funds Withdrawal system unlocked successfully!'); 
                  }} 
                />
              ) : (
                <WithdrawalForm 
                  referralBalance={referralBalance}
                  taskBalance={taskBalance}
                  profileLevel={profileLevel}
                  onInitiateWithdrawal={handleInitiateWithdrawal}
                  presetAmount={presetWithdrawalAmount}
                  presetCategory={presetCategory}
                />
              )
            )}

            {/* VIEW 6: DETAILED AUDIT TRANSACTION HISTORY */}
            {activeTab === 'transactions' && (
              <TransactionHistory 
                activities={activities}
              />
            )}

            {/* VIEW 6B: VERIFIED WITHDRAWAL PROOFS */}
            {activeTab === 'withdrawal_proofs' && (
              <WithdrawalProofs />
            )}

            {/* VIEW 7: REALTIME LIVE NOTIFICATIONS */}
            {activeTab === 'notifications' && (
              <NotificationsCenter />
            )}

            {/* VIEW 8: SUPPORT HELP DESK SERVICE */}
            {activeTab === 'support' && (
              <SupportCenter 
                officialChannelLink={officialChannelLink} 
                officialWhatsappLink={officialWhatsappLink} 
              />
            )}

            {/* VIEW 9: EDITABLE PROFILE & SETTLEMENT SETTINGS */}
            {activeTab === 'profile' && (
              <ProfileSettings 
                onUpdateSuccess={(msg) => triggerToast(msg)}
                theme={theme}
                onThemeChange={setTheme}
                profilePhoto={profilePhoto}
                onProfilePhotoChange={setProfilePhoto}
              />
            )}

          </main>
        </div>

        {/* Structured payout terms layout footer */}
        <Footer />

      </div>

      {/* Auto-logout warning modal */}
      {showLogoutWarning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-fade-in" id="auto-logout-warning-overlay">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-gray-100 dark:border-slate-800 p-6 text-center space-y-5 animate-scale-in">
            <div className="mx-auto w-16 h-16 bg-amber-50 dark:bg-amber-950/40 rounded-full flex items-center justify-center text-amber-500 animate-pulse">
              <AlertTriangle className="h-8 w-8" />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-lg font-extrabold text-slate-900 dark:text-white font-sans tracking-tight">
                Inactivity Timeout Warning
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Your session is about to terminate due to inactivity. For your account security, you will be automatically logged out in:
              </p>
            </div>

            <div className="py-4 px-6 bg-slate-50 dark:bg-slate-850 rounded-2xl flex items-center justify-center gap-3">
              <Clock className="h-5 w-5 text-amber-500 animate-spin" style={{ animationDuration: '6s' }} />
              <span className="font-mono text-3xl font-black text-amber-500 tabular-nums">
                {warningCountdown}s
              </span>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                type="button"
                id="stay-logged-in-btn"
                onClick={() => {
                  lastActivityTime.current = Date.now();
                  setShowLogoutWarning(false);
                  triggerToast('Session extended successfully!');
                }}
                className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl uppercase tracking-wider shadow-lg shadow-emerald-600/10 transition duration-150 cursor-pointer"
              >
                Stay Logged In
              </button>
              <button
                type="button"
                id="logout-now-btn"
                onClick={() => {
                  setIsAuthenticated(false);
                  setTasks([]);
                  setActiveTab('dashboard');
                  setShowLogoutWarning(false);
                  triggerToast('Session terminated securely.');
                }}
                className="flex-1 py-3 px-4 bg-slate-100 dark:bg-slate-850 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-black rounded-xl uppercase tracking-wider transition duration-150 cursor-pointer"
              >
                Logout Now
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
    </AdminSettingsProvider>
  );
}
